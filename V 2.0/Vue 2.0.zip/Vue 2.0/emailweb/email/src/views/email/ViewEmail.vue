<template>
  <el-card class="email-view">
    <div slot="header" class="clearfix">
      <el-button class="close-btn" @click="closeView">X</el-button>
      <div class="email-subject">{{ email.subject }}</div>
    </div>
    <el-descriptions class="content" :column="2" :content-style="cont" :label-style="des"  border>
      <el-descriptions-item label="From" label-class-name="my-label" content-class-name="my-content">{{ email.senderEmail }}</el-descriptions-item>
      <el-descriptions-item label="Name" label-class-name="my-label" content-class-name="my-content">{{ userInfo.name }}</el-descriptions-item>
      <!-- <el-descriptions-item label="To">{{ email.recipientEmail }}</el-descriptions-item> -->
      <el-descriptions-item label="Department" label-class-name="my-label" content-class-name="my-content">{{ userInfo.department }}</el-descriptions-item>
      <el-descriptions-item label="Time" label-class-name="my-label" content-class-name="my-content">{{ email.updateTime }}</el-descriptions-item>
      <!-- 展示附件信息 -->
      <el-descriptions-item label="Attachments" :span="2">
        <template v-if="attachments.length">
          <ul>
            <li v-for="attachment in attachments" :key="attachment.uid">
              <a :href="attachment.response.content" target="_blank">{{ attachment.name }}</a>
            </li>
          </ul>
        </template>
        <span v-else>No attachment</span>
      </el-descriptions-item>
    </el-descriptions>
    <div v-html="email.content" class="email-content"></div>
  </el-card>
</template>
  
<script>
export default {
  name: "EmailView",
  data() {
    return {
      email: {}, // 初始为空对象
      attachments: [], // 用于存储附件信息
      userInfo:[],
      des:{
        'borderColor':'#f5f3ec',
      },
      cont:{
        'borderColor':'#f5f3ec',
      }
    };
  },
  mounted() {
    const emailId = this.$route.params.emailId;
    const fromInbox = this.$route.query.fromInbox;
    // this.loadEmailDetails(emailId);
    this.loadEmailDetails(emailId, fromInbox);
    
  },
  methods: {
    loadUserInfo(userEmail) {
      if(userEmail){
        this.axios.get(`http://localhost:3759/email-web/sysUser/${userEmail}`)
        .then(response => {
          // console.log(response.data);
          this.userInfo = response.data;
          
        })
        .catch(error => {
          console.error("Error fetching user info:", error);
        });
      }else{
        console.error("User email not found.");
      }
    },
    loadEmailDetails(emailId, fromInbox) {
      this.axios.get(`http://localhost:3759/email-web/emails/${emailId}`, { params: { fromInbox } })
        .then((response) => {
          this.email = response.data;
          console.log(this.email);
          // 解析attachmentInfo
          if (this.email.attachmentInfo) {
            this.attachments = JSON.parse(this.email.attachmentInfo);
          }
          // 使用formatDate方法来格式化时间
          this.email.updateTime = this.formatDate(this.email.updateTime);
          this.loadUserInfo(this.email.senderEmail);
        })
        .catch((error) => {
          console.error("Error fetching email details:", error);
        });
    },
    closeView() {
      this.$router.back();
    },
    formatDate(date) {
        return this.$moment(date).format('YYYY-MM-DD'); // 格式化为您需要的格式
    },
  },
};
</script>

<style lang="less" scoped>
.email-view {
  background-color: #EFEAD8;
  // padding-left: 10px; /* 左侧留出空间 */
  // padding-right: 10px; /* 右侧留出空间 */
  height: 650px; /* 根据你的内容多少调整，确保内容能够良好展示 */
  overflow: auto; /* 如果内容超出指定高度，允许滚动 */
  // 上面的X按钮和主题的显示样式
    .clearfix{  
      display: flex;
      flex-direction: column; // 子元素垂直排列
      align-items: flex-end; // 第一个子元素（"X" 按钮）靠右对齐
      text-align: center; // 确保文本也居中
      .close-btn{
        align-self: flex-end; // 靠右显示
        background-color: #eef1d7;
        color: #2f4d37;
        border: 1px solid #d1ccbc;
        &:hover {
          background-color: #cedac9;
          color: #2f4d37;
          border: 1px solid #d2d4c2;
        }
      }
      .email-subject{
        font-weight: bold; // 加粗显示
        width: 100%; // 确保占满整行
        text-align: center; // 文本居中
        margin-top: 10px; // 在 "X" 按钮下方留出空间
      }
    }
    ::v-deep .el-card__header{
      // border-bottom-style:dotted solid #637b2b;
      border-bottom: 1px solid transparent;
    }
    // 内容表格部分
    .content ::v-deep .el-descriptions-item__label {
      max-width: 40px; /* 或者你希望的任何宽度 */
      text-align: center; // 文本居中
      background-color: #cedac9;
      color: #2f4d37;

    }
    .content{
      ::v-deep .el-descriptions-item__content {
        width: auto; /* 或者设定一个具体的最大宽度，例如 250px */
        background-color: #dfdac8;
        color: #2f4d37;
        padding-left: 30px;
      }
    }
    /* 附件文件的默认颜色 */
    .content ::v-deep .el-descriptions-item__content ul li a {
      color: #5ba06d; 
    }
    /* 鼠标悬停时的颜色 */
    .content ::v-deep .el-descriptions-item__content ul li a:hover {
      color: #2f4d37; 
    }
  .email-content, ul {
    margin-top: 20px;
    padding: 15px;
    background-color: #dfdac8;
    // border: 1px solid #fbf6e4;
    border-radius: 4px;
  }
  
}

</style>
