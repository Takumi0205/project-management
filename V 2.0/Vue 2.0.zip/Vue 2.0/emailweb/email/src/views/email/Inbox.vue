<template>
    <div class="body">
        <div class="search-box">
            <el-input
            v-model="searchQuery"
            placeholder="Search emails..."
            class="input-with-select"
            >
                
            </el-input>
            <el-button class="search-button custom-button" slot="append" icon="el-icon-search" @click="searchEmails"></el-button>
            <el-button class="back-button custom-button" icon="el-icon-arrow-left" @click="resetSearch"></el-button>
        </div>
        <el-table
        ref="multipleTable"
        :data="tableData"
        tooltip-effect="dark"
        height="76vh"
        border
        :row-class-name="tableRowClassName"
        @selection-change="handleSelectionChange"
        empty-text="No emails found in the inbox."
        style="width: 100%">
        <!-- 选择框 -->
        <el-table-column
            type="selection"
            width="55">
        </el-table-column>
        <!-- 序号 -->
        <el-table-column
            type="index"
            :index="indexMethod">
        </el-table-column>
        <!-- 日期 -->
        <el-table-column
            prop="updateTime"
            label="Date"
            width="95"
            show-overflow-tooltip>
        </el-table-column>
        <!-- 发件人name -->
        <el-table-column
            prop="senderEmail"
            label="Sender"
            width="140"
            show-overflow-tooltip>
        </el-table-column>
        <!-- 主题 -->
        <el-table-column
            prop="subject"
            label="Subject"
            show-overflow-tooltip>
        </el-table-column>
        <el-table-column
            prop="content"
            label="Content"
            show-overflow-tooltip>
        </el-table-column>
        <!-- 附件的具体数量 -->
        <el-table-column
            label="Attachment"
            width="140"
            show-overflow-tooltip>
            <template v-slot="{ row }">
                <span v-if="getAttachmentCount(row.attachmentInfo)">
                    {{ getAttachmentCount(row.attachmentInfo) }} attachments
                </span>
                <span v-else>No attachment</span>
            </template>
        </el-table-column>
        <!-- 是否已读 -->
        <el-table-column
            prop="isRead"
            label="Status"
            width="100">
            <template v-slot="{ row }">
                <span v-if="!row.isRead" style="color: red;">Unread</span>
                <span v-else style="color: green;">Read</span>
            </template>
        </el-table-column>
        <!-- 操作 -->
        <el-table-column
        fixed="right"
        label="operation"
        width="110">
            <template slot-scope="scope">
                <el-button @click="viewEmail(scope.row)" type="text" size="small">View</el-button>
                <el-button @click="deleteEmail(scope.row)" type="text" size="small">Delete</el-button>
            </template>
        </el-table-column>
        </el-table>
    </div>
  </template>
  
<script>
export default {
    name: "Inbox",
    data() {
        return {
            tableData: [],
            multipleSelection: [],
            searchQuery: '',
        }
      },
    methods: {
        /* // load(){
        //     const recipientEmail = localStorage.getItem('userEmail');
        //     if (recipientEmail) {
        //         this.axios.get(`http://localhost:3759/email-web/inbox?email=${recipientEmail}`)
        //             .then(response => {
        //                 // console.log(response.data); // 打印邮件数据，检查isRead字段
        //                 // 如果后端正确返回了邮件列表数据
        //                 this.tableData = response.data.map(email => {
        //                     // 格式化或调整每个邮件对象
        //                     // email.updateTime = email.updateTime ? new Date(email.updateTime).toLocaleString() : '';
        //                     // 使用formatDate方法来格式化日期
        //                     email.updateTime = this.formatDate(email.updateTime);
        //                     // console.log(email.isRead); // 看看是否每个邮件都有isRead字段以及它的值
        //                     return email;
        //                 });
        //             })
        //             .catch(error => {
        //             console.error("Error fetching emails:", error);
        //             });
        //     } else {
        //         console.error("Recipient email is not found in localStorage.");
        //     }
        // },
        */ 
        

        // 加载邮件的方法，如果没有特定查询，就加载所有邮件
        loadEmials() {
            const recipientEmail = localStorage.getItem('userEmail');
            let url = `http://localhost:3759/email-web/inbox?email=${recipientEmail}`;
            if (this.searchQuery.trim()) {
                url += `&query=${encodeURIComponent(this.searchQuery)}`;
            }
            this.axios.get(url)
                .then(response => {
                    this.tableData = response.data.map(email => {
                        email.updateTime = this.formatDate(email.updateTime);
                        return email;
                    });
                })
                .catch(error => {
                    console.error("Error fetching emails:", error);
                });
        },
        indexMethod(index) {
            return index + 1;
        },
        toggleSelection(rows) {
            if (rows) {
            rows.forEach(row => {
                this.$refs.multipleTable.toggleRowSelection(row);
            });
            } else {
            this.$refs.multipleTable.clearSelection();
            }
        },
        handleSelectionChange(val) {
            this.multipleSelection = val;
        },
        tableRowClassName({row, index}) {
            if (index === 1) {
            return 'warning-row';
            } else if (index === 3) {
            return 'success-row';
            }
            return '';
        },
        formatDate(date) {
            return this.$moment(date).format('YYYY-MM-DD'); // 格式化为您需要的格式
        },
        viewEmail(row) {
            // 从row对象中获取emailId了
            const emailId = row.emailId;
            // this.$router.push({ name: 'ViewEmail', params: { emailId: emailId } });
            this.$router.push({ name: 'ViewEmail', params: { emailId: emailId }, query: { fromInbox: true } });
        },
        // 前端获取附件有几个
        getAttachmentCount(attachmentInfo) {
            try {
                const attachments = JSON.parse(attachmentInfo);
                if (Array.isArray(attachments) && attachments.length > 0) {
                    return attachments.length; // 返回附件数量
                }
            } catch (error) {
                console.error("Error parsing attachmentInfo:", error);
            }
            return 0; // 如果没有附件或解析失败，返回0
        },
        deleteEmail(row) {
            this.$confirm('Are you sure you want to delete this email?', 'Warning', {
                confirmButtonText: 'OK',
                cancelButtonText: 'Cancel',
                type: 'warning'
            }).then(() => {
                this.axios.delete(`http://localhost:3759/email-web/inbox/${row.emailId}`)
                    .then(response => {
                        // 检查状态码，以确保操作成功
                        if (response.status === 200) {
                            this.$message.success('Draft deleted successfully');
                            // 确保在这里重新加载收件箱列表，而不是跳转，如果是要刷新当前页面的数据
                            this.loadEmials(); // 重新加载收件箱的方法
                        } else {
                            // 如果状态码不是200，但请求被.then()捕获，说明有一个问题需要检查
                            console.error("Unexpected response status:", response);
                            this.$message.error('Failed to delete draft');
                        }
                    })
                    .catch(error => {
                        console.error("Error deleting draft:", error);
                        this.$message.error('Failed to delete draft');
                    });
            }).catch(() => {
                this.$message.info('Delete canceled');
            });
        },
        searchEmails() {
            const recipientEmail = localStorage.getItem('userEmail');
            if (recipientEmail && this.searchQuery.trim()) {
            this.axios.get(`http://localhost:3759/email-web/inbox/search`, { params: { email: recipientEmail, query: this.searchQuery }})
                .then(response => {
                this.tableData = response.data.map(email => {
                    email.updateTime = this.formatDate(email.updateTime);
                    return email;
                });
                })
                .catch(error => {
                console.error("Error searching emails:", error);
                });
            } else {
            console.error("Recipient email is not found in localStorage or search query is empty.");
            }
        },
        resetSearch() {
            this.searchQuery = ''; // 重置搜索查询
            this.loadEmails(); // 重新加载或显示全部邮件
        },
    },
    
    mounted() {
        const recipientEmail = localStorage.getItem('userEmail');
        if (recipientEmail) {
            this.axios.get(`http://localhost:3759/email-web/inbox?email=${recipientEmail}`)
                .then(response => {
                    // console.log(response.data); // 打印邮件数据，检查isRead字段
                    // 如果后端正确返回了邮件列表数据
                    this.tableData = response.data.map(email => {
                        // 格式化或调整每个邮件对象
                        // email.updateTime = email.updateTime ? new Date(email.updateTime).toLocaleString() : '';
                        // 使用formatDate方法来格式化日期
                        email.updateTime = this.formatDate(email.updateTime);
                        // console.log(email.isRead); // 看看是否每个邮件都有isRead字段以及它的值
                        return email;
                    });
                })
                .catch(error => {
                console.error("Error fetching emails:", error);
                });
        } else {
            console.error("Recipient email is not found in localStorage.");
        }
    },
}
</script>

  <style lang="less" scoped>
  .body {
    max-width: 100vw; // 最大宽度不超过视口宽度
    max-height: 84vh; // 最大高度不超过视口高度

    .search-box {
        display: flex;
        align-items: center; // 垂直居中对齐
        gap: 10px; // 在元素之间添加一些间隙
        padding-bottom: 10px; // 为搜索框和返回按钮底部添加一些间距

        .custom-button {
            display: flex; /* 启用Flexbox */
            justify-content: center; /* 水平居中内容 */
            align-items: center; /* 垂直居中内容 */
            width: 60px; /* 按钮宽度 */
        }
        .search-button{
            background-color: #eef1d7;
            color: #2f4d37;
            margin-left: 5px;
            &:hover {
                background: #cedac9;
                color: #2f4d37;
            }
        }
        .back-button {
            background-color: #eef1d7;
            color: #2f4d37;
            margin-left: 5px; 

            &:hover {
                background: #cedac9;
                color: #2f4d37;
            }
        }
    }
    // 每一行的背景颜色
    ::v-deep .el-table__row{
        background-color: #e3e6d0;
        color: #2f4d37;
    }
    // 表格表头背景颜色
    ::v-deep .el-table--border th.el-table__cell {
        background-color: #cedac9;
        color: #2f4d37;
    }
    //剩下表格的北京的颜色
    ::v-deep .el-table, .el-table__expanded-cell {
        background-color: transparent;
    }
    //设置当鼠标移动的时候的行背景颜色
    ::v-deep .el-table__body tr:hover > td{
        background-color:#cfd2bd !important;
    }
    //设置当鼠标移动的时候的行背景颜色
    ::v-deep .el-table__body .el-table__row.hover-row td {
    background-color: #cfd2bd !important;
    font-weight: bolder;
    }

    // ::v-deep .el-table {
    //     .warning-row {
    //         background: oldlace;
    //     }
    //     .success-row {
    //         background: #f0f9eb;
    //     }
    // }
    
    .no-emails-message {
        padding: 20px;
        text-align: center;
        color: #666;
    }
}

  </style>