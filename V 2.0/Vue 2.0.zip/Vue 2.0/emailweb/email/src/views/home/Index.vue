<!-- 系统首页 -->
<template>
    <div class="topDiv">
        <!-- 主体部分 -->
        <div class="body">
            <!--logo标题图片 -->
            <!-- <img class="title" src="../../assets/e1.png" alt="" /> -->
            <div class="title">
                <h3>Taku Email Website</h3>
            </div>
            <!--第二排内容 -->
            <div class="awayMenu">
                <!--左侧 -->
                <div class="awayLeft">
                    <span class="manage2">
                        Welcome!  
                        <!--用户名称 -->
                        <span>  {{ userInfo.name }}</span>
                    </span>
                    <!--登入地址 -->
                    <div class="manage">Login address: {{ location }}</div>
                </div>
            </div>
            <!--三层标题 -->
            <div class="bigTips">
                <span style="color: #3a6934; margin-bottom: 10px; margin-top: 20px;">Common modules</span>
                <span style=""> </span>
            </div>
            <!--常用按钮层 -->
            <div class="buttonMenu">
                <!--常用按钮盒子 -->
                <div class="addMenuBox">
                    <!--循环遍历按钮 -->
                    <div class="addMenu" v-for="item in addMenuTempList" :key="item.meta.title" @click="selectItem(item)">
                        {{ item.meta.title }}
                    </div>
                </div>
                <!--分隔线 -->
                <div class="shu"></div>
                <!--右侧3按钮 -->
                <div class="timeBox">
                    <div class="clockDisplay">
                        Date: <span id="date">{{ currentDate }}</span> <!-- 添加日期显示 -->
                        Time: <span id="clock">{{ currentTime }}</span>
                    </div>
                </div>
            </div>
            <!--左下角提升语句，点击跳转盒子-->
            <div class="bottomText" @click="toOwnMenu">
                <!-- 添加"常用模块"? 点我 进入个人门户设置 -->
                Welcome to the email system!
            </div>
        </div>
    </div>
</template>

<script>

/* 引入菜单子组件 */
import MenuTree from '@/components/menu/MenuTree.vue'
// 引入标签导航栏
import TabNavBar from '@/components/tab/TabNavBar.vue'

    export default{
        name: "Index",
        components: {
            // 注册组件
            MenuTree: MenuTree,
            TabNavBar: TabNavBar,
        },
        data() {
        return {
            userInfo:[],
            currentTime: new Date().toLocaleTimeString(), // 这是为了显示时间
            currentDate: new Date().toLocaleDateString(), // 存储当前日期
            location: "Local Test",
            // location: "company Intranet",
            addMenuTempList: [
                {
                    name: 'inbox',
                    path: 'inbox',
                    meta: {
                        title: 'Inbox',
                        icon: 'el-icon-folder-opened'
                    },
                    children: []
                },
                {
                    name: 'drafts',
                    path: 'drafts',
                    meta: {
                        title: 'Drafts',
                        icon: 'el-icon-folder-opened'
                    },
                    children: []
                },
                {
                    name: 'outbox',
                    path: 'outbox',
                    meta: {
                        title: 'Outbox',
                        icon: 'el-icon-folder-opened'
                    },
                    children: []
                },
                {
                    name: 'trashbox',
                    path: 'trashbox',
                    meta: {
                        title: 'Trash Box',
                        icon: 'el-icon-folder-opened'
                    },
                    children: []
                },
                {
                    name: 'sysUser',
                    path: 'sysUser',
                    meta: {
                        title: 'User Management',
                        icon: 'el-icon-folder-opened'
                    },
                    children: []
                },
                {
                    name: 'sendEmail',
                    path: 'sendEmail',
                    meta: {
                        title: 'Send Email',
                        icon: 'el-icon-folder-opened'
                    },
                    children: []
                },
            ],
            number1: 0,
            number2: 0,
            number3: 0,
            number1List: [],
            number2List: [],
            number3List: []
        };
    },

    methods: {
        loadUserInfo(userEmail) {
            if(userEmail){
                this.axios.get(`http://localhost:3759/email-web/sysUser/${userEmail}`)
                .then(response => {
                // console.log(response.data);
                this.userInfo = response.data;
                
                })
                .catch(error => {
                console.error("Error fetching user info:", error);
                });
            }else{
                console.error("User email not found.");
            }
        },
        updateTime() {
            this.currentTime = new Date().toLocaleTimeString();
            this.currentDate = new Date().toLocaleDateString(); // 更新日期
        },
        selectItem(item) {
            if (item.name) {
                this.$router.push({ path: item.name });
                // 先获取一下导航表要是有当前点击的,那么直接跳转到就可以
                // 如果没有,就像下面的代码,直接在导航栏添加.
                this.$store.commit('addTab',item);
            }
        },
        toOwnMenu() {
            this.$router.push("/sysUser");
        },
    },
    mounted() {
        const userEmail = localStorage.getItem('userEmail');
        this.loadUserInfo(userEmail);
        this.interval = setInterval(this.updateTime, 1000); // 1秒更新一下时间
    },
    beforeDestroy() {
        clearInterval(this.interval); // 清除定时器
    },
    watch: {
        clientHeight() {
            this.changeFixed(this.clientHeight);
        },
    },
    }
</script>

<style lang="less" scoped>

@font-face {
    font-family: 'HeadingFont';
    src: url('../../fonts/LibreCaslonDisplay-Regular.woff2') format('woff2');
    font-weight: normal;
    font-style: normal;
}

@font-face {
    font-family: 'HeadingFont2';
    src: url('../../fonts/KaushanScript-Regular.woff2') format('woff2');
    font-weight: normal;
    font-style: normal;
}
@font-face {
    font-family: 'TextFont';
    src: url('../../fonts/Domine-Regular.woff2') format('woff2');
    font-weight: normal;
    font-style: normal;
}

@font-face {
    font-family: 'TextFont2';
    src: url('../../fonts/LibreCaslonText-Bold.woff2') format('woff2');
    font-weight: normal;
    font-style: normal;
}

.body {
    // height: 76vh;
    // height: 717px;
    height: 650px;
    /* width: 98%; */
    max-width: 100vw; /* 最大宽度不超过视口宽度 */
    /* height: 100%; */
    display: flex;
    flex-direction: column;
    padding: 0 45px;
    align-items: center;
    border-radius: 4px;
    /* background-color: #fff; */
    /* margin: 5px 16px; */
    color: #000;
    /* width:100%; */
    background-repeat: no-repeat;
    background-size: cover;
    background-position:center center;
    // background-image: url('../../assets/bk04.jpg');
    // background-color: #cfbda0;
    // background-color: #cce0c5;
    // 目前选定的颜色：e3e6d0
    background-color: #e3e6d0;
    // background-color: #eddd9bfe;
    overflow: auto;
}

.awayLeft {
    display: flex;
    align-items: center;
    justify-content: flex-start; /* 确保内容从左侧开始并且按顺序排列 */
    width: 100%; /* 占据全部可用宽度 */
}


.title {
    /* width: 15%; */
    font-family: 'HeadingFont2';
    letter-spacing: 6px;
    font-size: 30px;
    margin-bottom: 90px;
    max-height: 80px;
    color: #3a6934;
}

.awayMenu {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.manage {
    font-size: 20px;
    display: flex;
    align-items: center;
    margin-left: 680px; /* 将这个元素推向右侧 */
}

.manage2 {
    font-family: 'TextFont';
    letter-spacing: 1px;
    // width: 40%;
    // height: 100%;
    font-size: 28px;
    // float: right;
    display: flex;
    align-items: center;
    // color: rgb(255, 255, 255, 0.7);
}
.manage2 span {
    // color: #2d4f28;
    margin-left: 10px; 
}
.buttonMenu {
    width: 100%;
    display: flex;
}

.bigTips {
    width: 100%;
    display: flex;
    justify-content: left;
    align-items: center;
    margin-top: 3vh;
    margin-bottom: 3vh;
    font-size: 20px;
}

.addMenuBox {
    width: 50%;
    max-width: 500px; /* 根据实际需求调整 */
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    flex-wrap: wrap;  /* 允许内容换行 */

    .addMenu {
        width: 45%;
        height: 24%;
        margin: 2% 2.5%;
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #687c6866;
        border-radius: 10px;
        color: #194608;
        font-size: 20px;
        cursor: pointer;
        
        /* 让鼠标悬停时改变背景颜色 */
        &:hover {
            background-color:#687c68a3;
            color: #d5d5d5;
        }
    }
}

.addMenu :nth-child(5) {
    margin-bottom: 0;
}

.addMenu :nth-child(6) {
    margin-bottom: 0;
}

.shu {
    width: 0.2%;
    margin: 0 9.9%;
    background-color: #4c4c4c;
}

.timeBox {
    width: 30%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
}
.clockDisplay {
    font-family: 'TextFont'; /* 使用适合阅读的字体 */
    letter-spacing: 2px;
    color: #000; /* 字体颜色，根据背景调整 */
    background: rgba(255, 255, 255, 0.6); /* 背景颜色，根据需要调整 */
    padding: 15px;
    border-radius: 5px; /* 边框圆角 */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2); /* 给盒子添加一些阴影 */
    display: flex;
    flex-direction: column; /* 使内容呈现上下结构 */
    align-items: center; /* 水平居中对齐 */
    justify-content: center; /* 垂直居中对齐 */
    margin: 20px 0; /* 上下外边距 */
    margin-top: 40px; /* 增加上边距以向下移动 */
}

#clock, #date {
    font-size: 30px; /* 增加字体大小 */
    letter-spacing: 2px; /* 字符间距 */
    margin: 5px 0; /* 上下外边距 */
}

/* 为了使数字更具立体感，可以增加一点文字阴影 */
#clock {
    text-shadow: 1px 1px 2px #555;
}
#date {
    text-shadow: 1px 1px 2px #555;
}


.button {
    width: 60%;
    height: 28%;
    min-width: 310px;
    max-width: 860px;
    max-height: 80px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: rgba(255, 255, 255, 0.3);
    border-radius: 10px;
    padding: 20px;
    margin: 0 auto;
    z-index: 99;

    .left {
        width: 60%;
        min-width: 150;
        display: flex;
        align-items: center;
    }

    .text {
        color: #fff;
        font-size: 20px;
        position: relative;
    }

    .shu {
        width: 1px !important;
        height: 100%;
        max-height: 35px;
        background-color: #fff;
    }

    .number {
        font-size: 22px;
        color: #fff;
    }
}

.bottomText {
    opacity: 0.7;
    width: 100%;
    margin-top: 7vh;
    text-align: left;
    font-size: 16px;
    color: #98998f;
    text-decoration: underline;
    cursor: pointer;
    &:hover {
        color: #51524bc3
    }
}

.textBox {
    width: 800px;
    display: flex;
    flex-direction: column;
    align-items: left;
    padding: 0 10%;

    .text {
        font-size: 16px;
        margin: 3px 0;
        border-bottom: 1px solid #777;

        .one {
            display: flex;
            align-items: center;

            .xuhao {
                width: 20%;
                min-width: 50px;
                background-color: #ff9900;
                border: 1px solid #ff9900;
                display: flex;
                justify-content: center;
                align-items: center;
                border-radius: 5px;
                padding: 3px;
                margin-right: 8px;
            }

            .floar {
                width: 85%;
                display: flex;
                justify-content: center;
                font-size: 16px;
                font-family: "Fantasy";
                font-weight: 500;
                margin-right: 30px;
            }
        }

        .two {
            display: flex;
            margin: 5px 0;
            align-items: center;
            justify-content: space-between;

            .twoItem {
                width: 35%;
                font-size: 12px;
            }

            .twoItem2 {
                width: 65%;
                display: flex;
                justify-content: center;
                font-size: 12px;

            }
        }
    }
}
</style>