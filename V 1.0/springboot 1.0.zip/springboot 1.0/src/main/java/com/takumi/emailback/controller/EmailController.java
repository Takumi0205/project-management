package com.takumi.emailback.controller;

import com.takumi.emailback.req.EmailLoginReq;
import com.takumi.emailback.req.EmailSaveReq;
import com.takumi.emailback.resp.CommonResp;
import com.takumi.emailback.resp.EmailLoginResp;
import com.takumi.emailback.service.EmailService;
import jakarta.annotation.Resource;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/email-web")
public class EmailController {
    @Resource
    private EmailService emailService;

    @PostMapping("register")
    public CommonResp register(@RequestBody EmailSaveReq req){
        req.setPassword(DigestUtils.md5DigestAsHex(req.getPassword().getBytes()));
        CommonResp resp = new CommonResp<>();

        emailService.register(req);
        System.out.println(req);
        return resp;
    }

    @PostMapping("login")
    public CommonResp login(@RequestBody EmailLoginReq req){
//        密码加密
        req.setPassword(DigestUtils.md5DigestAsHex(req.getPassword().getBytes()));

        CommonResp resp = new CommonResp<>();
        EmailLoginResp login = emailService.login(req);
        resp.setContent(login);
        return resp;
    }
}
