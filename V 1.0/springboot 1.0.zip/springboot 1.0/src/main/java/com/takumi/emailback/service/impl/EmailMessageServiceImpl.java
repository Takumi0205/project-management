package com.takumi.emailback.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.takumi.emailback.entity.EmailEntity;
import com.takumi.emailback.entity.EmailMessageEntity;
import com.takumi.emailback.mapper.EmailMapper;
import com.takumi.emailback.mapper.EmailMessageMapper;
import com.takumi.emailback.req.EmailMessageSaveReq;
import com.takumi.emailback.service.EmailMessageService;
import com.takumi.emailback.utils.CopyUtil;
import jakarta.annotation.Resource;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;

import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class EmailMessageServiceImpl extends ServiceImpl<EmailMessageMapper, EmailMessageEntity> implements EmailMessageService {

    @Resource
    private EmailMessageMapper emailMessageMapper;

    @Resource
    private EmailMapper emailMapper;
//    保存邮件信息到数据库的操作
    @Override
    @Transactional
    public boolean sendMessage(EmailMessageSaveReq req) {
        EmailMessageEntity message = CopyUtil.copy(req, EmailMessageEntity.class);
        System.out.println("the message is:" + message);

        try {
            System.out.println("fujian:" + message.getAttachmentInfo());
            // 这里应该是实际的邮件发送逻辑，例如调用第三方服务或者邮件服务器
            // 假设邮件发送逻辑在这里，如果邮件成功发送:
            message.setStatus("sent"); // 假设发送成功
            emailMessageMapper.insert(message); // 保存邮件信息
            return true; // 发送成功
        } catch (Exception e) {
            // 发送失败的处理逻辑
            message.setStatus("failed");
            emailMessageMapper.insert(message); // 即使失败也保存邮件信息，但状态为failed
            return false; // 发送失败
        }
    }
    // 在相应的Service类中
    public List<String> getAllEmailAddresses() {
        // 使用QueryWrapper来查询所有记录，不设置任何条件表示查询全部
        List<EmailEntity> emailList = emailMapper.selectList(new QueryWrapper<>());
        // 使用Java 8 Stream API将EmailEntity列表转换为邮箱地址列表
        List<String> emailAddresses = emailList.stream()
                .map(EmailEntity::getEmail) // 假设getEmail是获取邮箱地址的getter方法
                .collect(Collectors.toList());
        return emailAddresses;
    }


    //    保存邮件为草稿的方法
    @Override
    @Transactional
    public boolean saveDraft(EmailMessageSaveReq req) {
        EmailMessageEntity message = CopyUtil.copy(req, EmailMessageEntity.class);
        System.out.println("the email message is:" + message);

        try {
            message.setStatus("draft"); // 设置状态为草稿
            emailMessageMapper.insert(message); // 尝试保存到数据库
            return true; // 保存成功
        } catch (Exception e) {
            // 异常处理逻辑，根据需要记录日志或者做其他处理
            // 发送失败的处理逻辑
            message.setStatus("failed");
            emailMessageMapper.insert(message); // 即使失败也保存邮件信息，但状态为failed
            return false; // 保存失败
        }
    }




    @Override
    public List<EmailMessageSaveReq> getEmailsForRecipient(String recipientEmail) {
        QueryWrapper<EmailMessageEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("recipient_email", recipientEmail)
                    .eq("status", "sent") // 只选取状态为 "sent" 的邮件
                    .eq("recipient_deleted", false);
        List<EmailMessageEntity> entities = emailMessageMapper.selectList(queryWrapper);

//        return entities.stream().map(entity -> CopyUtil.copy(entity, EmailMessageSaveReq.class)).collect(Collectors.toList());
        return entities.stream().map(entity -> {
            EmailMessageSaveReq emails = CopyUtil.copy(entity, EmailMessageSaveReq.class);
            emails.setEmailId(entity.getEmailId().toString()); // 在这里进行转换
            return emails;
        }).collect(Collectors.toList());
    }


//    通过id查到email信息
    @Override
    public EmailMessageSaveReq getEmailById(Long emailId, Boolean fromInbox) {
        EmailMessageEntity entity = emailMessageMapper.selectById(emailId);
        if (entity != null ){
            if (Boolean.TRUE.equals(fromInbox) && !entity.getIsRead()) {
                System.out.println("The Email open from inbox");
                entity.setIsRead(true);
                emailMessageMapper.updateById(entity);
            }
            EmailMessageSaveReq emailDetails = CopyUtil.copy(entity, EmailMessageSaveReq.class);
            return emailDetails;
        }
        return null;
    }

//    @Override
//    public EmailMessageSaveReq getEmailById(Long emailId) {
//        EmailMessageEntity entity = emailMessageMapper.selectById(emailId);
//        if (entity != null) {
//            // 检查邮件是否未读，如果是，则将其标记为已读
//            if (!entity.getIsRead()) {
//                entity.setIsRead(true); // 更新为已读
//                emailMessageMapper.updateById(entity); // 保存更新到数据库
//            }
//            EmailMessageSaveReq emails = CopyUtil.copy(entity, EmailMessageSaveReq.class);
//            emails.setEmailId(entity.getEmailId().toString()); // 进行转换
//            return emails;
//        }
//        return null;
//    }

    @Override
    public List<EmailMessageSaveReq> getDraftsForUser(String userEmail) {
        QueryWrapper<EmailMessageEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("sender_email", userEmail)
                .eq("status", "draft");
        List<EmailMessageEntity> drafts = emailMessageMapper.selectList(queryWrapper);
//        if (!drafts.isEmpty()) {
//            for (EmailMessageEntity draft : drafts) {
//                System.out.println("emailID of Draft: " + draft.getEmailId());
//            }
//        } else {
//            System.out.println("No drafts found.");
//        }
//        return entities.stream().map(entity -> {
//            EmailMessageSaveReq emails = CopyUtil.copy(entity, EmailMessageSaveReq.class);
//            emails.setEmailId(entity.getEmailId().toString()); // 在这里进行转换
//            return emails;
        return drafts.stream().map(draft -> {
            EmailMessageSaveReq emails = CopyUtil.copy(draft, EmailMessageSaveReq.class);
            emails.setEmailId(draft.getEmailId().toString()); // 在这里进行转换
            return emails;
        }).collect(Collectors.toList());
    }

//    更新草稿件
    @Override
    @Transactional
    public boolean updateDraft(EmailMessageSaveReq req) {
        if (req.getEmailId() == null || req.getEmailId().isEmpty()) {
            return false; // 没有提供有效的Email ID
        }

        Long emailId = Long.parseLong(req.getEmailId());
        EmailMessageEntity existingDraft = emailMessageMapper.selectById(emailId);

        if (existingDraft == null) {
            existingDraft = new EmailMessageEntity(); // 如果不存在，创建新实例
        }

        // 设置或更新字段值
        existingDraft.setEmailId(emailId);
        existingDraft.setSenderEmail(req.getSenderEmail());
        existingDraft.setRecipientEmail(req.getRecipientEmail());
        existingDraft.setSubject(req.getSubject());
        existingDraft.setContent(req.getContent());
        existingDraft.setAttachmentInfo(req.getAttachmentInfo());
        existingDraft.setStatus("draft"); // 确保状态被设置为草稿
        // 当在草稿箱点击edit时，调用的是byID的方法，已经设置了is_Read变为了true，
        // 所以在用户再次点击保存为草稿的时候把isRead的状态改回来。
        existingDraft.setIsRead(false);
        existingDraft.setUpdateTime(LocalDateTime.now()); // 显式设置更新时间为当前时间

        try {
            emailMessageMapper.updateDraft(existingDraft); // 使用insertOrUpdate
            return true; // 操作成功
        } catch (Exception e) {
            e.printStackTrace();
            return false; // 操作失败
        }
    }

//    在草稿修改页面发送邮件
    @Override
    @Transactional
    public boolean sendDraft(EmailMessageSaveReq req) {
        if (req.getEmailId() == null || req.getEmailId().isEmpty()) {
            return false;
        }

        Long emailId = Long.parseLong(req.getEmailId());
        EmailMessageEntity email = emailMessageMapper.selectById(emailId);
        if (email == null) {
            return false;
        }

        // 更新邮件信息
        email.setRecipientEmail(req.getRecipientEmail());
        email.setSubject(req.getSubject());
        email.setContent(req.getContent());
        email.setAttachmentInfo(req.getAttachmentInfo());
        email.setStatus("sent");
        email.setIsRead(false);
        email.setUpdateTime(LocalDateTime.now()); // 更新时间

        try {
            emailMessageMapper.updateById(email);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

//    获取到发件箱中的全部邮件列表
    @Override
    public List<EmailMessageSaveReq> getEmailsForOutbox(String senderEmail) {
        QueryWrapper<EmailMessageEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("sender_email", senderEmail)
                    .in("status", Arrays.asList("sent", "draft", "failed")) // 只包括'sent'、'draft'、'failed'状态的邮件;
                    .eq("sender_deleted", false);
        List<EmailMessageEntity> entities = emailMessageMapper.selectList(queryWrapper);

//        return entities.stream().map(entity -> CopyUtil.copy(entity, EmailMessageSaveReq.class)).collect(Collectors.toList());
        return entities.stream().map(entity -> {
            EmailMessageSaveReq emails = CopyUtil.copy(entity, EmailMessageSaveReq.class);
            emails.setEmailId(entity.getEmailId().toString()); // 在这里进行转换
            return emails;
        }).collect(Collectors.toList());
    }
//    获取到垃圾箱中的全部邮件列表
    @Override
    public List<EmailMessageSaveReq> getEmailsForTrashbox(String userEmail) {
        // 查询作为发件人且标记为删除的邮件
        QueryWrapper<EmailMessageEntity> senderDeletedQuery = new QueryWrapper<>();
//        查找发件人的id与登录id符合的邮件,然后查找sender_deleted为1的邮件,说明
//        1.从草稿箱删除的邮件
//        2.从发件箱删除的邮件
        senderDeletedQuery.eq("sender_email", userEmail)
                          .eq("sender_deleted", true)
                          .eq("confirm_sender_deleted", false);

        List<EmailMessageEntity> senderDeletedEmails = emailMessageMapper.selectList(senderDeletedQuery);

        // 查询作为收件人且标记为删除的邮件
//        1.从收件箱中删除的邮件
        QueryWrapper<EmailMessageEntity> recipientDeletedQuery = new QueryWrapper<>();
        recipientDeletedQuery.eq("recipient_email", userEmail)
                             .eq("recipient_deleted", true)
                             .eq("confirm_recipient_deleted", false);

        List<EmailMessageEntity> recipientDeletedEmails = emailMessageMapper.selectList(recipientDeletedQuery);

        // 合并两个列表
        List<EmailMessageEntity> allDeletedEmails = new ArrayList<>(senderDeletedEmails);
        allDeletedEmails.addAll(recipientDeletedEmails);


        // 应用层面去重，保证每个邮件ID只出现一次
        List<EmailMessageSaveReq> distinctEmails = allDeletedEmails.stream()
                .collect(Collectors.collectingAndThen(
                        Collectors.toMap(EmailMessageEntity::getEmailId, Function.identity(), (e1, e2) -> e1),
                        map -> new ArrayList<>(map.values())))
                .stream()
                .map(entity -> {
                    EmailMessageSaveReq emailDto = CopyUtil.copy(entity, EmailMessageSaveReq.class);
                    // 确保在这里手动设置emailId为字符串形式
                    emailDto.setEmailId(entity.getEmailId().toString());
                    return emailDto;
                })
                .collect(Collectors.toList());


        // 转换为DTO列表
//        return allDeletedEmails.stream().map(entity -> {
//            EmailMessageSaveReq emailDto = CopyUtil.copy(entity, EmailMessageSaveReq.class);
//            emailDto.setEmailId(entity.getEmailId().toString()); // 在这里进行转换
//            return emailDto;
//        }).collect(Collectors.toList());
        return distinctEmails;
    }



    //    从草稿箱中删除邮件到垃圾桶
    @Override
    @Transactional
    public boolean deleteDraft(Long emailId) {
        EmailMessageEntity draft = emailMessageMapper.selectById(emailId);
        if (draft != null && "draft".equals(draft.getStatus())) {
            draft.setStatus("deleted"); // 更新状态为已删除
            draft.setSenderDeleted(true); // 标记为发件人删除
            emailMessageMapper.updateById(draft); // 更新记录
            return true;
        }
        return false;
    }

    //    从收件中删除邮件到垃圾桶
    @Override
    @Transactional
    public boolean deleteInboxEmail(Long emailId) {
        EmailMessageEntity email = emailMessageMapper.selectById(emailId);
        if (email != null && "sent".equals(email.getStatus())) {
            email.setRecipientDeleted(true); // 标记为发件人删除
            emailMessageMapper.updateById(email); // 更新记录
            return true;
        }
        return false;
    }

    //    从发件箱中删除邮件到垃圾桶
    @Override
    @Transactional
    public boolean deleteOutboxEmail(Long emailId) {
        EmailMessageEntity email = emailMessageMapper.selectById(emailId);
        if (email != null){
            if("sent".equals(email.getStatus()) || "draft".equals(email.getStatus())
                    || "failed".equals(email.getStatus())){
                email.setSenderDeleted(true); // 标记为发件人删除
                emailMessageMapper.updateById(email); // 更新记录
                return true;
            }
        }
        return false;
    }

//    在垃圾箱里彻底删除的操作
    @Override
    @Transactional
    public boolean confirmDeleteEmail(Long emailId, String currentUserEmail) {
        EmailMessageEntity email = emailMessageMapper.selectById(emailId);
        if (email == null) {
            return false;
        }

        boolean isSender = currentUserEmail.equals(email.getSenderEmail());
        boolean isRecipient = currentUserEmail.equals(email.getRecipientEmail());

        if ("deleted".equals(email.getStatus())) {
            // 特殊处理：草稿被标记为已删除，且没有收件人删除的情况
            if (isSender && !Boolean.TRUE.equals(email.getRecipientDeleted())) {
                email.setConfirmSenderDeleted(true);
                // 对于草稿，直接进行彻底删除操作
                if (!Boolean.TRUE.equals(email.getConfirmRecipientDeleted())) {
                    emailMessageMapper.deleteById(emailId); // 或其他彻底删除的逻辑
                    return true;
                }
            }
        }
        // 检查是否同时为发件人和收件人
        if (isSender && isRecipient) {
            boolean confirmDelete = false;
            if (Boolean.TRUE.equals(email.getSenderDeleted())) {
                email.setConfirmSenderDeleted(true);
                confirmDelete = true;
            }
            if (Boolean.TRUE.equals(email.getRecipientDeleted())) {
                email.setConfirmRecipientDeleted(true);
                confirmDelete = true;
            }
            if (confirmDelete && email.getConfirmSenderDeleted() && email.getConfirmRecipientDeleted()) {
                emailMessageMapper.deleteById(emailId); // 彻底删除邮件记录
                return true;
            }
        } else {
            if (isSender && Boolean.TRUE.equals(email.getSenderDeleted())) {
                email.setConfirmSenderDeleted(true);
            }
            if (isRecipient && Boolean.TRUE.equals(email.getRecipientDeleted())) {
                email.setConfirmRecipientDeleted(true);
            }
            // 只有当两个确认删除状态都为true时，才彻底删除邮件
            if (email.getConfirmSenderDeleted() && email.getConfirmRecipientDeleted()) {
                emailMessageMapper.deleteById(emailId); // 彻底删除邮件记录
                return true;
            }
        }

        emailMessageMapper.updateById(email); // 更新邮件状态
        return true;
    }
    //    在收件箱中搜索邮件
    @Override
    public List<EmailMessageSaveReq> searchEmailsForRecipient(String recipientEmail, String query) {
        QueryWrapper<EmailMessageEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("recipient_email", recipientEmail)
                .eq("status", "sent") // 确保只搜索状态为"sent"的邮件
                .eq("recipient_deleted", false) // 确保不搜索已被标记为删除的邮件
                .and(wrapper -> wrapper
                        .like("subject", query)
                        .or()
                        .like("content", query));

        List<EmailMessageEntity> entities = emailMessageMapper.selectList(queryWrapper);

        // 如果entities为空，直接返回一个空的列表
        if (entities == null || entities.isEmpty()) {
            return new ArrayList<>(); // 返回一个空列表，而不是null
        }

        // 转换实体到DTO，并确保emailId被正确转换为String类型
        return entities.stream().map(entity -> {
            EmailMessageSaveReq emailDto = CopyUtil.copy(entity, EmailMessageSaveReq.class);
            emailDto.setEmailId(entity.getEmailId().toString()); // 确保这里是获取实体类中的ID并转换为字符串
            return emailDto;
        }).collect(Collectors.toList());
    }

    //    在草稿箱中搜索邮件
    @Override
    public List<EmailMessageSaveReq> searchEmailsInDrafts(String userEmail, String query) {
        QueryWrapper<EmailMessageEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("sender_email", userEmail)
                    .eq("status", "draft")
                    .and(wrapper -> wrapper
                            .like("subject", query)
                            .or()
                            .like("content", query));

        List<EmailMessageEntity> entities = emailMessageMapper.selectList(queryWrapper);

        // 如果entities为空，直接返回一个空的列表
        if (entities == null || entities.isEmpty()) {
            return new ArrayList<>(); // 返回一个空列表，而不是null
        }

        // 转换实体到DTO，并确保emailId被正确转换为String类型
        return entities.stream().map(entity -> {
            EmailMessageSaveReq emailDto = CopyUtil.copy(entity, EmailMessageSaveReq.class);
            emailDto.setEmailId(entity.getEmailId().toString()); // 确保这里是获取实体类中的ID并转换为字符串
            return emailDto;
        }).collect(Collectors.toList());
    }

    //    在发件箱中搜索邮件
    @Override
    public List<EmailMessageSaveReq> searchEmailsInOutbox(String senderEmail, String query) {
        QueryWrapper<EmailMessageEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("sender_email", senderEmail)
                    .in("status", Arrays.asList("sent", "draft", "failed")) // 只包括'sent'、'draft'、'failed'状态的邮件;
                    .eq("sender_deleted", false)
                    .and(wrapper -> wrapper
                            .like("subject", query)
                            .or()
                            .like("content", query));

        List<EmailMessageEntity> entities = emailMessageMapper.selectList(queryWrapper);

        // 如果entities为空，直接返回一个空的列表
        if (entities == null || entities.isEmpty()) {
            return new ArrayList<>(); // 返回一个空列表，而不是null
        }

        // 转换实体到DTO，并确保emailId被正确转换为String类型
        return entities.stream().map(entity -> {
            EmailMessageSaveReq emailDto = CopyUtil.copy(entity, EmailMessageSaveReq.class);
            emailDto.setEmailId(entity.getEmailId().toString()); // 确保这里是获取实体类中的ID并转换为字符串
            return emailDto;
        }).collect(Collectors.toList());
    }

    //    在垃圾箱中搜索邮件
    public List<EmailMessageSaveReq> searchEmailsInTrashbox(String userEmail, String query) {
        // 创建一个集合来存储查询结果
        List<EmailMessageEntity> results = new ArrayList<>();

        // 分别查询作为发件人的邮件
        QueryWrapper<EmailMessageEntity> senderQueryWrapper = new QueryWrapper<>();
        senderQueryWrapper
                .eq("sender_email", userEmail)
                .eq("sender_deleted", true)
                .eq("confirm_sender_deleted", false)
                .and(wrapper -> wrapper.like("subject", query).or().like("content", query));

        List<EmailMessageEntity> senderResults = emailMessageMapper.selectList(senderQueryWrapper);
        if (senderResults != null && !senderResults.isEmpty()) {
            results.addAll(senderResults);
        }

        // 分别查询作为收件人的邮件
        QueryWrapper<EmailMessageEntity> recipientQueryWrapper = new QueryWrapper<>();
        recipientQueryWrapper
                .eq("recipient_email", userEmail)
                .eq("recipient_deleted", true)
                .eq("confirm_recipient_deleted", false)
                .and(wrapper -> wrapper.like("subject", query).or().like("content", query));

        List<EmailMessageEntity> recipientResults = emailMessageMapper.selectList(recipientQueryWrapper);
        if (recipientResults != null && !recipientResults.isEmpty()) {
            results.addAll(recipientResults);
        }

        // 应用层面去重，保证每个邮件ID只出现一次
        List<EmailMessageSaveReq> distinctEmails = results.stream()
                .collect(Collectors.collectingAndThen(
                        Collectors.toMap(EmailMessageEntity::getEmailId, Function.identity(), (e1, e2) -> e1),
                        map -> new ArrayList<>(map.values())))
                .stream()
                .map(entity -> {
                    EmailMessageSaveReq emailDto = CopyUtil.copy(entity, EmailMessageSaveReq.class);
                    emailDto.setEmailId(entity.getEmailId().toString()); // 确保emailId被正确转换为String类型
                    return emailDto;
                })
                .collect(Collectors.toList());

        return distinctEmails;
    }

}
