package com.takumi.emailback.service;

import com.takumi.emailback.req.EmailMessageSaveReq;

import java.util.List;

public interface EmailMessageService {
//    void sendMessage(EmailMessageSaveReq req);
    boolean sendMessage(EmailMessageSaveReq req);
//    得到数据库中的email列表
    List<String> getAllEmailAddresses();
//    保存邮件为草稿的方法
    boolean saveDraft(EmailMessageSaveReq req);
//收件箱显示邮件
    List<EmailMessageSaveReq> getEmailsForRecipient(String recipientEmail);
//让用户可以在inbox页面点击view时查看到具体的邮件信息。
//    然后在用户点击查看邮件后改变状态为已读
    EmailMessageSaveReq getEmailById(Long emailId, Boolean fromInbox);

// 获取到email为草稿的列表
    List<EmailMessageSaveReq> getDraftsForUser(String userEmail);

//    是否删除草稿
    boolean deleteDraft(Long draftId);

//在草稿箱页面更新草稿。
    boolean updateDraft(EmailMessageSaveReq req);

//在草稿箱页面发送邮件
    boolean sendDraft(EmailMessageSaveReq req);
    //收件箱显示邮件
    List<EmailMessageSaveReq> getEmailsForOutbox(String recipientEmail);

//垃圾箱获取邮件列表
    List<EmailMessageSaveReq> getEmailsForTrashbox(String userEmail);

//    删除收件箱中的邮件
    boolean deleteInboxEmail(Long draftId);
    //    删除发件箱中的邮件
    boolean deleteOutboxEmail(Long draftId);
    //    在垃圾箱里彻底删除的操作
    boolean confirmDeleteEmail(Long emailId, String currentUserEmail);
    //    在收件箱中搜索邮件
    List<EmailMessageSaveReq> searchEmailsForRecipient(String recipientEmail, String query);

    //    在草稿箱中搜索邮件
    List<EmailMessageSaveReq> searchEmailsInDrafts(String recipientEmail, String query);
    //    在发件箱中搜索邮件
    List<EmailMessageSaveReq> searchEmailsInOutbox(String recipientEmail, String query);
    //    在垃圾中搜索邮件
    List<EmailMessageSaveReq> searchEmailsInTrashbox(String recipientEmail, String query);

}
