package com.takumi.emailback.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.takumi.emailback.entity.EmailEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface EmailMapper extends BaseMapper<EmailEntity> {
}
