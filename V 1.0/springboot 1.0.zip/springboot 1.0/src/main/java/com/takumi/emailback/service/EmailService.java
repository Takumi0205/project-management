package com.takumi.emailback.service;

import com.takumi.emailback.req.EmailLoginReq;
import com.takumi.emailback.req.EmailSaveReq;
import com.takumi.emailback.resp.EmailLoginResp;

public interface EmailService {

    void register(EmailSaveReq req);

    EmailLoginResp login(EmailLoginReq req);
}
