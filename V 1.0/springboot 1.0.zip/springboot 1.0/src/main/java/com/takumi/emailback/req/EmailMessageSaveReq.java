package com.takumi.emailback.req;


import java.time.LocalDateTime;

public class EmailMessageSaveReq {

    private String emailId;
    private String senderEmail;
    private String recipientEmail;
    //    邮件的主题
    private String subject;
//    邮件的内容
    private String content;

    //    附件信息
    private String attachmentInfo;

    // 邮件状态，例如“已发送”或“草稿”
    private String status;

    // Getters and Setters

    private boolean isRead; // 确保这里和你的实体类中的字段对应

    private LocalDateTime updateTime; // 添加更新时间字段

    private Boolean senderDeleted;
    private Boolean recipientDeleted;

    private Boolean confirmSenderDeleted;
    private Boolean confirmRecipientDeleted;

    // Getter 和 Setter

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
    public String getSenderEmail() {
        return senderEmail;
    }

    public void setSenderEmail(String senderEmail) {
        this.senderEmail = senderEmail;
    }

    public String getRecipientEmail() {
        return recipientEmail;
    }

    public void setRecipientEmail(String recipientEmail) {
        this.recipientEmail = recipientEmail;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAttachmentInfo() {
        return attachmentInfo;
    }

    public void setAttachmentInfo(String attachmentInfo) {
        this.attachmentInfo = attachmentInfo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(boolean isRead) {
        this.isRead = isRead;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public Boolean getSenderDeleted() {
        return senderDeleted;
    }

    public void setSenderDeleted(Boolean senderDeleted) {
        this.senderDeleted = senderDeleted;
    }

    public Boolean getRecipientDeleted() {
        return recipientDeleted;
    }

    public void setRecipientDeleted(Boolean recipientDeleted) {
        this.recipientDeleted = recipientDeleted;
    }

    public Boolean getConfirmSenderDeleted() {
        return confirmSenderDeleted;
    }

    public void setConfirmSenderDeleted(Boolean confirmSenderDeleted) {
        this.confirmSenderDeleted = confirmSenderDeleted;
    }

    public Boolean getConfirmRecipientDeleted() {
        return confirmRecipientDeleted;
    }

    public void setConfirmRecipientDeleted(Boolean confirmRecipientDeleted) {
        this.confirmRecipientDeleted = confirmRecipientDeleted;
    }

    @Override
    public String toString() {
        return "EmailMessageEntity{" +
                "emailId=" + emailId +
                ", senderEmail='" + senderEmail + '\'' +
                ", recipientEmail='" + recipientEmail + '\'' +
                ", subject='" + subject + '\'' +
                ", content='" + content + '\'' +
                ", attachmentInfo='" + attachmentInfo + '\'' +
                ", status='" + status + '\'' +
                ", isRead='" + isRead + '\'' +
                ", updateTime='" + updateTime + '\'' +
                ", senderDeleted='" + senderDeleted + '\'' +
                ", recipientDeleted='" + recipientDeleted + '\'' +
                ", confirmSenderDeleted='" + confirmSenderDeleted + '\'' +
                ", confirmRecipientDeleted='" + confirmRecipientDeleted + '\'' +
                '}';
    }
}
