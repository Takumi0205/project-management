<template>
  <div class="user-info-container">
    <!-- <h2 class="user-info-title">User Information</h2> -->
    <div class="demo-image__preview">
      <el-image 
        style="width: 100px; height: 100px"
        :src="avatarUrl" 
        :preview-src-list="srcList">
      </el-image>
    </div>
    
    <!-- <el-avatar class="user-avatar" :src="userInfo.avatar" shape="square" :size="100"></el-avatar> -->
    <!-- 上传头像 -->
    <el-upload
      v-if="isEditing"
      class="avatar-uploader"
      action="http://localhost:3759/email-web/upload/avatar"
      :on-success="handleAvatarSuccess"
      :before-upload="beforeAvatarUpload"
      :show-file-list="false">
      <el-button class="user-info-ava" size="small">Upload new avatar</el-button>
    </el-upload>
    
    <el-descriptions class="margin-top" :column="1" border>
      <template slot="extra">
        <el-button class="user-info-button" type="primary" @click="toggleEditing" size="small">Edit</el-button>
      </template>
      <!-- 邮件 -->
      <el-descriptions-item>
        <template slot="label">
          <i class="el-icon-message"></i>
          Email
        </template>
        <template v-if="isEditing">
          <el-input v-model="editableUserInfo.email" :disabled="true"></el-input>
        </template>
        <template v-else>
          {{ userInfo.email }}
        </template>
      </el-descriptions-item>

      <!-- 用户名字 -->
      <el-descriptions-item>
        <template slot="label">
          <i class="el-icon-user"></i>
          Name
        </template>
        <template v-if="isEditing">
          <el-input v-model="editableUserInfo.name"></el-input>
        </template>
        <template v-else>
          {{ userInfo.name }}
        </template> 
      </el-descriptions-item>

      <!-- 用户电话 -->
      <el-descriptions-item>
        <template slot="label">
          <i class="el-icon-mobile"></i>
          Phone
        </template>
        <template v-if="isEditing">
          <el-input v-model="editableUserInfo.phone"></el-input>
        </template>
        <template v-else>
          {{ userInfo.phone }}
        </template>
      </el-descriptions-item>

      <!-- 用户的部门 -->
      <el-descriptions-item>
        <template slot="label">
          <i class="el-icon-tickets"></i>
          Department
        </template>
        <template v-if="isEditing">
          <el-input v-model="editableUserInfo.department" :disabled="true"></el-input>
        </template>
        <template v-else>
          <el-tag>{{ userInfo.department }}</el-tag>
        </template>
      </el-descriptions-item>

      <!-- 用户的个人简介 -->
      <el-descriptions-item>
        <template slot="label">
          <i class="el-icon-edit"></i>
          Individual resume 
        </template>
        <template v-if="isEditing">
          <el-input v-model="editableUserInfo.personalIntro"></el-input>
        </template>
        <template v-else>
          {{ userInfo.personalIntro}}
        </template>
      </el-descriptions-item>

      <!-- 用户住址 -->
      <el-descriptions-item>
        <template slot="label">
          <i class="el-icon-office-building"></i>
          Address
        </template>
        <template v-if="isEditing">
          <el-input v-model="editableUserInfo.address"></el-input>
        </template>
        <template v-else>
          {{ userInfo.address}}
        </template>
      </el-descriptions-item>
    </el-descriptions>
    <el-button type="success" @click="saveUserInfo" v-if="isEditing">Save</el-button>
  </div>
</template>

<script>
export default {
  name: "SysUser",
  data() {
    return {
      userInfo: {
        email: '',
        name: '',
        phone: '',
        department: '',
        personalIntro: '',
        address: '',
        avatar: '',
      },
      editableUserInfo: {},
      isEditing: false,
      avatarInfos: [],
    };
  },
  mounted() {
    this.loadUserInfo();
  },
  computed: {
    avatarUrl() {
      // 检查userInfo.avatar是否为空或者不存在
      if (!this.userInfo.avatar || this.userInfo.avatar === '') {
        return ''; // 提前返回一个默认的占位URL或空字符串
      }
      try {
        const avatarInfo = JSON.parse(this.userInfo.avatar);
        return avatarInfo.url; // 返回解析后的头像URL
      } catch (error) {
        console.error("Error parsing avatar info:", error);
        return ''; // 解析失败时同样返回一个默认的占位URL或空字符串
      }
      return 'http://localhost:3759/avatars/avatar01.jpeg';
    },
    srcList() {
      // 如果 avatarUrl 有效，则将其作为唯一元素的数组返回
      if (this.avatarUrl) {
        return [this.avatarUrl];
      } else {
        // 如果没有有效的 avatarUrl，返回一个包含默认头像URL的数组
        return ['http://localhost:3759/avatars/avatar01.jpeg'];
      }
    }

  },
  methods: {
    loadUserInfo() {
      const userEmail = localStorage.getItem('userEmail');
      if (userEmail) {
        this.axios.get(`http://localhost:3759/email-web/sysUser/${userEmail}`)
          .then(response => {
            
            this.userInfo = response.data;
            this.editableUserInfo = { ...this.userInfo }; // Clone userInfo for editing
          })
          .catch(error => {
            console.error("Error fetching user info:", error);
          });
      } else {
        console.error("User email not found.");
      }
    },
    toggleEditing() {
      this.isEditing = true;
    },
    saveUserInfo() {
      // 验证 editableUserInfo 数据有效性
      console.log("Saving user information", this.editableUserInfo);
      this.axios.post(`http://localhost:3759/email-web/sysUser/update`, this.editableUserInfo)
        .then(response => {
          // 处理成功的响应
          console.log("User information updated successfully", response);
          this.isEditing = false; // 关闭编辑模式
          this.$message.success('User information updated successfully');

          // 更新 userInfo 以显示最新的信息
          this.userInfo = { ...this.editableUserInfo };

          console.log("保存后头像信息",this.userInfo.avatar);
        })
        .catch(error => {
          // 处理错误的响应
          console.error("Error updating user info:", error);
          this.$message.error('Failed to update user information');
        });
    },
    handleAvatarSuccess(response, file) {
      // console.log("这个头像成功更新了",response);

      if (response.success) {
        // 组织你想要的数据结构
        const avatarInfos = {
            status: "success",
            name: file.name,
            uid: response.message,
            url: response.content // 假设这是从后端返回的文件访问URL
        };
        this.userInfo.avatar = JSON.stringify(avatarInfos);
        // 修改信息栏也要把更新的头像信息写进去
        this.editableUserInfo.avatar = this.userInfo.avatar;
        this.$message.success('Avatar uploaded successfully');
        console.log("头像信息:",this.userInfo.avatar);
      } else {
        this.$message.error('Upload failed: ' + response.message);
      }
    },
    beforeAvatarUpload(file) {
      const isJPG = file.type === 'image/jpeg' || file.type === 'image/png';
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG) {
        this.$message.error('Avatar picture must be in JPEG or PNG format!');
      }
      if (!isLt2M) {
        this.$message.error('Avatar picture size must not exceed 2MB!');
      }
      return isJPG && isLt2M;
    }
  }
}
</script>

<style lang="less" scoped>
.user-info-container {
  height: 650px; /* 根据你的内容多少调整，确保内容能够良好展示 */
  overflow: auto; /* 如果内容超出指定高度，允许滚动 */

  .user-info-title {
    text-align: center;
  }

  .avatar-uploader{

    .user-info-ava{
      margin-bottom: 10px;
    }
  }
  
  .user-info-button{
    margin-bottom: 0px;
  }

  .user-avatar {
    margin: 20px auto;
    display: block;
  }

  .margin-top{
    /deep/ .el-descriptions-item__label {
      width: 15%;
    }
  }
}
</style>
