<template>
  <el-card class="email-view">
    <el-button class="close-btn" @click="closeView">X</el-button>
    <div slot="header" class="clearfix">
      <span>{{ email.subject }}</span>
    </div>
    <el-descriptions :column="1" border>
      <el-descriptions-item label="From">{{ email.senderEmail }}</el-descriptions-item>
      <el-descriptions-item label="To">{{ email.recipientEmail }}</el-descriptions-item>
      <el-descriptions-item label="Time">{{ email.updateTime }}</el-descriptions-item>
      <!-- 展示附件信息 -->
      <el-descriptions-item label="Attachments">
        <template v-if="attachments.length">
          <ul>
            <li v-for="attachment in attachments" :key="attachment.uid">
              <a :href="attachment.response.content" target="_blank">{{ attachment.name }}</a>
            </li>
          </ul>
        </template>
        <span v-else>No attachment</span>
      </el-descriptions-item>
    </el-descriptions>
    <div v-html="email.content" class="email-content"></div>
  </el-card>
</template>
  
<script>
export default {
  name: "EmailView",
  data() {
    return {
      email: {}, // 初始为空对象
      attachments: [], // 用于存储附件信息
    };
  },
  mounted() {
    const emailId = this.$route.params.emailId;
    const fromInbox = this.$route.query.fromInbox;
    // this.loadEmailDetails(emailId);
    this.loadEmailDetails(emailId, fromInbox);
    
  },
  methods: {
    loadEmailDetails(emailId, fromInbox) {
      this.axios.get(`http://localhost:3759/email-web/emails/${emailId}`, { params: { fromInbox } })
        .then((response) => {
          this.email = response.data;
          // 解析attachmentInfo
          if (this.email.attachmentInfo) {
            this.attachments = JSON.parse(this.email.attachmentInfo);
          }
          // 使用formatDate方法来格式化时间
          this.email.updateTime = this.formatDate(this.email.updateTime);
        })
        .catch((error) => {
          console.error("Error fetching email details:", error);
        });
    },
    closeView() {
      this.$router.back();
    },
    formatDate(date) {
        return this.$moment(date).format('YYYY-MM-DD'); // 格式化为您需要的格式
    },
  },
};
</script>

<style lang="less" scoped>
.email-view {
    height: 650px; /* 根据你的内容多少调整，确保内容能够良好展示 */
  	overflow: auto; /* 如果内容超出指定高度，允许滚动 */
  .email-content, ul {
    margin-top: 20px;
    padding: 15px;
    background-color: #f9f9f9;
    border: 1px solid #ebeef5;
    border-radius: 4px;
  }
}
</style>
