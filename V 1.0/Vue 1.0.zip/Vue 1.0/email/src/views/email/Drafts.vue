<!-- 草稿箱视图 -->
<template>
    <div class="body">
        <div class="search-box">
            <el-input
            v-model="searchQuery"
            placeholder="Search emails..."
            class="input-with-select"
            >
                <el-button slot="append" icon="el-icon-search" @click="searchEmails"></el-button>
            </el-input>
            <el-button class="back-button" icon="el-icon-arrow-left" @click="resetSearch"></el-button>
        </div>
        <el-table
            ref="multipleTable"
            :data="tableData"
            tooltip-effect="dark"
            border
            height="76vh"
            :row-class-name="tableRowClassName"
            @selection-change="handleSelectionChange"
            empty-text="No emails found in the drafts."
            style="width: 100%">
            <!-- 选择框 -->
            <el-table-column type="selection" width="55"></el-table-column>
            <!-- 序号 -->
            <el-table-column type="index" :index="indexMethod"></el-table-column>
            <!-- 日期 -->
            <el-table-column prop="updateTime" label="Date" width="95" show-overflow-tooltip></el-table-column>
            <!-- 收件人 -->
            <el-table-column prop="recipientEmail" label="Recipient" width="140" show-overflow-tooltip></el-table-column>
            <!-- 主题 -->
            <el-table-column prop="subject" label="Subject" show-overflow-tooltip></el-table-column>
            <!-- 内容预览 -->
            <el-table-column prop="content" label="Content" show-overflow-tooltip></el-table-column>
            <!-- 附件数量 -->
            <el-table-column label="Attachment" width="120" show-overflow-tooltip>
                <template v-slot="{ row }">
                    <span v-if="getAttachmentCount(row.attachmentInfo)">{{ getAttachmentCount(row.attachmentInfo) }} attachments</span>
                    <span v-else>No attachment</span>
                </template>
            </el-table-column>
            <!-- 操作 -->
            <el-table-column fixed="right" label="Operation" width="120">
                <template slot-scope="scope">
                    <el-button @click="editDraft(scope.row)" type="text" size="small">Edit</el-button>
                    <el-button @click="deleteDraft(scope.row)" type="text" size="small">Delete</el-button>
                </template>
            </el-table-column>
        </el-table>
    </div>
</template>

<script>
export default {
    name: "Drafts",
    data() {
        return {
            tableData: [],
            multipleSelection: [],
            searchQuery: '',
        }
    },
    methods: {
        // loadDrafts() {
        //     const userEmail = localStorage.getItem('userEmail'); // 假设你通过localStorage存储了用户的email
        //     if (userEmail) {
        //         this.axios.get(`http://localhost:3759/email-web/drafts?email=${userEmail}`)
        //             .then(response => {
        //                 console.log(response.data);
        //                 this.tableData = response.data.map(draft => {
        //                     draft.updateTime = this.formatDate(draft.updateTime);
        //                     return draft;
        //                 });
        //             })
        //             .catch(error => {
        //                 console.error("Error loading drafts:", error);
        //                 this.$message.error('Failed to load drafts');
        //             });
        //     } else {
        //         console.error("User email is not found in localStorage.");
        //         // 可以选择在这里做一些额外的处理，例如提示用户登录
        //     }
        // },
        loadDrafts() {
            const userEmail = localStorage.getItem('userEmail');
            if (!userEmail) {
                console.error("User email is not found in localStorage.");
                this.$message.error('User email not found. Please log in.');
                return;
            }

            // Construct the base URL for fetching drafts
            let url = `http://localhost:3759/email-web/drafts?email=${encodeURIComponent(userEmail)}`;
            // Append the search query if present
            if (this.searchQuery.trim()) {
                url += `&query=${encodeURIComponent(this.searchQuery.trim())}`;
            }

            this.axios.get(url)
                .then(response => {
                    this.tableData = response.data.map(draft => {
                        // Format each draft's updateTime and return the modified draft
                        draft.updateTime = this.formatDate(draft.updateTime);
                        return draft;
                    });
                    // If no drafts are found, you might want to handle it, e.g., showing a message
                    if (this.tableData.length === 0) {
                        this.$message.info('No drafts found.');
                    }
                })
                .catch(error => {
                    console.error("Error loading drafts:", error);
                    this.$message.error('Failed to load drafts');
                });
        },
        indexMethod(index) {
            return index + 1;
        },
        toggleSelection(rows) {
            if (rows) {
                rows.forEach(row => {
                    this.$refs.multipleTable.toggleRowSelection(row);
                });
            } else {
                this.$refs.multipleTable.clearSelection();
            }
        },
        handleSelectionChange(val) {
            this.multipleSelection = val;
        },
        formatDate(date) {
            return this.$moment(date).format('YYYY-MM-DD');
        },
        editDraft(row) {
            const emailId = row.emailId;
            // 编辑草稿的逻辑
            this.$router.push({ name: 'EditEmail', params: { emailId: emailId }});
        },
        deleteDraft(row) {
            this.$confirm('Are you sure you want to delete this draft?', 'Warning', {
                confirmButtonText: 'OK',
                cancelButtonText: 'Cancel',
                type: 'warning'
            }).then(() => {
                this.axios.delete(`http://localhost:3759/email-web/drafts/${row.emailId}`)
                    .then(response => {
                        // 检查状态码，以确保操作成功
                        if (response.status === 200) {
                            this.$message.success('Draft deleted successfully');
                            // 确保在这里重新加载草稿列表，而不是跳转，如果是要刷新当前页面的数据
                            this.loadDrafts(); // 假设loadDrafts是重新加载草稿的方法
                        } else {
                            // 如果状态码不是200，但请求被.then()捕获，说明有一个问题需要检查
                            console.error("Unexpected response status:", response);
                            this.$message.error('Failed to delete draft');
                        }
                    })
                    .catch(error => {
                        console.error("Error deleting draft:", error);
                        this.$message.error('Failed to delete draft');
                    });
            }).catch(() => {
                this.$message.info('Delete canceled');
            });
        },

        getAttachmentCount(attachmentInfo) {
            try {
                const attachments = JSON.parse(attachmentInfo);
                if (Array.isArray(attachments) && attachments.length > 0) {
                    return attachments.length;
                }
            } catch (error) {
                console.error("Error parsing attachmentInfo:", error);
            }
            return 0;
        },
        tableRowClassName({row, index}) {
            if (index === 1) {
            return 'warning-row';
            } else if (index === 3) {
            return 'success-row';
            }
            return '';
        },
        searchEmails() {
            const userEmail = localStorage.getItem('userEmail');
            if (userEmail && this.searchQuery.trim()) {
            this.axios.get(`http://localhost:3759/email-web/drafts/search`, { params: { email: userEmail, query: this.searchQuery }})
                .then(response => {
                this.tableData = response.data.map(email => {
                    email.updateTime = this.formatDate(email.updateTime);
                    return email;
                });
                })
                .catch(error => {
                console.error("Error searching emails:", error);
                });
            } else {
            console.error("Recipient email is not found in localStorage or search query is empty.");
            }
        },
        resetSearch() {
            this.searchQuery = ''; // 重置搜索查询
            this.loadDrafts(); // 重新加载或显示全部邮件
        },
    },
    mounted() {
        const userEmail = localStorage.getItem('userEmail');
        if (userEmail) {
            this.axios.get(`http://localhost:3759/email-web/drafts?email=${userEmail}`)
                .then(response => {
                    console.log(response.data);
                    this.tableData = response.data.map(draft => {
                        draft.updateTime = this.formatDate(draft.updateTime);
                        return draft;
                    });
                })
                .catch(error => {
                    console.error("Error fetching drafts:", error);
                });
        } else {
            console.error("User email is not found in localStorage.");
        }
    },
}
</script>

<style lang="less" scoped>
.body {
  max-width: 100vw; // 最大宽度不超过视口宽度
  max-height: 84vh; // 最大高度不超过视口高度

  .search-box {
      display: flex;
      align-items: center; // 垂直居中对齐
      gap: 10px; // 在元素之间添加一些间隙
      padding-bottom: 10px; // 为搜索框和返回按钮底部添加一些间距

      .input-with-select {
          flex-grow: 1; // 搜索框占据剩余空间
      }

      .back-button {
          margin-left: 10px; // 为返回按钮添加一些左边距，使其与搜索框有适当的间隔
      }
  }

  .el-table {
      .warning-row {
          background: oldlace;
      }
      .success-row {
          background: #f0f9eb;
      }
  }
  
  .no-emails-message {
      padding: 20px;
      text-align: center;
      color: #666;
  }
}

</style>