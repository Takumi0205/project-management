<template>
	<div class="email-container">
	  <el-form :model="emailForm" ref="emailForm" label-width="0px" class="email-form">
		<h3 class="email-subject">Write an email</h3>
  
		<!-- 邮件标题输入框 -->
		<el-form-item prop="subject" :rules="rules.subject">
		  <el-input v-model="emailForm.subject" placeholder="Email subject" prefix-icon="el-icon-edit"></el-input>
		</el-form-item>
  
		<!-- 收件人选择框 -->
		<el-form-item prop="recipientEmail" :rules="rules.recipientEmail">
		  <el-select v-model="emailForm.recipientEmail" filterable placeholder="Please select recipient">
			<el-option
			  v-for="item in recipients"
			  :key="item.value"
			  :label="item.label"
			  :value="item.value">
			</el-option>
		  </el-select>
		</el-form-item>
  
		<!-- 邮件内容输入框 -->
		<!-- <el-form-item prop="content">
		  <el-input
			type="textarea"
			v-model="emailForm.content"
			placeholder="Email Content"
			rows="5">
		  </el-input>
		</el-form-item> -->

		
		<el-form-item prop="content">
			<vue-editor v-model="emailForm.content" placeholder="Email Content"></vue-editor>
		</el-form-item>
		<!-- 附件组 -->
		<el-form-item label="Attachments:">
			<!-- 			:auto-upload="false" 不能自动上传了 -->
		<el-upload
			class="upload-demo"
			action="http://localhost:3759/email-web/upload" 
			multiple
			:on-success="handleUploadSuccess"
			:on-remove="handleRemoveAttachment"
			:on-preview="handlePreview"
			:file-list="attachments"
			list-type="text">
			<el-button size="small" type="primary">Click to upload</el-button>
			<div slot="tip" class="el-upload__tip">Only files with a size less than 2MB are allowed</div>
		</el-upload>
		</el-form-item>
		<!-- 展示上传文件的链接 -->
		<!-- <ul>
			<li v-for="file in attachments" :key="file.uid">
				<a :href="fileUrl" target="_blank">Download or Preview File</a>
			</li>
		</ul> -->


		<!-- 按钮组 -->
		<el-form-item class="form-actions">
		  <el-button type="primary" @click="saveDraft" style="width: 32%; margin-right: 2%;">Save as draft</el-button>
		  <el-button type="success" @click="sendEmail" style="width: 32%; margin-left: 2%; margin-right: 2%;">Send</el-button>
		  <el-button type="default" @click="resetEmailForm" style="width: 32%;">Reset</el-button>
		</el-form-item>
	  </el-form>
	</div>
  </template>
  
  <script>
  export default {
	name: "SendEmail",
	data() {
	  return {
		emailForm: {
		  recipientEmail: '',
		  senderEmail: '', // 假设这里稍后会被设置为当前登录用户的邮箱
		  subject: '',
		  content: '',
		  attachmentInfo: '', // 这里保留这个字段，但你会在表单提交时动态填充它，在send的方法中把这个变成数组,这样就能上传多组附件了
		//   邮件发送的状态(1:表示成功发送,2:表示保存到草稿,3:表示发送失败) ×
		//   还是保存成了'sent','draft','failed'
		  status: '',
		},
		recipients: [
		  // 收件人已经由 API 获取到了
		],
		attachments: [], // 用于存储上传的附件信息
		// 如果有表单验证规则
		rules: {
			subject: [
				{ required: true, message: 'Please input the subject of the email', trigger: 'blur' }
			],
			recipientEmail: [
				{ required: true, message: 'Please select a recipient', trigger: 'blur' }
			],
		},
	  };
	},
	methods: {
		
		saveDraft() {
			this.$refs.emailForm.validate((valid) => {
				if (valid) {
					// 将attachments数组转换为JSON字符串并存入emailForm.attachmentInfo
					this.emailForm.attachmentInfo = JSON.stringify(this.attachments);
					// 设置状态为草稿
					this.emailForm.status = 'draft';
					// 调用API保存草稿
					this.saveEmailFormData();
				} else{
					console.log('error draft!!');
				}
			});
		},

		sendEmail() {
			this.$refs.emailForm.validate((valid) => {
				if (valid) {
					// 如果验证通过
					// 将attachments数组转换为JSON字符串并存入emailForm.attachmentInfo
					this.emailForm.attachmentInfo = JSON.stringify(this.attachments);
					// 设置状态为已发送
					this.emailForm.status = 'sent';
					// 调用API发送邮件
					this.sendEmailFormData();
				} else {
					console.log('error submit!!');
				}
			});
		},

		// 上传附件的方法
		// handleUploadSuccess(response, file, fileList) {
		// 	this.attachments.push({
		// 		name: file.name, // 文件名
		// 		uid: file.uid, // Element UI自动生成的唯一标识符
		// 		url: response.url, // 文件的URL，如果后端返回了可访问的URL
		// 	});
		// },

		handleUploadSuccess(response, file, fileList) {
			// 假设后端返回的响应体中直接包含了文件的可访问URL
			const fileUrl = response.content;

			// 找到刚上传的文件对象，并为它添加URL属性
			const uploadedFile = this.attachments.find(f => f.uid === file.uid);
			if (uploadedFile) {
				uploadedFile.url = fileUrl; // 将URL保存到文件对象中
			}

			// 更新attachments数组以反映最新状态，这一步可能不是必需的，取决于你的具体实现
			this.attachments = [...fileList];
		},

		handleRemoveAttachment(file, fileList) {
			// 移除文件时更新attachments
			this.attachments = fileList;
		},

		// 删除附件的方法
		// handleRemoveAttachment(file) {
		// 	// 假设使用file.uid作为唯一标识符来识别和删除附件
		// 	// 这是因为如果有多个相同名称的文件，可以使用一个唯一的uid来识别删除
  		// 	this.attachments = this.attachments.filter(attachment => attachment.uid !== file.uid);
			
		// 	// 更新emailForm.attachmentInfo以反映删除操作
  		// 	this.emailForm.attachmentInfo = JSON.stringify(this.attachments);
		// },

		handleRemoveAttachment(file, fileList) {
			// 直接使用更新后的fileList更新attachments，因为<el-upload>已经处理了文件的移除
			this.attachments = [...fileList];

			// 然后更新emailForm.attachmentInfo以反映当前的附件列表状态
			// 这里假设emailForm.attachmentInfo需要包含attachments数组的JSON字符串
			this.emailForm.attachmentInfo = JSON.stringify(this.attachments);
		},

		// 预览附件的方法
		handlePreview(file) {
			// 如果文件对象中有URL，则在新标签页中打开该URL
			if (file.url) {
			window.open(file.url, '_blank');
			} else {
			console.log("No URL available for this file");
			}
		},

		sendEmailFormData() {
			// 调用API发送邮件
			this.axios.post('http://localhost:3759/email-web/send', this.emailForm)
			.then(response => {
				this.resetForm(); // 调用resetEmailForm来重置表单
				// this.$router.push({ name: 'Outbox' });
				this.$message.success('Email sent successfully');
				// 处理响应...
			})
			.catch(error => {
				// 如果发送失败，设置状态为 'failed'
				this.emailForm.status = 'failed';
				console.error(error); // 输出完整的错误信息
				if (error.response && error.response.data) {
					// 如果后端返回了具体的错误消息
					this.$message.error('Failed to send email: ' + error.response.data.message);
				} else {
					this.$message.error('Failed to send email');
				}
			});
	    },
		saveEmailFormData() {
			// 调用API发送邮件
			this.axios.post('http://localhost:3759/email-web/saveDraft', this.emailForm)
			.then(response => {
				this.resetForm(); // 调用resetEmailForm来重置表单

				// this.$router.push({ name: 'Outbox' });

				this.$message.success('Email saved successfully');
				// 处理响应...
			})
			.catch(error => {
				// 如果发送失败，设置状态为 'failed'
				this.emailForm.status = 'failed';
				console.error(error); // 输出完整的错误信息
				if (error.response && error.response.data) {
					// 如果后端返回了具体的错误消息
					this.$message.error('Failed to save email: ' + error.response.data.message);
				} else {
					this.$message.error('Failed to save email');
				}
			});
	    },
		// 重置表单的逻辑
		resetEmailForm() {
			// 只重置特定的字段，保留senderEmail字段
			this.emailForm = {
				...this.emailForm, // 使用展开操作符保留其他值，主要是senderEmail
				recipientEmail: '',
				subject: '',
				content: '',
				attachmentInfo: '',
				status: '',
			};
			this.attachments = []; // 清空附件列表
			this.$message.info('Form has been reset');
		},
		resetForm() {
			// 只重置特定的字段，保留senderEmail字段
			this.emailForm = {
				...this.emailForm, // 使用展开操作符保留其他值，主要是senderEmail
				recipientEmail: '',
				subject: '',
				content: '',
				attachmentInfo: '',
				status: '',
			};
			this.attachments = []; // 清空附件列表
		},
		
	},
	created() {
		// 在登录成功后，获取到localStorage中的用户的邮箱地址
		this.emailForm.senderEmail = localStorage.getItem('userEmail') || '';
	},
	// 获取到联系人的方法
	// 可以在获取到全部email列表之后，后面显示它所在的部门，或者他的个人信息，
	// 还可以查找email   √
	mounted() {
		this.axios.get('http://localhost:3759/email-web/get-email-list')
			.then(response => {
				// 假设后端直接返回了邮箱地址的数组
				// 将每个邮箱地址转换为el-select组件所需的对象格式
				this.recipients = response.data.map(email => {
					return { label: email, value: email };
				});
			})
			.catch(error => {
				console.error("Failed to fetch email addresses:", error);
				this.$message.error('Failed to load recipient emails');
			});
	},
  }
  </script>
  
  <style lang="less" scoped>
  .email-container{
	height: 650px; /* 根据你的内容多少调整，确保内容能够良好展示 */
  	overflow: auto; /* 如果内容超出指定高度，允许滚动 */
	 .topDiv {
	
	.email-page {
	  background-color: #fff;
	}
  
	.header {
	  display: flex;
	  justify-content: center;
	  align-items: center;
	  padding: 20px;
	  border-bottom: 1px solid #ebeef5;
  
	  .header-subject {
		font-size: 20px; 
		color: #333; 
		padding: 0 10px; 
	  }
	  
	  .close-button {
		position: absolute; 
		right: 20px; 
		top: 20px;
  
		i {
		  font-size: 1.2em;
		}
	  }
	}
  
	.email-form {
	  padding: 20px;
	}
  }
  }
 
  </style>
  
  