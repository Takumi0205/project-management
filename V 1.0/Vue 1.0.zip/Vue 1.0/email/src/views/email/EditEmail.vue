<template>
    <div class="email-container">
        <el-form :model="emailForm" ref="emailForm" label-width="100px" class="email-form">
            <el-button class="close-btn" @click="closeView">X</el-button>
            <h3 class="email-subject">Edit an email</h3>

            <!-- 邮件标题输入框 -->
            <el-form-item prop="subject" :rules="rules.subject">
                <el-input v-model="emailForm.subject" placeholder="Email subject" prefix-icon="el-icon-edit"></el-input>
            </el-form-item>
            <!-- 收件人选择框 -->
            <el-form-item prop="recipientEmail" :rules="rules.recipientEmail">
                <el-select v-model="emailForm.recipientEmail" filterable placeholder="Please select recipient">
                    <el-option v-for="item in recipients" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item prop="content">
                <el-input type="textarea" v-model="emailForm.content" placeholder="Email Content" rows="5">
                </el-input>
            </el-form-item>
            <el-form-item label="Attachments:">
                <el-upload class="upload-demo" action="http://localhost:3759/email-web/upload" multiple :on-success="handleUploadSuccess" :on-remove="handleRemoveAttachment" :file-list="attachments" list-type="text">
                    <el-button size="small" type="primary">Click to upload</el-button>
                    <div slot="tip" class="el-upload__tip">Files less than 2MB</div>
                </el-upload>
            </el-form-item>
            <el-form-item class="form-actions">
                <el-button type="primary" @click="saveDraft">Save as draft</el-button>
                <el-button type="success" @click="sendEmail">Send</el-button>
                <el-button type="default" @click="resetEmailForm">Reset</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>

<script>
export default {
    name: "EditEmail",
    data() {
        return {
            emailForm: {
                recipientEmail: '',
                senderEmail: localStorage.getItem('userEmail') || '',
                subject: '',
                content: '',
                attachmentInfo: [],
                status: '',
            },
            recipients: [],
            attachments: [],
            rules: {
                subject: [
				    { required: true, message: 'Please input the subject of the email', trigger: 'blur' }
                ],
                recipientEmail: [
                    { required: true, message: 'Please select a recipient', trigger: 'blur' }
                ],
            },
        };
    },
    mounted() {
        const emailId = this.$route.params.emailId;
        this.loadDraft(emailId);
        this.axios.get('http://localhost:3759/email-web/get-email-list')
			.then(response => {
				// 假设后端直接返回了邮箱地址的数组
				// 将每个邮箱地址转换为el-select组件所需的对象格式
				this.recipients = response.data.map(email => {
					return { label: email, value: email };
				});
			})
			.catch(error => {
				console.error("Failed to fetch email addresses:", error);
				this.$message.error('Failed to load recipient emails');
			});
    },
    methods: {
        loadDraft(emailId) {
            this.axios.get(`http://localhost:3759/email-web/emails/${emailId}`)
            .then((response) => {
                const { emailId, recipientEmail, subject, content, attachmentInfo } = response.data;
                this.emailForm.emailId = emailId;
                this.emailForm.recipientEmail = recipientEmail;
                this.emailForm.subject = subject;
                this.emailForm.content = content;
                // 假设附件信息以JSON字符串形式保存
                this.attachments = attachmentInfo ? JSON.parse(attachmentInfo) : [];
            })
            .catch(error => {
                console.error("Error loading draft:", error);
            });
        },
        handleUploadSuccess(response, file, fileList) {
            this.attachments.push({
                name: file.name,
                url: response.url, // Assuming your backend returns the URL for the uploaded file
            });
            this.emailForm.attachmentInfo = JSON.stringify(this.attachments);
        },
        handleRemoveAttachment(file, fileList) {
            this.attachments = fileList;
            this.emailForm.attachmentInfo = JSON.stringify(this.attachments);
        },
        saveDraft() {
			this.$refs.emailForm.validate((valid) => {
				if (valid) {
					// 将attachments数组转换为JSON字符串并存入emailForm.attachmentInfo
					this.emailForm.attachmentInfo = JSON.stringify(this.attachments);
					// 设置状态为草稿
					this.emailForm.status = 'draft';
					// 调用API保存草稿
					this.saveEmailFormData();
				} else{
					console.log('error draft!!');
				}
			});
		},
        saveEmailFormData() {
            this.axios.post('http://localhost:3759/email-web/updateDraft', {
                ...this.emailForm,
                emailId: this.$route.params.emailId, // 确保包含emailId
                attachmentInfo: JSON.stringify(this.attachments)
            })
            .then(response => {
                this.resetForm();
                this.$router.push({ name: 'Drafts' }); 
                this.$message.success('Draft updated successfully');
                // 可能需要更新视图或者做其他处理，例如跳转回草稿箱
            })
            .catch(error => {
                this.$message.error('Failed to update draft');
                console.error("Error updating draft:", error);
            });
        },

        sendEmail() {
			this.$refs.emailForm.validate((valid) => {
				if (valid) {
					// 如果验证通过
					// 将attachments数组转换为JSON字符串并存入emailForm.attachmentInfo
					this.emailForm.attachmentInfo = JSON.stringify(this.attachments);
					// 设置状态为已发送
					this.emailForm.status = 'sent';
					// 调用API发送邮件
					this.sendEmailFormData();
				} else {
					console.log('error submit!!');
				}
			});
		},
        sendEmailFormData() {
			// 调用API发送邮件
			this.axios.post('http://localhost:3759/email-web/sendDraft', {
                ...this.emailForm,
                emailId: this.$route.params.emailId, // 确保包含emailId
                attachmentInfo: JSON.stringify(this.attachments)
            })
			.then(response => {
				this.resetForm(); // 调用resetEmailForm来重置表单
                this.$router.push({ name: 'Drafts' }); 
				this.$message.success('Email sent successfully');
			})
			.catch(error => {
				// 如果发送失败，设置状态为 'failed'
				this.emailForm.status = 'failed';
				console.error(error); // 输出完整的错误信息
				if (error.response && error.response.data) {
					// 如果后端返回了具体的错误消息
					this.$message.error('Failed to send email: ' + error.response.data.message);
				} else {
					this.$message.error('Failed to send email');
				}
			});
	    },
        resetEmailForm() {
            this.emailForm = {
                recipientEmail: '',
                senderEmail: localStorage.getItem('userEmail') || '',
                subject: '',
                content: '',
                attachmentInfo: [],
                status: '',
            };
            this.attachments = [];
        },
        formatDate(date) {
            return this.$moment(date).format('YYYY-MM-DD'); // 格式化为您需要的格式
        },
        closeView() {
            this.$router.back();
        },
        resetForm() {
			// 只重置特定的字段，保留senderEmail字段
			this.emailForm = {
				...this.emailForm, // 使用展开操作符保留其他值，主要是senderEmail
				recipientEmail: '',
				subject: '',
				content: '',
				attachmentInfo: '',
				status: '',
			};
			this.attachments = []; // 清空附件列表
		},
    },

};
</script>

<style scoped>
.email-container {
    padding: 20px;
}
.form-actions {
    display: flex;
    justify-content: space-between;
}
.close-btn {
    position: absolute;
    right: 20px;
    top: 20px;
}
</style>
