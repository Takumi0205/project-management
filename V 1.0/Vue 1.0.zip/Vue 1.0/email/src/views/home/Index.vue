<!-- 系统首页 -->
<template>
    <div class="topDiv">
        <!-- 主体部分 -->
        <div class="body">
            <!--logo标题图片 -->
            <img class="title" src="../../assets/e1.png" alt="" />
            <!--第二排内容 -->
            <div class="awayMenu">
                <!--左侧 -->
                <div class="awayLeft">
                    <span class="manage2">
                        Welcome!
                        <!--用户名称 -->
                        <span>{{ name }}</span>
                    </span>
                    <!--登入地址 -->
                    <div class="manage">Login address: {{ location }}</div>
                </div>
                <!--时间，上下布局 -->
                <div class="bottom">
                    <!--年月日 -->
                    <span class="showtime">{{ showtime }}</span>
                    <!--时分 -->
                    <span class="showtime2">{{ showtime2 }}</span>
                </div>
            </div>
            <!--三层标题 -->
            <div class="bigTips">
                <span style="color:rgba(255,255,255,0.8)">Common modules</span>
                <span style=""> </span>
            </div>
            <!--常用按钮层 -->
            <div class="buttonMenu">
                <!--常用按钮盒子 -->
                <div class="addMenuBox">
                    <!--循环遍历按钮 -->
                    <div class="addMenu" v-for="item in addMenuTempList" :key="item.meta.title" @click="selectItem(item)">
                        {{ item.meta.title }}
                    </div>
                </div>
                <!--分隔线 -->
                <div class="shu"></div>
                <!--右侧3按钮 -->
                <div class="threeButton">
                    <!--按钮1 -->
                    <div class="button" @click="toDaiBanPage">
                        <div class="left">
                            <!--图片1 -->
                            <img class="homeThreeIcon" src="../../assets/homeIcon1.png" />
                            <!--内容1 -->
                            <span class="text">我的待办</span>
                        </div>
                    </div>
                    <!--按钮2 -->
                    <div class="button" @click="toFaQiPage">
                        <div class="left">
                            <!--图片2 -->
                            <img class="homeThreeIcon" src="../../assets/homeIcon1.png" />
                            <!--内容2 -->
                            <span class="text">我的未办</span>
                        </div>
                    </div>
                    <!--按钮3 -->
                    <div class="button" @click="toJingBanPage">
                        <div class="left">
                            <!--图片3 -->
                            <img class="homeThreeIcon" src="../../assets/homeIcon1.png" />
                            <!--内容3 -->
                            <span class="text">我的经办</span>
                        </div>
                    </div>
                </div>
            </div>
            <!--左下角提升语句，点击跳转盒子-->
            <div class="bottomText" @click="toOwnMenu">
                <!-- 添加"常用模块"? 点我 进入个人门户设置 -->
                Welcome to the email system!
            </div>
        </div>
    </div>
</template>

<script>

/* 引入菜单子组件 */
import MenuTree from '@/components/menu/MenuTree.vue'
// 引入标签导航栏
import TabNavBar from '@/components/tab/TabNavBar.vue'

    export default{
        name: "Index",
        components: {
            // 注册组件
            MenuTree: MenuTree,
            TabNavBar: TabNavBar,
        },
        data() {
        return {
            userInfo:[],
            location: "Local Test",
            // location: "company Intranet",
            addMenuTempList: [
                {
                    name: 'inbox',
                    path: 'inbox',
                    meta: {
                        title: 'Inbox',
                        icon: 'el-icon-folder-opened'
                    },
                    children: []
                },
                {
                    name: 'drafts',
                    path: 'drafts',
                    meta: {
                        title: 'Drafts',
                        icon: 'el-icon-folder-opened'
                    },
                    children: []
                },
                {
                    name: 'outbox',
                    path: 'outbox',
                    meta: {
                        title: 'Outbox',
                        icon: 'el-icon-folder-opened'
                    },
                    children: []
                },
                {
                    name: 'trashbox',
                    path: 'trashbox',
                    meta: {
                        title: 'Trash Box',
                        icon: 'el-icon-folder-opened'
                    },
                    children: []
                },
                {
                    name: 'sysUser',
                    path: 'sysUser',
                    meta: {
                        title: 'User Management',
                        icon: 'el-icon-folder-opened'
                    },
                    children: []
                },
                {
                    name: 'sendEmail',
                    path: 'sendEmail',
                    meta: {
                        title: 'Send Email',
                        icon: 'el-icon-folder-opened'
                    },
                    children: []
                },
            ],
            number1: 0,
            number2: 0,
            number3: 0,
            number1List: [],
            number2List: [],
            number3List: []
        };
    },

    methods: {
        init() {
            // this.getMyDoorListFx();
            let user = JSON.parse(Cookies.get("userInfo"));
            this.name = user.nickname;
            this.getNowTime();
            ipInfo().then((res) => {
                if (res.success) {
                    this.location = res.result;
                }
            });
            this.timer = setInterval(this.getNowTime, 1000);
        },
        selectItem(item) {
            if (item.name) {
                this.$router.push({ path: item.name });
                // 先获取一下导航表要是有当前点击的,那么直接跳转到就可以
                // 如果没有,就像下面的代码,直接在导航栏添加.
                this.$store.commit('addTab',item);
            }
        },
        toDaiBanPage() {
            this.$Message.success("正在开发，敬请期待！");
        },
        toFaQiPage() {
            this.$Message.success("正在开发，敬请期待！");
        },
        toJingBanPage() {
            this.$Message.success("正在开发，敬请期待！");
        },
        toOwnMenu() {
            this.$router.push("/myHome");
        },
        // getMyDoorListFx() {
        //     var that = this;
        //     getMyDoorList6().then((res) => {
        //         that.addMenuTempList = res.result;
        //     });
        // },
        getNowTime() {
            this.showtime = this.format(new Date(), "yyyy年MM月dd日");
            this.showtime2 = this.format(new Date(), "HH:mm:dd");
        },
    },
    mounted() {
        this.init();
        this.clientHeight = `${document.documentElement.clientHeight}`;
        let that = this;
        window.onresize = function () {
            this.clientHeight = `${document.documentElement.clientHeight}`;
            if (that.$refs.page) {
                that.$refs.page.style.minHeight = clientHeight - 100 + "px";
            }
        };
    },
    watch: {
        clientHeight() {
            this.changeFixed(this.clientHeight);
        },
    },
    }
</script>

<style lang="less" scoped>
.body {
    // height: 76vh;
    height: 650px;
    /* width: 98%; */
    max-width: 100vw; /* 最大宽度不超过视口宽度 */
    /* height: 100%; */
    display: flex;
    flex-direction: column;
    padding: 0 45px;
    align-items: center;
    border-radius: 4px;
    /* background-color: #fff; */
    /* margin: 5px 16px; */
    color: #000;
    /* width:100%; */
    background-repeat: no-repeat;
    background-size: cover;
    background-position:center center;
    /* background-image:  ;*/
    background-color: #824c06;
    overflow: auto;
}
.ivu-tooltip {
    width: 100% !important;
}

.margin {
    margin-bottom: 20px;
}

.awayLeft {
    width: 60%;
    display: flex;
    align-items: center;
}

.bottom {
    width: 30%;
    margin-left: 10%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

.title {
    /* width: 15%; */

    margin: 5vh 0;
    max-height: 80px;
}

.awayMenu {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.manage {
    width: 40%;
    height: 100%;
    font-family: Microsoft YaHei;
    font-size: 20px;
    display: flex;
    align-items: center;
    color: rgb(255, 255, 255, 0.7);
}

.manage2 {
    width: 60%;
    height: 100%;
    font-size: 28px;
    display: flex;
    align-items: center;
    color: rgb(255, 255, 255, 0.7);
}

.buttonMenu {
    width: 100%;
    display: flex;
}

.bigTips {
    width: 100%;
    display: flex;
    justify-content: left;
    align-items: center;
    margin-top: 3vh;
    margin-bottom: 3vh;
    font-size: 20px;
}

.addMenuBox {
    width: 50%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    flex-wrap: wrap;  /* 允许内容换行 */

    .addMenu {
        width: 45%;
        height: 24%;
        margin: 2% 2.5%;
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #ffffff66;
        border-radius: 10px;
        color: #fff;
        font-size: 20px;
        cursor: pointer;
        
        /* 让鼠标悬停时改变背景颜色 */
        &:hover {
            background-color:#f3dab1;
            color: #824c06;
        }
    }
}

.addMenu :nth-child(5) {
    margin-bottom: 0;
}

.addMenu :nth-child(6) {
    margin-bottom: 0;
}

.shu {
    width: 0.2%;
    margin: 0 9.9%;
    background-color: #4c4c4c;
}

.threeButton {
    width: 30%;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
}

.showtime {
    font-family: Microsoft YaHei;
    font-size: 22px;
    letter-spacing: 1px;
    color: rgb(255, 255, 255);
    font-weight: 100;
    text-align: center;
}

.showtime2 {
    font-family: Microsoft YaHei;
    font-size: 26px;
    font-weight: 500;
    letter-spacing: 1px;
    color: rgb(255, 255, 255);
    text-align: center;
}

.homeThreeIcon {
    opacity: 1;
    height: 25px;
    width: 25px;
    margin-right: 10%;
}

.button {
    width: 60%;
    height: 28%;
    min-width: 310px;
    max-width: 860px;
    max-height: 80px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: rgba(255, 255, 255, 0.3);
    border-radius: 10px;
    padding: 20px;
    margin: 0 auto;
    z-index: 99;

    .left {
        width: 60%;
        min-width: 150;
        display: flex;
        align-items: center;
    }

    .text {
        color: #fff;
        font-size: 20px;
        position: relative;
    }

    .shu {
        width: 1px !important;
        height: 100%;
        max-height: 35px;
        background-color: #fff;
    }

    .number {
        font-size: 22px;
        color: #fff;
    }
}

.bottomText {
    opacity: 0.7;
    width: 100%;
    margin-top: 7vh;
    text-align: left;
    font-size: 16px;
    color: #e6e6e6;
    text-decoration: underline;
}

.textBox {
    width: 800px;
    display: flex;
    flex-direction: column;
    align-items: left;
    padding: 0 10%;

    .text {
        font-size: 16px;
        margin: 3px 0;
        border-bottom: 1px solid #777;

        .one {
            display: flex;
            align-items: center;

            .xuhao {
                width: 20%;
                min-width: 50px;
                background-color: #ff9900;
                border: 1px solid #ff9900;
                display: flex;
                justify-content: center;
                align-items: center;
                border-radius: 5px;
                padding: 3px;
                margin-right: 8px;
            }

            .floar {
                width: 85%;
                display: flex;
                justify-content: center;
                font-size: 16px;
                font-family: "Fantasy";
                font-weight: 500;
                margin-right: 30px;
            }
        }

        .two {
            display: flex;
            margin: 5px 0;
            align-items: center;
            justify-content: space-between;

            .twoItem {
                width: 35%;
                font-size: 12px;
            }

            .twoItem2 {
                width: 65%;
                display: flex;
                justify-content: center;
                font-size: 12px;

            }
        }
    }
}
</style>