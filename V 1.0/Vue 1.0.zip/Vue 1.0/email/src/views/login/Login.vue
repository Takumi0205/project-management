<template>
    <div>
        <body id="poster">
            <el-form :model="loginForm" :rules="rules" ref="loginForm" class="login-container" label-position="left" label-width="0px">
                <h3 class="login_title">
                    Account Login
                </h3>
                <el-form-item label="" prop="email">
                    <el-input type="email" v-model="loginForm.email" autocomplete="off" placeholder="email"></el-input>
                </el-form-item>
                <el-form-item label="" prop="password">
                    <el-input type="password" v-model="loginForm.password" autocomplete="off" placeholder="password"></el-input>
                </el-form-item>
                <el-form-item style="width: 100%;">
                    <el-button type="primary" v-on:click="Login()" style="width: 100%;">Login</el-button>        
                </el-form-item>
                <el-form-item style="width: 100%;"> 
                    <el-button type="primary" @click="toRegister()" style="width: 100%;">Register</el-button>
                </el-form-item>
            </el-form>
        </body>
    </div>
  </template>
  
  <script>
    export default {
        name: 'Login',
        data() {
            var checkEmail = (rule, value, callback) => {
                if (!value) {
                    return callback(new Error('Email cannot be empty'));
                }
                const emailPattern = /^[a-zA-Z0-9._-]+@taku.com$/;
                if (!emailPattern.test(value)) {
                    return callback(new Error('Please enter a valid @taku.com email address'));
                }
                callback();
            };
            var validatePass = (rule, value, callback) => {
                if (value === '') {
                    callback(new Error('Please enter password'));
                } else {
                    callback();
                }
            };
            return {
                loginForm: {
                    email: '',
                    password: ''
                },
                rules: {
                    password: [
                        { validator: validatePass, trigger: 'blur' },
                        { min: 8, max: 15, message:"Warm reminder: the password length is 8-15 characters", trigger: 'blur'}
                    ],
                    email: [
                        { validator: checkEmail, trigger: 'blur' },
                        { min: 14, max: 28, message:"Warm reminder: The length of the email is 5-19 characters.", trigger: 'blur'}
                    ],
                }
            }
        },
        methods: {
            Login() {
                // 先进行表单验证
                this.$refs.loginForm.validate((valid) => {
                    if (valid) {
                        // 如果表单验证通过，则发送登录请求
                        this.axios.post('http://localhost:3759/email-web/login', this.loginForm).then((response) => {
                            const data = response.data;
                            // 检查后端返回的success字段
                            if (data.success) {
                                // 登录成功逻辑
                                const expirationDuration = 3600000; // 1小时 = 3600000毫秒
                                const expirationTime = new Date().getTime() + expirationDuration;
                                localStorage.setItem('userEmail', this.loginForm.email);// 或者从响应数据中获取，如果服务器返回了email
                                localStorage.setItem("expirationTime", expirationTime.toString());
                                this.$message.success('Log in successfully');
                                this.$router.push({ path: '/Home' });
                            } else {
                                // 登录失败逻辑
                                this.$message.error(data.message || 'Login failed');
                            }
                        }).catch((error) => {
                            // 注意：此处可能捕获到的是网络错误等，而非后端业务逻辑错误
                            console.error('Login request failed', error);
                            // 检查error.response是否存在，以及是否有后端返回的错误信息
                            if (error.response && error.response.data && error.response.data.message) {
                                this.$message.error('Login failed: ' + error.response.data.message);
                            } else {
                                this.$message.error('Login request failed');
                            }
                        });
                    } else {
                        console.log('Validation failed!');
                    }
                });
            },
            toRegister(){
                this.$router.push({path:'/Register'})
            },
        }
    }
  </script>
  <style>
    #poster{
        background-position:center;
        height:100%;
        width:100%;
        background-size: cover;
        position: fixed;
    }
    body{
        margin: 0px;
        padding: 0px;
    }
    .login-container{
        border-radius: 10px;
        background-clip: padding-box;
        margin: 90px auto;
        width: 350px;
        padding: 35px 35px 35px 35px;
        background: #fff;
        border: 1px solid #eaeaea;
        box-shadow: 0 0 25px #cac6c6;
    }
    .login_title{
        margin: 0px auto 40px auto;
        text-align: center;
        color: #505458;
    }
    .login-container .el-button{
        background: #505458 ;
        border: none;
    }
    .login-container .el-button:hover{
        color:#505458;
        background-color: #dadada;
    }
    /* 为了解决在点击submit按钮后变为蓝色 */
    .login-container .el-button:focus {
        background: #505458; /* 按钮原本的背景颜色 */
        color: #FFFFFF; /* 按钮原本的文字颜色 */
        border-color: #505458; /* 如果有边框，指定边框颜色 */
    }
  </style>