import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  //数据，相当于data
  // 使用方法 this.$store.state.全局数据名称
  state: {
    // 	当前激活菜单的页面是哪一个
    activeMenu: 'index',
    /* tab标签绑定值，选中选项卡的 name */
    editableTabsValue: 'index',
     /* tab标签选项卡内容 */
        editableTabs: [
          /* 初始内容 */
          {
            title: 'Home',
            name: 'index',
            content: 'home page',
            icon: 'el-icon-menu'
          }
        ],
  },
  // 定义方法，用以操作state
  // 注意：使用commit触发Mutation操作
  // 如：this.$store.commit("mutations中定义的方法名",参数)
  mutations: {
    /* 动态添加tab标签 */
    addTab(state,item) {
      const newTab = {
        title: item.meta.title,
        name: item.path,
        content: item.meta.title,
        icon: item.meta.icon
      };
      // 判断当前editableTabs中是否存在该tab标签,
      // 判断title和标签的名字有没有相同的，等于-1表示没有相同的
      if(state.editableTabs.findIndex(item => item.title === newTab.title)==-1) {
        state.editableTabs.push(newTab);
        state.editableTabsValue = newTab.name;
        state.activeMenu = newTab.name;

        /* 将tab标签列表和tab标签绑定值以及当前激活的菜单存储到sessionStoage，防止页面刷新丢失 */
        sessionStorage.setItem('activeMenu',state.activeMenu);
        sessionStorage.setItem('editableTabsValue',state.editableTabsValue);
        sessionStorage.setItem('editableTabs',JSON.stringify(state.editableTabs));
        // 
      }
    },
    /* 移除tab标签 */
    removeTab(state,targetName) {
      let tabs = state.editableTabs;
      let activeName = state.editableTabsValue;
      if (activeName === targetName) {
        tabs.forEach((tab, index) => {
          if (tab.name === targetName) {
            let nextTab = tabs[index + 1] || tabs[index - 1];
            if (nextTab) {
              activeName = nextTab.name;
            }
          }
        });
      }
      
      state.activeMenu = activeName;
      state.editableTabsValue = activeName;
      state.editableTabs = tabs.filter(tab => tab.name !== targetName);
      /* 将tab标签列表和tab标签绑定值以及当前激活的菜单存储到sessionStoage，防止页面刷新丢失 */
      sessionStorage.setItem('activeMenu',state.activeMenu);
      sessionStorage.setItem('editableTabsValue',state.editableTabsValue);
      sessionStorage.setItem('editableTabs',JSON.stringify(state.editableTabs));
    },
    /* 重置状态方法 */
    /* 为了在用户退出时，再登录的activeMenu不出错 */
    RESET_STATE(state) {
      // 重置状态
      state.activeMenu = 'index'; // 或其他初始值
      state.editableTabsValue = 'index'; // 重置为首页
      state.editableTabs = [{
        title: 'Home',
        name: 'index',
        content: 'home page',
        icon: 'el-icon-menu'
      }]; // 重置为只含首页的数组
      // 清除sessionStorage中的相关数据
      sessionStorage.removeItem('activeMenu');
      sessionStorage.removeItem('editableTabsValue');
      sessionStorage.removeItem('editableTabs');
    },
    // 当认证过期了重置方法
    RESET_STATE_EXPIRED(state) {
      // 重置状态
      state.activeMenu = sessionStorage.getItem('activeMenu'); // 或其他初始值
      state.editableTabsValue = sessionStorage.getItem('editableTabsValue'); // 重置为首页
    },
  },
  // 定义方法，使用异步操作
  // Action和Mutation相似，Mutation 不能进行异步操作，若要进行异步操作，就得使用Action
  // 直接使用  dispatch触发Action函数 :this.$store.dispatch("方法名",参数)
  actions: {

  },
  // 当遇见大型项目时，数据量大，store就会显得很臃肿
  // 为了解决以上问题，Vuex 允许我们将 store 分割成模块（module）。
  // 每个模块拥有自己的 state、mutation、action、getter、甚至是嵌套子模块——
  // 从上至下进行同样方式的分割
  modules: {

  }
})