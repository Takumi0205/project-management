<!-- 菜单内容组件 -->
<template>
    <div>
        <!-- 遍历菜单列表 -->
        <template v-for="item in menuList">
            <el-submenu :key="'submenu-' + item.id" :index="item.id+''" v-if="item.children.length>0">
                <template slot="title">
                    <i :class="item.meta.icon"></i>
                    <span slot="title">{{item.meta.title}}</span>
                </template>
                <!-- 菜单下面还有子项的话也要传入进来 -->
                <MenuTree :menuList="item.children"></MenuTree>
            </el-submenu>
            <el-menu-item v-else :key="'menuitem-' + item.id" :index="item.path+''" @click="addTab(item)">
                <i :class="item.meta.icon"></i>
                <span slot="title">{{item.meta.title}}</span>
            </el-menu-item>
        </template>
    </div>
</template>
<script>
export default {
    name: 'MenuTree',
    props: ["menuList"],
    methods:{
        /* 添加导航标签  */
        addTab(item) {
            this.$store.commit('addTab',item)
        }
    },
}
</script>
<style scoped>
/*实现了一个溢出处理*/
.el-menu--collapse span,
.el-menu--collapse i.el-submenu__icon-arrow {
    height: 0;
    width: 0;
    overflow: hidden;
    visibility: hidden;
    display: inline-block;
    }
</style> 