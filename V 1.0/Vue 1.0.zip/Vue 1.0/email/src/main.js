import Vue from 'vue'
import App from './App.vue'
import router from './router'
// 引入vuex
import store from './store'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import axios from 'axios'
import VueAxios from 'vue-axios'
// 解决文字溢出
import Fragment from 'vue-fragment'

// 为了解决这个date不显示的问题
import moment from 'moment';
// 这个是为了让邮件信息框有各种形式
import Vue2Editor from "vue2-editor";

Vue.use(Vue2Editor);
Vue.use(Fragment.Plugin)
Vue.config.productionTip = false
Vue.use(ElementUI);
Vue.use( VueAxios , axios)

// 将moment添加到Vue的原型上，使其在所有组件中可用
Vue.prototype.$moment = moment;

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
