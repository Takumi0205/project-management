select * from login;
select * from user_register;
select * from merchant_register;
DELETE FROM user_register WHERE password='';
set sql_safe_updates = 0;
delete from user_register;
ALTER TABLE user_register ADD type varchar(10);
ALTER TABLE merchant_register ADD type varchar(10);
ALTER TABLE login ADD type varchar(10);
insert into user_register value('user','123456','sichuan','123@qq.com',123456789,"user");
insert into login value('user','123456','user');
delete from login where (type='user');
delete from login;

alter table user_register modify column password varchar(1000);
alter table merchant_register modify column password varchar(1000);
alter table login modify column password varchar(1000);

DELETE FROM merchant_register WHERE password='';

delete from goods;
update merchant_store set store_name = 'kkkk', head_p = '1', phone_number = '12359685555' ,email = '1151236@qq.com' ,address = 'heihe' where merchant_ID ='test2';
update merchant_register set address = 'aa' where merchant_ID = 'test1' and password = '1';
insert into merchant_register value('test1','123456','sichuan','123@qq.com',123456789,'merchant');
update merchant_store set store_name = 'kkkk', head_p = '1', phone_number = '12359685555' ,email = '1151236@qq.com' ,address = 'heihe' where merchant_ID ='test2';

select * from classifyGoods  where classify_ID= 1 ORDER BY update_time DESC;
delete from classifyGoods where (goods_ID ='test3');
alter table goods drop primary key;

update merchant_store set head_p = 'logo3.jpg' where merchant_ID = 'test2';

ALTER TABLE user_orders DROP COLUMN user_like_go;
delete from user_like_go where (goods_ID ='test');
ALTER TABLE goods_comment DROP COLUMN picture4;
ALTER TABLE goods_comment change picture1 picture varchar(120);

delete from goods_comment where (user_ID ='user5');
update login set password = '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92' where password = '123456';
