package com.takumi.emailback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailbackApplicationTests {

    @Test
    void contextLoads() {
    }

}
