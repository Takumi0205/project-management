package com.takumi.emailback.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

@TableName("email_recipients")
public class EmailRecsEntity {
    @TableId("id")
    private Long id;
    private String emailId;
    private String recipientEmail;

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRecipientEmail() {
        return recipientEmail;
    }

    public void setRecipientEmail(String recipientEmail) {
        this.recipientEmail = recipientEmail;
    }

    @Override
    public String toString() {
        return "EmailRecsEntity{" +
                "id=" + id +
                ", emailId='" + emailId + '\'' +
                ", recipientEmail='" + recipientEmail + '\'' +
                '}';
    }
}
