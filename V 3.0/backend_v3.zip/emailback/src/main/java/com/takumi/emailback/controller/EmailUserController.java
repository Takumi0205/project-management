package com.takumi.emailback.controller;


import com.takumi.emailback.req.EmailUserReq;
import com.takumi.emailback.resp.CommonResp;
import com.takumi.emailback.service.EmailUserService;
import jakarta.annotation.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.File;

@RestController
@RequestMapping("/email-web")
public class EmailUserController {

    @Resource
    private EmailUserService emailUserService;

    @GetMapping("/sysUser/{userEmail}")
    public ResponseEntity<EmailUserReq> getUserInfo(@PathVariable String userEmail) {
//        System.out.println("The method is run");
        EmailUserReq userInfo = emailUserService.getUserByEmail(userEmail);

        if (userInfo != null) {
            return ResponseEntity.ok(userInfo);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // 保存用户修改的内容
    @PostMapping("/sysUser/update")
    public ResponseEntity<Object> updateUser(@RequestBody EmailUserReq userReq) {
        // 调用服务层方法来更新用户信息
        boolean updateResult = emailUserService.updateUser(userReq);
        if (updateResult) {
            return ResponseEntity.ok().body("User information updated successfully");
        } else {
            return ResponseEntity.badRequest().body("Failed to update user information");
        }
    }


    //上传头像
    @PostMapping("/upload/avatar")
    public ResponseEntity<CommonResp<Object>> uploadUserAvatar(@RequestParam("file") MultipartFile file) {
        CommonResp<Object> resp = new CommonResp<>();
        // 看前端传入的附件是否为空
        if (file.isEmpty()) {
            resp.setSuccess(false);
            resp.setMessage("File is empty");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resp);
        }
        // 如果不是空
        try {
            String originalFileName = file.getOriginalFilename(); //得到文件上传时的原本名字
            //从上传文件的原始文件名中提取文件的扩展名
            //就是一直取到.前面的内容,例如example.jepg,就是返回6,索引从0开始
            //然后使用substring,从.开始取,就是取到了.jepg
            //所以扩展名为.jepg
            String fileExtension = originalFileName.substring(originalFileName.lastIndexOf("."));
            // 然后使用当前时间戳作为UID(uniqueID)
            String uniqueID = String.valueOf(System.currentTimeMillis());
            // 设置名字为UID+原本的扩展名
            String uniqueFileName = uniqueID + fileExtension;
            String destinationFilePath = "D:\\project\\MySpringBootProject\\avatars\\" + uniqueFileName;

            // 将文件保存到服务器
            File destinationFile = new File(destinationFilePath);

            //调用transferTo方法时，如果目标文件所在目录不存在，则会自动创建这个目录，然后文件被写入到这个位置。
            // 这个过程可能抛出异常（如文件写入失败），因此它被包裹在一个try-catch块中，以便于异常处理。
            file.transferTo(destinationFile);

            // 构建并返回文件的可访问URL
            // ServletUriComponentsBuilder.fromCurrentContextPath()这个方法获取当前应用的基础URL（即上下文路径）。
            // 即http://localhost:3759/email-web/upload
            // 然后还需要添加一个路径来打开文件,.path("/files/") 这一步就是在基础URL后添加一个路径/files/。
            String avatarUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                    .path("/avatars/") //file:/D:/project/MySpringBootProject/uploads/
                    .path(uniqueFileName)
                    .toUriString();//合并成一个完整的URI字符串

            // 这里可以更新数据库，保存originalFileName, uniqueFileName等信息
            //[{"status":"success","name":"logo2.jpg","size":17464,"percentage":100,"uid":1710825956878,"raw":{"uid":1710825956878},
            // "response":{"success":true,"message":"File uploaded successfully: 1710825957101.jpg","content":"http://localhost:3759/files/1710825957101.jpg"}}]
            resp.setSuccess(true);
            resp.setMessage(uniqueID);
            resp.setContent(avatarUrl); // 设置响应内容为文件访问URL
            return ResponseEntity.ok(resp);

        } catch (Exception e) {
            resp.setSuccess(false);
            resp.setMessage("File upload failed: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    // 假设这是直接更新数据库的方法，调整为只保存文件名或相对路径
    // 假定的上传头像并更新数据库的方法




}
