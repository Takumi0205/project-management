package com.takumi.emailback.utils;

import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;


//CopyUtil类是一个工具类，它的主要作用是在不同的Java对象之间复制属性。
// 这在处理层之间传递数据时非常有用，尤其是在需要从数据传输对象（DTOs）复制到实体对象（Entities）或反之时。
//这样的需求在Web应用中很常见，因为通常情况下，您不会直接将从数据库检索到的实体对象暴露给前端，而是会先将实体对象的数据复制到DTO中，再将DTO返回给前端.
public class CopyUtil {

    /**
     * 单体复制
     */
    public static <T> T copy(Object source, Class<T> clazz) {
        if (source == null) {
            return null;
        }
        T obj = null;
        try {
            obj = clazz.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        BeanUtils.copyProperties(source, obj);
        return obj;
    }

    /**
     * 列表复制
     */
    public static <T> List<T> copyList(List source, Class<T> clazz) {
        List<T> target = new ArrayList<>();
        if (!CollectionUtils.isEmpty(source)){
            for (Object c: source) {
                T obj = copy(c, clazz);
                target.add(obj);
            }
        }
        return target;
    }
}