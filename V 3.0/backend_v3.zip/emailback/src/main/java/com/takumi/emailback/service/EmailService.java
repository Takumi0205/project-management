package com.takumi.emailback.service;

import com.takumi.emailback.req.EmailLoginReq;
import com.takumi.emailback.req.EmailSaveReq;
import com.takumi.emailback.resp.EmailLoginResp;

public interface EmailService {

    boolean register(EmailSaveReq req);

    EmailLoginResp login(EmailLoginReq req);
}
