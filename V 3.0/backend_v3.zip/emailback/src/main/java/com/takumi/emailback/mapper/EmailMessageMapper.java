package com.takumi.emailback.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.takumi.emailback.entity.EmailMessageEntity;
import org.apache.ibatis.annotations.*;

@Mapper
public interface EmailMessageMapper extends BaseMapper<EmailMessageEntity> {
    @Select("SELECT * FROM email_message WHERE email_id = #{emailId}")
    EmailMessageEntity getEmailById(@Param("emailId") Long emailId);



    @Update("UPDATE email_message SET sender_email=#{senderEmail}, recipient_email=#{recipientEmail}, subject=#{subject}, content=#{content}, attachment_info=#{attachmentInfo}, status=#{status}, is_read=#{isRead}, update_time=#{updateTime}, sender_deleted=#{senderDeleted}, recipient_deleted=#{recipientDeleted}, confirm_sender_deleted=#{confirmSenderDeleted}, confirm_recipient_deleted=#{confirmRecipientDeleted} , recipients=#{recipients} } WHERE email_id=#{emailId}")
    void updateDraft(EmailMessageEntity draft);


}
