package com.takumi.emailback.controller;


import com.takumi.emailback.req.EmailMessageSaveReq;
import com.takumi.emailback.resp.CommonResp;
import com.takumi.emailback.service.EmailMessageService;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
@RequestMapping("/email-web")
public class EmailMessageController {
    @Resource
    private EmailMessageService emailMessageService;

    @PostMapping("/send")
    public ResponseEntity<CommonResp<Object>> sendEmail(@RequestBody EmailMessageSaveReq req) {
        CommonResp<Object> resp = new CommonResp<>();
        try {
            boolean isSent = emailMessageService.sendMessage(req);
            if (isSent) {
                resp.setMessage("Email sent successfully");
                return ResponseEntity.ok(resp);
            } else {
                resp.setSuccess(false);
                resp.setMessage("Email send failed due to [具体原因]"); // 请替换[具体原因]为实际失败的原因
                return ResponseEntity.badRequest().body(resp);
            }
        } catch (Exception e) {
            resp.setSuccess(false);
            resp.setMessage("Email send failed: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    @GetMapping("/get-email-list")
    public ResponseEntity<List<String>> getEmailAddresses() {
        List<String> emails = emailMessageService.getAllEmailAddresses();
        return ResponseEntity.ok(emails);
    }

//    邮件保存为草稿
    @PostMapping("/saveDraft")
    public ResponseEntity<CommonResp<Object>> saveDraft(@RequestBody EmailMessageSaveReq req) {
        CommonResp<Object> resp = new CommonResp<>();
        try {
            boolean draftSaved = emailMessageService.saveDraft(req);
            if (draftSaved) {
                resp.setMessage("Draft saved successfully");
                return ResponseEntity.ok(resp);
            } else {
                resp.setSuccess(false);
                resp.setMessage("Failed to save draft");
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
            }
        } catch (Exception e) {
            // 特定的异常处理逻辑
            resp.setSuccess(false);
            resp.setMessage("An error occurred while saving the draft: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }


    @PostMapping("/upload")
    public ResponseEntity<CommonResp<Object>> uploadAttachment(@RequestParam("file") MultipartFile file) {
        CommonResp<Object> resp = new CommonResp<>();
        // 看前端传入的附件是否为空
        if (file.isEmpty()) {
            resp.setSuccess(false);
            resp.setMessage("File is empty");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resp);
        }
        // 如果不是空
        try {
            String originalFileName = file.getOriginalFilename(); //得到文件上传时的原本名字
            //从上传文件的原始文件名中提取文件的扩展名
            //就是一直取到.前面的内容,例如example.jepg,就是返回6,索引从0开始
            //然后使用substring,从.开始取,就是取到了.jepg
            //所以扩展名为.jepg
            String fileExtension = originalFileName.substring(originalFileName.lastIndexOf("."));
            // 然后使用当前时间戳作为UID(uniqueID)
            String uniqueID = String.valueOf(System.currentTimeMillis());
            // 设置名字为UID+原本的扩展名
            String uniqueFileName = uniqueID + fileExtension;
            String destinationFilePath = "D:\\project\\MySpringBootProject\\uploads\\" + uniqueFileName;

            // 将文件保存到服务器
            File destinationFile = new File(destinationFilePath);

            //调用transferTo方法时，如果目标文件所在目录不存在，则会自动创建这个目录，然后文件被写入到这个位置。
            // 这个过程可能抛出异常（如文件写入失败），因此它被包裹在一个try-catch块中，以便于异常处理。
            file.transferTo(destinationFile);

            // 构建并返回文件的可访问URL
            // ServletUriComponentsBuilder.fromCurrentContextPath()这个方法获取当前应用的基础URL（即上下文路径）。
            // 即http://localhost:3759/email-web/upload
            // 然后还需要添加一个路径来打开文件,.path("/files/") 这一步就是在基础URL后添加一个路径/files/。
            String fileUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                    .path("/files/") //file:/D:/project/MySpringBootProject/uploads/
                    .path(uniqueFileName)
                    .toUriString();//合并成一个完整的URI字符串

            // 这里可以更新数据库，保存originalFileName, uniqueFileName等信息
            //[{"status":"success","name":"logo2.jpg","size":17464,"percentage":100,"uid":1710825956878,"raw":{"uid":1710825956878},
            // "response":{"success":true,"message":"File uploaded successfully: 1710825957101.jpg","content":"http://localhost:3759/files/1710825957101.jpg"}}]
            resp.setSuccess(true);
            resp.setMessage("File uploaded successfully: " + uniqueFileName);
            resp.setContent(fileUrl); // 设置响应内容为文件访问URL
            return ResponseEntity.ok(resp);

        } catch (Exception e) {
            resp.setSuccess(false);
            resp.setMessage("File upload failed: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

    @GetMapping("/inbox")
    public ResponseEntity<List<EmailMessageSaveReq>> getEmailsForCurrentRecipient(@RequestParam("email") String recipientEmail) {
        // 使用 emailMessageService 中的 getEmailsForRecipient 方法根据收件人邮箱获取邮件列表
        List<EmailMessageSaveReq> emails = emailMessageService.getEmailsForRecipient(recipientEmail);
        // 遍历emails列表，输出每个邮件的emailId
//        emails.forEach(email -> System.out.println("Email ID: " + email.getEmailId()));
        // 检查返回的邮件列表是否为空
        if (emails.isEmpty()) {
            // 如果邮件列表为空，返回 404 Not Found 状态码
            return ResponseEntity.notFound().build();
        } else {
            // 如果邮件列表不为空，返回邮件列表和 200 OK 状态码
            return ResponseEntity.ok(emails);
        }
    }

    @GetMapping("/emails/{emailId}")
    public ResponseEntity<EmailMessageSaveReq> getEmailDetails(@PathVariable Long emailId, @RequestParam(defaultValue = "false") boolean fromInbox) {
//        EmailMessageSaveReq emailDetails = emailMessageService.getEmailById(emailId);
        EmailMessageSaveReq emailDetails = emailMessageService.getEmailById(emailId, fromInbox);
        if (emailDetails == null) {
            // 如果找不到邮件，返回404 Not Found
            return ResponseEntity.notFound().build();
        }
        // 如果找到了邮件，返回邮件详情和200 OK
        return ResponseEntity.ok(emailDetails);
    }

    //获取到草稿箱的全部内容
    @GetMapping("/drafts")
    public ResponseEntity<List<EmailMessageSaveReq>> getDrafts(@RequestParam("email") String userEmail) {
        List<EmailMessageSaveReq> drafts = emailMessageService.getDraftsForUser(userEmail);
        // 遍历emails列表，输出每个邮件的emailId
//        drafts.forEach(email -> System.out.println("update time: " + email.getUpdateTime()));
        if (drafts.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            return ResponseEntity.ok(drafts);
        }
    }


//更新草稿
    @PostMapping("/updateDraft")
    public ResponseEntity<CommonResp<Object>> updateDraft(@RequestBody EmailMessageSaveReq req) {
        CommonResp<Object> resp = new CommonResp<>();
        boolean success = emailMessageService.updateDraft(req);
        if (success) {
            resp.setMessage("Draft updated successfully");
            return ResponseEntity.ok(resp);
        } else {
            resp.setSuccess(false);
            resp.setMessage("Failed to update draft");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }

//    发送草稿的邮件
    @PostMapping("/sendDraft")
    public ResponseEntity<CommonResp<Object>> sendDraft(@RequestBody EmailMessageSaveReq req) {
        CommonResp<Object> resp = new CommonResp<>();
        boolean success = emailMessageService.sendDraft(req);
        if (success) {
            resp.setMessage("Email sent successfully");
            return ResponseEntity.ok(resp);
        } else {
            resp.setSuccess(false);
            resp.setMessage("Failed to send email");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }


//    发件箱
    @GetMapping("/outbox")
    public ResponseEntity<List<EmailMessageSaveReq>> getEmailsForOutbox(@RequestParam("email") String userEmail) {
        // 使用 emailMessageService 中的 getEmailsForRecipient 方法根据收件人邮箱获取邮件列表
        List<EmailMessageSaveReq> emails = emailMessageService.getEmailsForOutbox(userEmail);
        // 遍历emails列表，输出每个邮件的emailId
    //        emails.forEach(email -> System.out.println("Email ID: " + email.getEmailId()));
        // 检查返回的邮件列表是否为空
        if (emails.isEmpty()) {
            // 如果邮件列表为空，返回 404 Not Found 状态码
            return ResponseEntity.notFound().build();
        } else {
            // 如果邮件列表不为空，返回邮件列表和 200 OK 状态码
            return ResponseEntity.ok(emails);
        }
    }

//    垃圾箱的邮件获取
    @GetMapping("/trashbox")
    public ResponseEntity<List<EmailMessageSaveReq>> getEmailsForTrashbox(@RequestParam("email") String userEmail) {
        // 使用 emailMessageService 中的 getEmailsForRecipient 方法根据收件人邮箱获取邮件列表
        List<EmailMessageSaveReq> emails = emailMessageService.getEmailsForTrashbox(userEmail);
        // 遍历emails列表，输出每个邮件的emailId
        //        emails.forEach(email -> System.out.println("Email ID: " + email.getEmailId()));
        // 检查返回的邮件列表是否为空
        if (emails.isEmpty()) {
            // 如果邮件列表为空，返回 404 Not Found 状态码
            return ResponseEntity.notFound().build();
        } else {
            // 如果邮件列表不为空，返回邮件列表和 200 OK 状态码
            return ResponseEntity.ok(emails);
        }
    }

//    从草稿箱中删除邮件
    @DeleteMapping("/drafts/{emailId}")
    public ResponseEntity<Void> deleteDraft(@PathVariable Long emailId) {
        boolean success = emailMessageService.deleteDraft(emailId);
        if (success) {
            return ResponseEntity.ok().build(); // 删除成功
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // 删除失败
        }
    }

    //    从收件箱中删除邮件
    @DeleteMapping("/inbox/{emailId}")
    public ResponseEntity<Void> deleteInboxEmail(@PathVariable Long emailId) {
        boolean success = emailMessageService.deleteInboxEmail(emailId);
        if (success) {
            return ResponseEntity.ok().build(); // 删除成功
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // 删除失败
        }
    }

//    从发件箱中删除邮件
    @DeleteMapping("/outbox/{emailId}")
    public ResponseEntity<Void> deleteOutboxEmail(@PathVariable Long emailId) {
        boolean success = emailMessageService.deleteOutboxEmail(emailId);
        if (success) {
            return ResponseEntity.ok().build(); // 删除成功
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // 删除失败
        }
    }

//    从垃圾箱彻底删除邮件
    @DeleteMapping("/trashbox/{emailId}")
    public ResponseEntity<Void> confirmDeleteEmail(@PathVariable Long emailId, @RequestParam("email") String userEmail) {
        boolean success = emailMessageService.confirmDeleteEmail(emailId, userEmail);
        if (success) {
            return ResponseEntity.ok().build(); // Successfully deleted
        } else {
            return ResponseEntity.notFound().build(); // Email not found or error occurred
        }
    }

//    在收件箱中搜索邮件
    @GetMapping("/inbox/search")
    public ResponseEntity<List<EmailMessageSaveReq>> searchEmails(@RequestParam("email") String recipientEmail, @RequestParam("query") String query) {
        List<EmailMessageSaveReq> emails = emailMessageService.searchEmailsForRecipient(recipientEmail, query);
        if (emails.isEmpty()) {
            return ResponseEntity.ok(Collections.emptyList()); // 返回空列表
        } else {
            return ResponseEntity.ok(emails);
        }
    }

    //    在草稿箱中搜索邮件
    @GetMapping("/drafts/search")
    public ResponseEntity<List<EmailMessageSaveReq>> searchEmailsInDrafts(@RequestParam("email") String senderEmail, @RequestParam("query") String query) {
        List<EmailMessageSaveReq> emails = emailMessageService.searchEmailsInDrafts(senderEmail, query);
        if (emails.isEmpty()) {
            return ResponseEntity.ok(Collections.emptyList()); // 返回空列表
        } else {
            return ResponseEntity.ok(emails);
        }
    }
    //    在发件箱中搜索邮件
    @GetMapping("/outbox/search")
    public ResponseEntity<List<EmailMessageSaveReq>> searchEmailsInOutbox(@RequestParam("email") String senderEmail, @RequestParam("query") String query) {
        List<EmailMessageSaveReq> emails = emailMessageService.searchEmailsInOutbox(senderEmail, query);
        if (emails.isEmpty()) {
            return ResponseEntity.ok(Collections.emptyList()); // 返回空列表
        } else {
            return ResponseEntity.ok(emails);
        }
    }

    //    在垃圾箱中搜索邮件
    @GetMapping("/trashbox/search")
    public ResponseEntity<List<EmailMessageSaveReq>> searchEmailsInTrashbox(@RequestParam("email") String senderEmail, @RequestParam("query") String query) {
        List<EmailMessageSaveReq> emails = emailMessageService.searchEmailsInTrashbox(senderEmail, query);
        if (emails.isEmpty()) {
            return ResponseEntity.ok(Collections.emptyList()); // 返回空列表
        } else {
            return ResponseEntity.ok(emails);
        }
    }

    @PostMapping("/sendEmailToMulRecipients")
    public ResponseEntity<CommonResp<Object>> sendEmailToMultipleRecipients(@RequestBody EmailMessageSaveReq req) {
        CommonResp<Object> resp = new CommonResp<>();
        boolean result = emailMessageService.sendMessageToMultipleRecipients(req);
        System.out.println("群发");
        if (result) {
            resp.setSuccess(true);
            resp.setMessage("Email sent successfully to multiple recipients");
        } else {
            resp.setSuccess(false);
            resp.setMessage("Failed to send email");
        }
        return ResponseEntity.ok(resp);
    }

    @PostMapping("/saveDraftMultipleRecipients")
    public ResponseEntity<CommonResp<Object>> saveDraftMultipleRecipients(@RequestBody EmailMessageSaveReq req) {
        CommonResp<Object> resp = new CommonResp<>();
        boolean success = emailMessageService.saveDraftToMu(req);
        if (success) {
            resp.setMessage("Draft saved successfully for multiple recipients.");
        } else {
            resp.setSuccess(false);
            resp.setMessage("Failed to save draft for multiple recipients.");
        }
        return ResponseEntity.ok(resp);
    }

    @PostMapping("/sendDraftMultipleRecipients")
    public ResponseEntity<CommonResp<Object>> sendDraftMultipleRecipients(@RequestBody EmailMessageSaveReq req) {
        CommonResp<Object> resp = new CommonResp<>();
        boolean result = emailMessageService.sendDraftToMultipleRecipients(req);
        if (result) {
            resp.setSuccess(true);
            resp.setMessage("Draft sent successfully to multiple recipients");
        } else {
            resp.setSuccess(false);
            resp.setMessage("Failed to send draft");
        }
        return ResponseEntity.ok(resp);
    }

    @PostMapping("/updateDraftMultipleRecipients")
    public ResponseEntity<CommonResp<Object>> updateDraftMultipleRecipients(@RequestBody EmailMessageSaveReq req) {
        CommonResp<Object> resp = new CommonResp<>();
        try {
            boolean isUpdated = emailMessageService.updateMultipleRecipientsDraft(req);
            if (isUpdated) {
                resp.setSuccess(true);
                resp.setMessage("Draft updated successfully for multiple recipients");
            } else {
                resp.setSuccess(false);
                resp.setMessage("Failed to update draft for multiple recipients");
            }
        } catch (Exception e) {
            resp.setSuccess(false);
            resp.setMessage("An error occurred while updating the draft: " + e.getMessage());
        }
        return ResponseEntity.ok(resp);
    }

}
