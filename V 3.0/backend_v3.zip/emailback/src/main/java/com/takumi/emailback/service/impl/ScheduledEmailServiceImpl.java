package com.takumi.emailback.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.takumi.emailback.entity.EmailMessageEntity;
import com.takumi.emailback.entity.ScheduledEmailEntity;
import com.takumi.emailback.mapper.EmailMessageMapper;
import com.takumi.emailback.mapper.ScheduledEmailMapper;
import com.takumi.emailback.req.ScheduledEmailSaveReq;
import com.takumi.emailback.service.ScheduledEmailService;
import com.takumi.emailback.utils.CopyUtil;
import jakarta.annotation.Resource;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
public class ScheduledEmailServiceImpl extends ServiceImpl<ScheduledEmailMapper, ScheduledEmailEntity> implements ScheduledEmailService {

    @Resource
    private ScheduledEmailMapper scheduledEmailMapper;
    @Resource
    private EmailMessageMapper emailMessageMapper;
    @Resource
    private TaskScheduler taskScheduler;

    @Override
    @Transactional
    public boolean scheduleEmail(ScheduledEmailSaveReq emailRequest) throws Exception {
        ScheduledEmailEntity emailEntity = CopyUtil.copy(emailRequest, ScheduledEmailEntity.class);
        System.out.println("the Scheduled Email Entity is:" + emailRequest);

        try {
            System.out.println("fujian:" + emailRequest.getAttachmentInfo());
            // 这里保存邮件实体到数据库
            scheduledEmailMapper.insert(emailEntity);
            // 安排定时任务
            taskScheduler.schedule(
                    () -> {
                        sendEmail(emailEntity);
                    },
                    Date.from(emailRequest.getScheduledTime().atZone(java.time.ZoneId.systemDefault()).toInstant())
            );
            return true; // 保存邮件成功
        } catch (Exception e) {
            // 发送失败的处理逻辑
            emailRequest.setStatus("failed");
            scheduledEmailMapper.insert(emailEntity); // 即使失败也保存邮件信息，但状态为failed
            return false; // 发送失败
        }
    }

    private void sendEmail(ScheduledEmailEntity email) {
        // 这里模拟发送邮件的逻辑
        System.out.println("Sending scheduled email to: " + email.getRecipientEmail());
        // 更新原计划邮件的状态为已发送
        email.setStatus("sent");
        // 假设邮件发送成功后，将信息复制到 email_message 表，并更新状态
        EmailMessageEntity message = CopyUtil.copy(email, EmailMessageEntity.class);
        System.out.println("email message: "+ message);
        emailMessageMapper.insert(message); // 保存邮件信息

        scheduledEmailMapper.updateById(email);
    }
}
