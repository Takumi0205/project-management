package com.takumi.emailback.exception;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import com.takumi.emailback.resp.CommonResp;
import org.springframework.http.HttpStatus;


@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(Exception.class)
    public ResponseEntity<CommonResp<Object>> handleException(Exception e) {
        CommonResp<Object> resp = new CommonResp<>();
        resp.setSuccess(false);
        resp.setMessage("Error occurred: " + e.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
    }

    @ExceptionHandler(RuntimeException.class)
    @ResponseBody
    public ResponseEntity<CommonResp> handleRuntimeException(RuntimeException e) {
        CommonResp<String> response = new CommonResp<>();
        response.setSuccess(false);
        response.setMessage(e.getMessage());
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }
}

