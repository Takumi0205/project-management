package com.takumi.emailback.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.takumi.emailback.entity.EmailRecsEntity;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface EmailRecsMapper extends BaseMapper<EmailRecsEntity> {
}
