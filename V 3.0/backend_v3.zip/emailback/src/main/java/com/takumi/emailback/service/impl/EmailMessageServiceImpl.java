package com.takumi.emailback.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.takumi.emailback.entity.EmailEntity;
import com.takumi.emailback.entity.EmailMessageEntity;
import com.takumi.emailback.entity.EmailRecsEntity;
import com.takumi.emailback.entity.EmailUserEntity;
import com.takumi.emailback.mapper.EmailMapper;
import com.takumi.emailback.mapper.EmailMessageMapper;
import com.takumi.emailback.mapper.EmailUserMapper;
import com.takumi.emailback.req.EmailMessageSaveReq;
import com.takumi.emailback.req.EmailUserReq;
import com.takumi.emailback.service.EmailMessageService;
import com.takumi.emailback.utils.CopyUtil;
import jakarta.annotation.Resource;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;

import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class EmailMessageServiceImpl extends ServiceImpl<EmailMessageMapper, EmailMessageEntity> implements EmailMessageService {

    @Resource
    private EmailMessageMapper emailMessageMapper;
    @Resource
    private EmailMapper emailMapper;

    @Resource
    private EmailUserMapper emailUserMapper;
//    保存邮件信息到数据库的操作,发送邮件
    @Override
    @Transactional
    public boolean sendMessage(EmailMessageSaveReq req) {
        EmailMessageEntity message = CopyUtil.copy(req, EmailMessageEntity.class);
        System.out.println("the message is:" + message);

        try {
            System.out.println("fujian:" + message.getAttachmentInfo());
            // 如果邮件成功发送:
            message.setStatus("sent"); // 假设发送成功
            emailMessageMapper.insert(message); // 保存邮件信息

            //加一个判断方法,首先查看收件人是否为customer_service,如果是那么进行自动回复.
            boolean autoReplySent = autoSendEmail(message);
            System.out.println("11111111111");
            System.out.println(message.getEmailId());
            if (autoReplySent) {
                System.out.println("Auto reply email sent successfully.");
            } else {
                System.out.println("No auto reply needed or failed to send auto reply.");
            }

            return true; // 发送成功
        } catch (Exception e) {
            // 发送失败的处理逻辑
            message.setStatus("failed");
            emailMessageMapper.insert(message); // 即使失败也保存邮件信息，但状态为failed
            return false; // 发送失败
        }
    }
    // 在相应的Service类中
    public List<String> getAllEmailAddresses() {
        // 使用QueryWrapper来查询所有记录，不设置任何条件表示查询全部
        List<EmailEntity> emailList = emailMapper.selectList(new QueryWrapper<>());
        // 使用Java 8 Stream API将EmailEntity列表转换为邮箱地址列表
        List<String> emailAddresses = emailList.stream()
                .map(EmailEntity::getEmail) // 假设getEmail是获取邮箱地址的getter方法
                .collect(Collectors.toList());
        return emailAddresses;
    }

    //查看收件人的部门是否是customer_service,我还想让它在这个方法里自动发邮件了
    public boolean autoSendEmail(EmailMessageEntity message){
        System.out.println(message.getRecipients());
        //首先得获取到收件人的邮件地址,然后查这个邮件地址的部门信息.
        //换一种写法
        if(message.getRecipientEmail().equals("multipleRecipients@example.com")){
            // 遍历所有收件人，对部门为customer_service的收件人进行自动回复
            String[] recipients = message.getRecipients().split(";");
            boolean allRepliesSent = true;
            for (String recipient : recipients) {
                recipient = recipient.trim();
                EmailUserReq userDetails = getUserByEmail(recipient);
                if (userDetails != null && "customer_service".equals(userDetails.getDepartment())) {
                    boolean replySent = sendAutoReply(message.getSubject(), recipient, message.getSenderEmail());
                    if (!replySent) {
                        allRepliesSent = false;
                    }
                }
            }
            return allRepliesSent;
        }
        else{
            //如果多收件人为空,证明发件人不是hr/hr没有选多个收件人
            String userEmail = message.getRecipientEmail();
            System.out.println("now get the recipient email is:" + userEmail);
            EmailUserReq userDetails = getUserByEmail(userEmail);
            if (userDetails != null && "customer_service".equals(userDetails.getDepartment())) {
                return sendAutoReply(message.getSubject(), userEmail, message.getSenderEmail());
            }
        }
        return false;
    }

    // 发送自动回复邮件
    private boolean sendAutoReply(String originalSubject, String recipientEmail, String senderEmail) {
        EmailMessageEntity replyMessage = new EmailMessageEntity();
        replyMessage.setSenderEmail(recipientEmail); // 收件人成为发件人
        replyMessage.setRecipientEmail(senderEmail); // 发件人成为收件人
        replyMessage.setSubject("Re: " + originalSubject); // 回复的主题
        replyMessage.setContent("<p>Thank you for your email. We have received your message and will respond shortly.</p>"); // 回复的内容
        replyMessage.setStatus("sent"); // 设置状态为已发送

        try {
            emailMessageMapper.insert(replyMessage); // 插入回复邮件
            System.out.println("Auto reply email sent successfully.");
            return true; // 自动回复成功
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Failed to send auto reply email.");
            return false; // 自动回复失败
        }
    }

    //获取email的个人信息.
    public EmailUserReq getUserByEmail(String email) {
//        System.out.println("The get email:" + email);
        EmailUserEntity entity = emailUserMapper.selectByEmail(email);
//        System.out.println("The user information:" + entity);
        if (entity != null ){
            EmailUserReq userDetails = CopyUtil.copy(entity, EmailUserReq.class);
            return userDetails;
        }
        return null;
    }
    //    保存邮件为草稿的方法
    @Override
    @Transactional
    public boolean saveDraft(EmailMessageSaveReq req) {
        EmailMessageEntity message = CopyUtil.copy(req, EmailMessageEntity.class);
        System.out.println("the email message is:" + message);

        try {
            message.setStatus("draft"); // 设置状态为草稿
            emailMessageMapper.insert(message); // 尝试保存到数据库
            return true; // 保存成功
        } catch (Exception e) {
            // 异常处理逻辑，根据需要记录日志或者做其他处理
            // 发送失败的处理逻辑
            message.setStatus("failed");
            emailMessageMapper.insert(message); // 即使失败也保存邮件信息，但状态为failed
            return false; // 保存失败
        }
    }




    @Override
    public List<EmailMessageSaveReq> getEmailsForRecipient(String recipientEmail) {
        QueryWrapper<EmailMessageEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("recipient_email", recipientEmail)
                    .eq("status", "sent") // 只选取状态为 "sent" 的邮件
                    .eq("recipient_deleted", false);
        List<EmailMessageEntity> entities = emailMessageMapper.selectList(queryWrapper);

//        return entities.stream().map(entity -> CopyUtil.copy(entity, EmailMessageSaveReq.class)).collect(Collectors.toList());
        return entities.stream().map(entity -> {
            EmailMessageSaveReq emails = CopyUtil.copy(entity, EmailMessageSaveReq.class);
            emails.setEmailId(entity.getEmailId().toString()); // 在这里进行转换
            return emails;
        }).collect(Collectors.toList());
    }


//    通过id查到email信息
    @Override
    public EmailMessageSaveReq getEmailById(Long emailId, Boolean fromInbox) {
        EmailMessageEntity entity = emailMessageMapper.selectById(emailId);
        if (entity != null ){
            if (Boolean.TRUE.equals(fromInbox) && !entity.getIsRead()) {
                System.out.println("The Email open from inbox");
                entity.setIsRead(true);
                emailMessageMapper.updateById(entity);
            }
            EmailMessageSaveReq emailDetails = CopyUtil.copy(entity, EmailMessageSaveReq.class);
            return emailDetails;
        }
        return null;
    }

//    @Override
//    public EmailMessageSaveReq getEmailById(Long emailId) {
//        EmailMessageEntity entity = emailMessageMapper.selectById(emailId);
//        if (entity != null) {
//            // 检查邮件是否未读，如果是，则将其标记为已读
//            if (!entity.getIsRead()) {
//                entity.setIsRead(true); // 更新为已读
//                emailMessageMapper.updateById(entity); // 保存更新到数据库
//            }
//            EmailMessageSaveReq emails = CopyUtil.copy(entity, EmailMessageSaveReq.class);
//            emails.setEmailId(entity.getEmailId().toString()); // 进行转换
//            return emails;
//        }
//        return null;
//    }

    @Override
    public List<EmailMessageSaveReq> getDraftsForUser(String userEmail) {
        QueryWrapper<EmailMessageEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("sender_email", userEmail)
                .eq("status", "draft");
        List<EmailMessageEntity> drafts = emailMessageMapper.selectList(queryWrapper);
//        if (!drafts.isEmpty()) {
//            for (EmailMessageEntity draft : drafts) {
//                System.out.println("emailID of Draft: " + draft.getEmailId());
//            }
//        } else {
//            System.out.println("No drafts found.");
//        }
//        return entities.stream().map(entity -> {
//            EmailMessageSaveReq emails = CopyUtil.copy(entity, EmailMessageSaveReq.class);
//            emails.setEmailId(entity.getEmailId().toString()); // 在这里进行转换
//            return emails;
        return drafts.stream().map(draft -> {
            EmailMessageSaveReq emails = CopyUtil.copy(draft, EmailMessageSaveReq.class);
            emails.setEmailId(draft.getEmailId().toString()); // 在这里进行转换
            return emails;
        }).collect(Collectors.toList());
    }

//    更新草稿件
    @Override
    @Transactional
    public boolean updateDraft(EmailMessageSaveReq req) {
        if (req.getEmailId() == null || req.getEmailId().isEmpty()) {
            return false; // 没有提供有效的Email ID
        }

        Long emailId = Long.parseLong(req.getEmailId());
        EmailMessageEntity existingDraft = emailMessageMapper.selectById(emailId);

        if (existingDraft == null) {
            existingDraft = new EmailMessageEntity(); // 如果不存在，创建新实例
        }

        // 设置或更新字段值
        existingDraft.setEmailId(emailId);
        existingDraft.setSenderEmail(req.getSenderEmail());
        existingDraft.setRecipientEmail(req.getRecipientEmail());
        existingDraft.setSubject(req.getSubject());
        existingDraft.setContent(req.getContent());
        existingDraft.setAttachmentInfo(req.getAttachmentInfo());
        existingDraft.setStatus("draft"); // 确保状态被设置为草稿
        // 当在草稿箱点击edit时，调用的是byID的方法，已经设置了is_Read变为了true，
        // 所以在用户再次点击保存为草稿的时候把isRead的状态改回来。
        existingDraft.setIsRead(false);
        existingDraft.setUpdateTime(LocalDateTime.now()); // 显式设置更新时间为当前时间

        try {
            emailMessageMapper.updateDraft(existingDraft); // 使用insertOrUpdate
            return true; // 操作成功
        } catch (Exception e) {
            e.printStackTrace();
            return false; // 操作失败
        }
    }

//    在草稿修改页面发送邮件
    @Override
    @Transactional
    public boolean sendDraft(EmailMessageSaveReq req) {
        if (req.getEmailId() == null || req.getEmailId().isEmpty()) {
            return false;
        }

        Long emailId = Long.parseLong(req.getEmailId());
        EmailMessageEntity email = emailMessageMapper.selectById(emailId);
        if (email == null) {
            return false;
        }

        // 更新邮件信息
        email.setRecipientEmail(req.getRecipientEmail());
        email.setSubject(req.getSubject());
        email.setContent(req.getContent());
        email.setAttachmentInfo(req.getAttachmentInfo());
//        email.setRecipients(null);
        email.setStatus("sent");
        email.setIsRead(false);
        email.setUpdateTime(LocalDateTime.now()); // 更新时间
//        System.out.println("看看多发件人是什么"+email.getRecipients());
        try {
            emailMessageMapper.updateById(email);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

//    获取到发件箱中的全部邮件列表
    @Override
    public List<EmailMessageSaveReq> getEmailsForOutbox(String senderEmail) {
        QueryWrapper<EmailMessageEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("sender_email", senderEmail)
                    .in("status", Arrays.asList("sent", "draft", "failed")) // 只包括'sent'、'draft'、'failed'状态的邮件;
                    .eq("sender_deleted", false);
        List<EmailMessageEntity> entities = emailMessageMapper.selectList(queryWrapper);

//        return entities.stream().map(entity -> CopyUtil.copy(entity, EmailMessageSaveReq.class)).collect(Collectors.toList());
        return entities.stream().map(entity -> {
            EmailMessageSaveReq emails = CopyUtil.copy(entity, EmailMessageSaveReq.class);
            emails.setEmailId(entity.getEmailId().toString()); // 在这里进行转换
            return emails;
        }).collect(Collectors.toList());
    }
//    获取到垃圾箱中的全部邮件列表
    @Override
    public List<EmailMessageSaveReq> getEmailsForTrashbox(String userEmail) {
        // 查询作为发件人且标记为删除的邮件
        QueryWrapper<EmailMessageEntity> senderDeletedQuery = new QueryWrapper<>();
//        查找发件人的id与登录id符合的邮件,然后查找sender_deleted为1的邮件,说明
//        1.从草稿箱删除的邮件
//        2.从发件箱删除的邮件
        senderDeletedQuery.eq("sender_email", userEmail)
                          .eq("sender_deleted", true)
                          .eq("confirm_sender_deleted", false);

        List<EmailMessageEntity> senderDeletedEmails = emailMessageMapper.selectList(senderDeletedQuery);

        // 查询作为收件人且标记为删除的邮件
//        1.从收件箱中删除的邮件
        QueryWrapper<EmailMessageEntity> recipientDeletedQuery = new QueryWrapper<>();
        recipientDeletedQuery.eq("recipient_email", userEmail)
                             .eq("recipient_deleted", true)
                             .eq("confirm_recipient_deleted", false);

        List<EmailMessageEntity> recipientDeletedEmails = emailMessageMapper.selectList(recipientDeletedQuery);

        // 合并两个列表
        List<EmailMessageEntity> allDeletedEmails = new ArrayList<>(senderDeletedEmails);
        allDeletedEmails.addAll(recipientDeletedEmails);


        // 应用层面去重，保证每个邮件ID只出现一次
        List<EmailMessageSaveReq> distinctEmails = allDeletedEmails.stream()
                .collect(Collectors.collectingAndThen(
                        Collectors.toMap(EmailMessageEntity::getEmailId, Function.identity(), (e1, e2) -> e1),
                        map -> new ArrayList<>(map.values())))
                .stream()
                .map(entity -> {
                    EmailMessageSaveReq emailDto = CopyUtil.copy(entity, EmailMessageSaveReq.class);
                    // 确保在这里手动设置emailId为字符串形式
                    emailDto.setEmailId(entity.getEmailId().toString());
                    return emailDto;
                })
                .collect(Collectors.toList());


        // 转换为DTO列表
//        return allDeletedEmails.stream().map(entity -> {
//            EmailMessageSaveReq emailDto = CopyUtil.copy(entity, EmailMessageSaveReq.class);
//            emailDto.setEmailId(entity.getEmailId().toString()); // 在这里进行转换
//            return emailDto;
//        }).collect(Collectors.toList());
        return distinctEmails;
    }



    //    从草稿箱中删除邮件到垃圾桶
    @Override
    @Transactional
    public boolean deleteDraft(Long emailId) {
        EmailMessageEntity draft = emailMessageMapper.selectById(emailId);
        if (draft != null && "draft".equals(draft.getStatus())) {
            draft.setStatus("deleted"); // 更新状态为已删除
            draft.setSenderDeleted(true); // 标记为发件人删除
            emailMessageMapper.updateById(draft); // 更新记录
            return true;
        }
        return false;
    }

    //    从收件中删除邮件到垃圾桶
    @Override
    @Transactional
    public boolean deleteInboxEmail(Long emailId) {
        EmailMessageEntity email = emailMessageMapper.selectById(emailId);
        if (email != null && "sent".equals(email.getStatus())) {
            email.setRecipientDeleted(true); // 标记为发件人删除
            emailMessageMapper.updateById(email); // 更新记录
            return true;
        }
        return false;
    }

    //    从发件箱中删除邮件到垃圾桶
    @Override
    @Transactional
    public boolean deleteOutboxEmail(Long emailId) {
        EmailMessageEntity email = emailMessageMapper.selectById(emailId);
        if (email != null){
            if("sent".equals(email.getStatus()) || "draft".equals(email.getStatus())
                    || "failed".equals(email.getStatus())){
                email.setSenderDeleted(true); // 标记为发件人删除
                emailMessageMapper.updateById(email); // 更新记录
                return true;
            }
        }
        return false;
    }

//    在垃圾箱里彻底删除的操作
    @Override
    @Transactional
    public boolean confirmDeleteEmail(Long emailId, String currentUserEmail) {
        EmailMessageEntity email = emailMessageMapper.selectById(emailId);
        if (email == null) {
            return false;
        }

        boolean isSender = currentUserEmail.equals(email.getSenderEmail());
        boolean isRecipient = currentUserEmail.equals(email.getRecipientEmail());

        if ("deleted".equals(email.getStatus())) {
            // 特殊处理：草稿被标记为已删除，且没有收件人删除的情况
            if (isSender && !Boolean.TRUE.equals(email.getRecipientDeleted())) {
                email.setConfirmSenderDeleted(true);
                // 对于草稿，直接进行彻底删除操作
                if (!Boolean.TRUE.equals(email.getConfirmRecipientDeleted())) {
                    emailMessageMapper.deleteById(emailId); // 或其他彻底删除的逻辑
                    return true;
                }
            }
        }
        // 检查是否同时为发件人和收件人
        if (isSender && isRecipient) {
            boolean confirmDelete = false;
            if (Boolean.TRUE.equals(email.getSenderDeleted())) {
                email.setConfirmSenderDeleted(true);
                confirmDelete = true;
            }
            if (Boolean.TRUE.equals(email.getRecipientDeleted())) {
                email.setConfirmRecipientDeleted(true);
                confirmDelete = true;
            }
            if (confirmDelete && email.getConfirmSenderDeleted() && email.getConfirmRecipientDeleted()) {
                emailMessageMapper.deleteById(emailId); // 彻底删除邮件记录
                return true;
            }
        } else {
            if (isSender && Boolean.TRUE.equals(email.getSenderDeleted())) {
                email.setConfirmSenderDeleted(true);
            }
            if (isRecipient && Boolean.TRUE.equals(email.getRecipientDeleted())) {
                email.setConfirmRecipientDeleted(true);
            }
            // 只有当两个确认删除状态都为true时，才彻底删除邮件
            if (email.getConfirmSenderDeleted() && email.getConfirmRecipientDeleted()) {
                emailMessageMapper.deleteById(emailId); // 彻底删除邮件记录
                return true;
            }
        }

        emailMessageMapper.updateById(email); // 更新邮件状态
        return true;
    }
    //    在收件箱中搜索邮件
    @Override
    public List<EmailMessageSaveReq> searchEmailsForRecipient(String recipientEmail, String query) {
        QueryWrapper<EmailMessageEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("recipient_email", recipientEmail)
                .eq("status", "sent") // 确保只搜索状态为"sent"的邮件
                .eq("recipient_deleted", false) // 确保不搜索已被标记为删除的邮件
                .and(wrapper -> wrapper
                        .like("subject", query)
                        .or()
                        .like("content", query));

        List<EmailMessageEntity> entities = emailMessageMapper.selectList(queryWrapper);

        // 如果entities为空，直接返回一个空的列表
        if (entities == null || entities.isEmpty()) {
            return new ArrayList<>(); // 返回一个空列表，而不是null
        }

        // 转换实体到DTO，并确保emailId被正确转换为String类型
        return entities.stream().map(entity -> {
            EmailMessageSaveReq emailDto = CopyUtil.copy(entity, EmailMessageSaveReq.class);
            emailDto.setEmailId(entity.getEmailId().toString()); // 确保这里是获取实体类中的ID并转换为字符串
            return emailDto;
        }).collect(Collectors.toList());
    }

    //    在草稿箱中搜索邮件
    @Override
    public List<EmailMessageSaveReq> searchEmailsInDrafts(String userEmail, String query) {
        QueryWrapper<EmailMessageEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("sender_email", userEmail)
                    .eq("status", "draft")
                    .and(wrapper -> wrapper
                            .like("subject", query)
                            .or()
                            .like("content", query));

        List<EmailMessageEntity> entities = emailMessageMapper.selectList(queryWrapper);

        // 如果entities为空，直接返回一个空的列表
        if (entities == null || entities.isEmpty()) {
            return new ArrayList<>(); // 返回一个空列表，而不是null
        }

        // 转换实体到DTO，并确保emailId被正确转换为String类型
        return entities.stream().map(entity -> {
            EmailMessageSaveReq emailDto = CopyUtil.copy(entity, EmailMessageSaveReq.class);
            emailDto.setEmailId(entity.getEmailId().toString()); // 确保这里是获取实体类中的ID并转换为字符串
            return emailDto;
        }).collect(Collectors.toList());
    }

    //    在发件箱中搜索邮件
    @Override
    public List<EmailMessageSaveReq> searchEmailsInOutbox(String senderEmail, String query) {
        QueryWrapper<EmailMessageEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("sender_email", senderEmail)
                    .in("status", Arrays.asList("sent", "draft", "failed")) // 只包括'sent'、'draft'、'failed'状态的邮件;
                    .eq("sender_deleted", false)
                    .and(wrapper -> wrapper
                            .like("subject", query)
                            .or()
                            .like("content", query));

        List<EmailMessageEntity> entities = emailMessageMapper.selectList(queryWrapper);

        // 如果entities为空，直接返回一个空的列表
        if (entities == null || entities.isEmpty()) {
            return new ArrayList<>(); // 返回一个空列表，而不是null
        }

        // 转换实体到DTO，并确保emailId被正确转换为String类型
        return entities.stream().map(entity -> {
            EmailMessageSaveReq emailDto = CopyUtil.copy(entity, EmailMessageSaveReq.class);
            emailDto.setEmailId(entity.getEmailId().toString()); // 确保这里是获取实体类中的ID并转换为字符串
            return emailDto;
        }).collect(Collectors.toList());
    }

    //    在垃圾箱中搜索邮件
    public List<EmailMessageSaveReq> searchEmailsInTrashbox(String userEmail, String query) {
        // 创建一个集合来存储查询结果
        List<EmailMessageEntity> results = new ArrayList<>();

        // 分别查询作为发件人的邮件
        QueryWrapper<EmailMessageEntity> senderQueryWrapper = new QueryWrapper<>();
        senderQueryWrapper
                .eq("sender_email", userEmail)
                .eq("sender_deleted", true)
                .eq("confirm_sender_deleted", false)
                .and(wrapper -> wrapper.like("subject", query).or().like("content", query));

        List<EmailMessageEntity> senderResults = emailMessageMapper.selectList(senderQueryWrapper);
        if (senderResults != null && !senderResults.isEmpty()) {
            results.addAll(senderResults);
        }

        // 分别查询作为收件人的邮件
        QueryWrapper<EmailMessageEntity> recipientQueryWrapper = new QueryWrapper<>();
        recipientQueryWrapper
                .eq("recipient_email", userEmail)
                .eq("recipient_deleted", true)
                .eq("confirm_recipient_deleted", false)
                .and(wrapper -> wrapper.like("subject", query).or().like("content", query));

        List<EmailMessageEntity> recipientResults = emailMessageMapper.selectList(recipientQueryWrapper);
        if (recipientResults != null && !recipientResults.isEmpty()) {
            results.addAll(recipientResults);
        }

        // 应用层面去重，保证每个邮件ID只出现一次
        List<EmailMessageSaveReq> distinctEmails = results.stream()
                .collect(Collectors.collectingAndThen(
                        Collectors.toMap(EmailMessageEntity::getEmailId, Function.identity(), (e1, e2) -> e1),
                        map -> new ArrayList<>(map.values())))
                .stream()
                .map(entity -> {
                    EmailMessageSaveReq emailDto = CopyUtil.copy(entity, EmailMessageSaveReq.class);
                    emailDto.setEmailId(entity.getEmailId().toString()); // 确保emailId被正确转换为String类型
                    return emailDto;
                })
                .collect(Collectors.toList());

        return distinctEmails;
    }

    @Override
    @Transactional
    public boolean sendMessageToMultipleRecipients(EmailMessageSaveReq req) {
        boolean allSentSuccessfully = true;
        // 假设req中的recipientEmail是以分号分隔的多个邮箱地址
        String[] recipients = req.getRecipientEmail().split(";");
        for (String recipient : recipients) {
            try {
                EmailMessageEntity message = CopyUtil.copy(req, EmailMessageEntity.class);
                message.setRecipientEmail(recipient.trim()); // 注意去除可能的空格
                // 这里添加发送邮件的逻辑
                message.setStatus("sent");
                emailMessageMapper.insert(message);
            } catch (Exception e) {
                allSentSuccessfully = false;
                // 根据需要处理异常，例如记录日志等
                e.printStackTrace();
            }
        }
        return allSentSuccessfully;
    }

    @Override
    @Transactional
    public boolean saveDraftToMu(EmailMessageSaveReq req) {
        try {
            EmailMessageEntity draft = CopyUtil.copy(req, EmailMessageEntity.class);
            draft.setStatus("draft");

            // 假设req.getRecipientEmail()返回的是完整的收件人列表字符串
            String allRecipients = req.getRecipientEmail(); // "x;x;x;"
            draft.setRecipients(allRecipients); // 保存完整的收件人列表

            // 如果需要，将第一个收件人或占位邮箱设置到recipient_email字段
            // 可以是allRecipients.split(";")[0]，或一个有效的占位邮箱
            draft.setRecipientEmail("multipleRecipients@example.com");

            emailMessageMapper.insert(draft);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    //从草稿箱发送草稿(多联系人
    @Override
    @Transactional
    public boolean sendDraftToMultipleRecipients(EmailMessageSaveReq req) {
        if (req.getEmailId() == null || req.getEmailId().isEmpty()) {
            System.out.println("emailID为空");
            return false; // 没有提供有效的Email ID
        }

        Long emailId = Long.parseLong(req.getEmailId());
        EmailMessageEntity draft = emailMessageMapper.selectById(emailId);

        if (draft == null) {
            System.out.println("draft为空");
            return false; // 如果草稿不存在，直接返回失败
        }

        boolean allSentSuccessfully = true;
        // 将收件人字符串分割成单个邮箱地址
        String[] recipients = req.getRecipientEmail().split(";");
        System.out.println("正常运行");
        // 对于每个收件人，创建一个新的邮件实体并发送
        for (String recipient : recipients) {
            try {
                EmailMessageEntity messageToSend = CopyUtil.copy(req, EmailMessageEntity.class);
                messageToSend.setRecipientEmail(recipient.trim()); // 注意去除可能的空格
                messageToSend.setStatus("sent"); // 设置状态为已发送
                messageToSend.setUpdateTime(LocalDateTime.now()); // 更新发送时间
                // 注意：这里可能需要设置其他必要的字段，比如发送者信息等
//                System.out.println("给每个收件人发送的邮件"+messageToSend.getRecipientEmail());
                emailMessageMapper.insert(messageToSend);
            } catch (Exception e) {
                allSentSuccessfully = false;
                e.printStackTrace(); // 根据需要处理异常
            }
        }

        // 如果所有邮件都成功发送，更新原草稿状态为已发送
        if (allSentSuccessfully) {
            draft.setStatus("sent");
            emailMessageMapper.updateById(draft);
        }

        return allSentSuccessfully;
    }

    @Override
    @Transactional
    public boolean updateMultipleRecipientsDraft(EmailMessageSaveReq req) {
        if (req.getEmailId() == null || req.getEmailId().isEmpty()) {
            return false; // 没有提供有效的Email ID
        }

        Long emailId = Long.parseLong(req.getEmailId());
        EmailMessageEntity existingDraft = emailMessageMapper.selectById(emailId);

        if (existingDraft == null) {
            return false; // 草稿不存在
        }

        try {
            // 更新草稿信息
            existingDraft.setSubject(req.getSubject());
            existingDraft.setContent(req.getContent());
            existingDraft.setAttachmentInfo(req.getAttachmentInfo());
            existingDraft.setUpdateTime(LocalDateTime.now()); // 更新时间

            // 处理多收件人
            String allRecipients = req.getRecipientEmail(); // 假设这是完整的收件人列表字符串
            existingDraft.setRecipients(allRecipients); // 更新收件人列表

            emailMessageMapper.updateById(existingDraft);
            System.out.println("测试");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


}
