select * from email_login;
-- 删除一个表格
set sql_safe_updates = 0;
DROP TABLE IF EXISTS user_message;
DROP TABLE IF EXISTS email_message;
DROP TABLE IF EXISTS email_recipients;

DELETE FROM email_login WHERE email='test1@taku.com';
DELETE FROM user_message WHERE email='test1@taku.com';
DELETE FROM email_message WHERE attachment_info='附件信息(还没写这个功能和框)';
DELETE FROM email_message WHERE email_id='1775039082719182850';


update email_message set is_read = '0' where email_id ='1767908170873233409';

update email_message set sender_deleted = '1' where email_id ='1769034628580573185';

update email_message set status = 'sent' where email_id ='1769039973591875586';

update user_message set avatar = 'avatar01.jpeg' where email ='junki@taku.com';

update user_message set avatar = 'avatar01.jpeg' where email ='takumi@taku.com';
-- 邮件的信息总表
CREATE TABLE email_message (
    email_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    sender_email VARCHAR(255) NOT NULL,
    recipient_email VARCHAR(255) NOT NULL,
    subject VARCHAR(255),
    content TEXT,
    attachment_info TEXT,
    creation_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status VARCHAR(50),
    FOREIGN KEY (sender_email) REFERENCES user_message(email),
    FOREIGN KEY (recipient_email) REFERENCES user_message(email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


select * from email_message;

-- 创建了一个用户的总表
-- 这个表user_id作为主键，同时email字段设置为UNIQUE，确保每个电子邮件地址在表中是唯一的。
CREATE TABLE user_message (
    user_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255),
    avatar VARCHAR(255),
    name VARCHAR(255),
    phone bigint,
    address VARCHAR(255),
    department VARCHAR(255),
    personal_intro TEXT,
    creation_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE user_message ADD COLUMN password VARCHAR(255);

select * from user_message;

INSERT INTO user_message (email, password, name, phone, department) 
VALUES ('takumi@taku.com', '25f9e794323b453885f5181f1b624d0b', 'kawanishi', 15468535968, 'it');
-- 更新原来注册过账户的头像
UPDATE user_message 
SET avatar = '{\"status\":\"success\",\"name\":\"avatar01.jpeg\",\"uid\":\"avatar01\",\"url\":\"http://localhost:3759/avatars/avatar01.jpeg\"}'
WHERE avatar IS NULL;

-- 加一个已读/未读的状态
ALTER TABLE email_message ADD COLUMN is_read BOOLEAN DEFAULT FALSE;

ALTER TABLE user_message MODIFY COLUMN avatar TEXT;

ALTER TABLE email_message MODIFY COLUMN content longtext;
ALTER TABLE email_message MODIFY COLUMN attachment_info longtext;
SELECT * FROM email_message WHERE email_id = 1769048333217234946;

SELECT * FROM email_message WHERE sender_email = "test2@taku.com" and status="draft";
-- 加两列看发件人是否删除以及收件人是否删除。
ALTER TABLE email_message
ADD COLUMN sender_deleted BOOLEAN NOT NULL DEFAULT FALSE,
ADD COLUMN recipient_deleted BOOLEAN NOT NULL DEFAULT FALSE;

-- 加两列看发件人是否删除以及收件人是否彻底删除。
ALTER TABLE email_message
ADD COLUMN confirm_sender_deleted BOOLEAN DEFAULT FALSE,
ADD COLUMN confirm_recipient_deleted BOOLEAN DEFAULT FALSE;

-- 加一列多选的用户
ALTER TABLE email_message ADD COLUMN recipients longtext;


INSERT INTO user_message (email) VALUES ('multipleRecipients@example.com');

-- 创建一个待送邮件的列表
CREATE TABLE scheduled_email (
    email_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    sender_email VARCHAR(255) NOT NULL,
    recipient_email VARCHAR(255) NOT NULL, -- 单个收件人,因为只有hr能群发
    subject VARCHAR(255),
    content LONGTEXT, -- 邮件内容，使用 LONGTEXT 以兼容大文本
    attachment_info LONGTEXT, -- 附件信息，也使用 LONGTEXT
    scheduled_time DATETIME, -- 预定发送时间
    status VARCHAR(50) DEFAULT 'scheduled', -- 默认状态为'scheduled'
    creation_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_email) REFERENCES user_message(email),
    FOREIGN KEY (recipient_email) REFERENCES user_message(email) -- 外键指向user_message表
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

select * from scheduled_email;


