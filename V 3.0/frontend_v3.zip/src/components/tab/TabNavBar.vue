<!-- 主页面母版页头（标签导航栏）子组件 -->
<template>
  <fragment>
    <el-tabs ref="tabs" v-model="editableTabsValue" type="border-card" closable @tab-click="handleTabClick" 
    @tab-remove="handleTabRemove">
      <el-tab-pane
        v-for="item in this.$store.state.editableTabs"
        :key="item.name"
        :name="item.name">
        <span slot="label" @contextmenu.prevent="RightClickMenu(item, $event)"> <i :class="item.icon"></i> {{ item.title }}</span>
      </el-tab-pane>
      <!-- 鼠标右键显示关闭菜单内容 -->
      <ul class="contextmenu" v-show="menuShow" :style="`top:${menuPosition.y}px;left:${menuPosition.x}px;`">
        <li class="menu_item" @click="clickMenuItem(item.method)" v-for="item in menuContent" :key="item.title">
          {{ item.title }}
        </li>
      </ul>
      <!-- <ul v-show="menuShow" :style="`top:${menuPosition.y}px;left:${menuPosition.x}px;`">
          <li @click="clickMenuItem(item.method)" v-for="item in menuContent" :key="item.title">
              {{ item.title }}
          </li>
      </ul> -->
      <!-- 路由视图对象 -->
      <router-view></router-view>
    </el-tabs>
  </fragment>
</template>





<!-- 直接复制 -->
<!-- <el-tabs ref="tabs" v-model="editableTabsValue" type="border-card" 
      tab-position="top" closable @tab-remove="handleTabRemove" @tab-click="handleTabClick">
          <el-tab-pane
           v-for="item in this.$store.state.editableTabs"
          :key="item.name"
          :name="item.name">
          <span slot="label" @contextmenu.prevent="RightClickMenu(item)"><i :class="item.icon"></i> {{item.title}}</span>
          </el-tab-pane> -->
          <!-- 鼠标右键显示关闭菜单内容 -->
          <!-- <ul v-show="menuShow" :style="`top:${menuPosition.y}px;left:${menuPosition.x}px;`">
              <li @click="clickMenuItem(item.method)" v-for="item in menuContent" :key="item.title">
                  {{ item.title }}
              </li>
          </ul>
          <router-view></router-view>
      </el-tabs> -->
<script>
export default {
name: 'TagNavBar',
data() {
    return {
      // tab标签绑定值，选中选项卡的 name
      editableTabsValue: '',
      // 鼠标右键菜单位置
      menuPosition: {
        x: 0,
        y: 0
      },
      // 鼠标右键菜单内容
      menuContent: [
        { title: 'close', method: "menuClose" },
        { title: 'close left', method: "menuCloseLeft" },
        { title: 'close right', method: "menuCloseRight" },
        { title: 'close other', method: "menuCloseOther" },
      ],
      /* 是否显示鼠标右键的菜单 */
      menuShow: false,
      // 点击的tab名称
      clickName: ''
    }
  },
  watch: {
    '$store.state.editableTabsValue': {
      handler(last, first) {
        this.editableTabsValue = last
        // 只要上面的发生变化就储存起来
        sessionStorage.setItem('editableTabsValue', last);
      }
    },
    '$store.state.activeMenu': {
      handler(last, first) {
        sessionStorage.setItem('activeMenu', last);
      }
    },
    '$store.state.editableTabs': {
      handler(last, first) {
        sessionStorage.setItem('editableTabs', JSON.stringify(last));
      }
    }
  },
  methods: {
    // tab 被选中时触发的事件
    handleTabClick(tab, event){
      this.$store.state.activeMenu = tab.name;
      this.$store.state.editableTabsValue = tab.name;
      // 判断当前url地址和即将跳转的是否一致，不一致进行跳转，防止跳转多次
      if ('/' + tab.name + '' !== this.$route.path) {
        // 用path的跳转方法把当前项的name当作地址跳转。
        this.$router.push({ path: tab.name });
      }
    },
    /* 右击鼠标显示菜单 */
    RightClickMenu(item, event) {
      // 去掉浏览器默认事件
      event.preventDefault();
      // 设置点击的tab名称用于获取位置，这里直接使用Vue的响应式数据
      this.clickName = item.title;

      // 获取当前鼠标坐标来设置菜单栏的位置
      this.menuPosition.y = event.clientY;
      this.menuPosition.x = event.clientX + 5;

      // 显示菜单栏
      this.menuShow = true;
      // // 获取tab列表dom元素
      // let tabs = this.$refs.tabs
      // // 获取tab列表的子dom列表
      // let tabDom = tabs.$el.querySelectorAll('div[role=tab]')
      // // 循环配置右击事件
      // tabDom.forEach(e=>{
      //   // 触发右击事件的方法
      //   e.oncontextmenu = (el) => { 
      //     // e.button === 2: 右键被点击
      //     if ('/' + item.name + '' == this.$route.path) { 
      //       // 设置点击的tab名称 用于获取位置
      //       this.clickName = el.path[0].innerText.trim();
      //       // 去掉浏览器默认事件
      //       el.preventDefault();
      //       // 获取当前鼠标坐标来设置菜单栏的位置
      //       this.menuPosition.y = el.clientY;
      //       this.menuPosition.x = el.clientX + 5;
      //       // 显示菜单栏
      //       this.menuShow = true;
      //     }
      //   }
      // });

    },
    /* 鼠标右键菜单项点击事件 */
    clickMenuItem(method) {
      switch (method){
        // 关闭
        case 'menuClose':
          // 调用关闭方法
          this.menuClose()
          break;
        // 关闭左侧
        case 'menuCloseLeft':
          this.menuCloseLeft()
          break;
        // 关闭右侧
        case 'menuCloseRight':
          this.menuCloseRight()
          break;
        // 关闭其他
        case 'menuCloseOther':
          this.menuCloseOther()
          break;
      }
    },
    /* 菜单项关闭按钮方法 */
    menuClose() {
      this.handleTabRemove(this.editableTabsValue)
    },
    /* 菜单项关闭左侧 */
    // menuCloseLeft() {
    //   this.$store.state.editableTabs.find(e => {
    //     if (e.title !== this.clickName) {
    //       this.removeTab(e.name)
    //     }
    //     return e.title == this.clickName
    //   })
    // },
    menuCloseLeft() {
      const currentIndex = this.$store.state.editableTabs.findIndex(tab => tab.title === this.clickName);
      // 保留当前点击的标签页以及其右侧的所有标签页
      const remainingTabs = this.$store.state.editableTabs.slice(currentIndex);
      this.$store.state.editableTabs = remainingTabs;

      // 如果当前激活的标签页在关闭的标签页之中，则将当前点击的标签页设置为新的激活标签页
      if (!remainingTabs.some(tab => tab.name === this.editableTabsValue)) {
        this.updateRoute(this.clickName);
      }
    },
    /* 菜单项关闭右侧 */
    menuCloseRight() {
      this.$store.state.editableTabs.slice().reverse().find(e => {
        if (e.title !== this.clickName) {
          this.removeTab(e.name)
        }
        return e.title == this.clickName
      })
    },
    /* 菜单项关闭其他*/ 
    menuCloseOther() {
      // 关闭其他标签页
      this.$store.state.editableTabs = this.$store.state.editableTabs.filter(e => e.title === this.clickName);
      // 如果当前激活的标签页不是点击的标签页，则需要更改路由
      if (this.editableTabsValue !== this.$store.state.editableTabs[0].name) {
        this.updateRoute(this.$store.state.editableTabs[0].name);
      }
    },
    /* 更新路由 */ 
    updateRoute(name) {
      // 更新当前激活的标签页
      this.editableTabsValue = name;
      this.$store.state.activeMenu = name;
      // 更改路由地址
      if ('/' + name !== this.$route.path) {
        this.$router.push({ path: name });
      }
    },
    /* 隐藏鼠标右键菜单 */
    hideMenu() {
      this.menuShow = false
    },
    // 移除tab标签
    removeTab(targetName) {
      // 隐藏右击菜单
      this.hideMenu();
      this.$store.commit("removeTab",targetName);
    },
    /* 处理tab标签x按钮的移除 */
    handleTabRemove(targetName){
      /* 1、从editableTabs中移除当前tab标签 */
      this.removeTab(targetName);
      /* 2、更改路由地址 */
      // 判断当前tabs列表中是否还有元素，有才进行以下操作，没有就不进行任何操作
      if (this.$store.state.editableTabs.length > 0) {
        // 获取tabs列表中的最后一个tab,就是当你删除前一个标签时,自动获取到下有一个标签的tab和url
        let lastTag = this.$store.state.editableTabs.slice(-1)
        // 更改路由地址
        // 判断当前url地址和即将跳转的是否一致，不一致进行跳转，防止跳转多次
        if ('/' + lastTag[0].name + '' !== this.$route.path) {
          // 用path的跳转方法把当前项的name当作地址跳转。
          this.$router.push({ path: lastTag[0].name })
        }
        // 更改tab标签绑定值，选中选项卡的 name
        this.$store.state.editableTabsValue = lastTag[0].name
        // 更改当前激活的菜单
        this.$store.state.activeMenu = lastTag[0].name
      }else{
        this.$store.state.activeMenu = ''
        this.$store.state.editableTabsValue = ''
        this.$store.state.editableTabs = []
      }
    }
  },
  beforeUnmount() {
    // 页面卸载时去除监听 防止占用资源
    document.body.removeEventListener('click', this.hideMenu)
  },
  beforeMount() {
    /* 从sessionStorage中获取存储的tab标签列表和tab标签绑定值以及当前激活的菜单 */
    if (sessionStorage.getItem('activeMenu') != null && sessionStorage.getItem('editableTabsValue') != null && sessionStorage.getItem('editableTabs') != null){
      this.$store.state.activeMenu = sessionStorage.getItem('activeMenu');
      this.$store.state.editableTabsValue = sessionStorage.getItem('editableTabsValue');
      this.$store.state.editableTabs = JSON.parse(sessionStorage.getItem('editableTabs'));
      this.editableTabsValue = sessionStorage.getItem('editableTabsValue')
    } else {
      // 初始化赋值
      this.editableTabsValue = this.$store.state.editableTabsValue
    }
  },
  mounted() {
    // 监听全页面，如果有点击就隐藏右击菜单
    document.body.addEventListener('click', this.hideMenu)
  }











// data() {
//   return {
//     // tab标签绑定值，选中选项卡的 name
//     editableTabsValue: '',
//     // 鼠标右键菜单位置
//     menuPosition: {
//       x: 0,
//       y: 0
//     },
//     // 鼠标右键菜单内容
//     menuContent: [
//       { title: 'close', method: "menuClose" },
//       { title: 'close left', method: "menuCloseLeft" },
//       { title: 'close right', method: "menuCloseRight" },
//       { title: 'close other', method: "menuCloseOther" },
//     ],
//     // 是否显示鼠标右键的菜单
//     menuShow: false,
//     // 点击的tab名称
//     clickName: ''
//   }
// },
// watch: {
//   '$store.state.editableTabsValue': {
//     handler(last, first) {
//       this.editableTabsValue = last
//       sessionStorage.setItem('editableTabsValue', last);
//     }
//   },
//   '$store.state.activeMenu': {
//     handler(last, first) {
//       sessionStorage.setItem('activeMenu', last);
//     }
//   },
//   '$store.state.editableTabs': {
//     handler(last, first) {
//       sessionStorage.setItem('editableTabs', JSON.stringify(last));
//     }
//   }
// },
// methods: {
//   // tab 被选中时触发
//   handleTabClick(tab, event) {
//     this.$store.state.activeMenu = tab.name
//     sessionStorage.setItem('activeMenu', tab.name);
//     this.$store.state.editableTabsValue = tab.name;
//     sessionStorage.setItem('editableTabsValue', tab.name);
//     // 判断当前url地址和即将跳转的是否一致，不一致进行跳转，防止跳转多次
//     if ('/' + tab.name + '' !== this.$route.path) {
//       // 用path的跳转方法把当前项的name当作地址跳转。
//       this.$router.push({ path: tab.name });
//     }
//   },
//   /* 右击鼠标显示菜单 */
//   RightClickMenu(item) {
//     // 获取tab列表dom
//     let tabs = this.$refs.tabs
//     // 获取tab列表的子dom列表
//     let tabDom = tabs.$el.querySelectorAll('div[role=tab]')
//     // 循环配置右击事件
//     tabDom.forEach(e => {
//       // 触发右击事件的方法
//       e.oncontextmenu = (el) => {
//         // e.button === 2: 右键被点击
//         if (el.button == 2 && '/' + item.name + '' == this.$route.path) {
//           // 设置点击的tab名称 用于获取位置
//           this.clickName = el.path[0].innerText.trim()
//           // 去掉浏览器默认事件
//           el.preventDefault()
//           // 获取当前鼠标坐标来设置菜单栏的位置
//           this.menuPosition.y = event.clientY
//           this.menuPosition.x = event.clientX + 5
//           // 显示菜单栏
//           this.menuShow = true
//         }
//       }
//     });
//   },
//   /* 鼠标右键菜单项点击事件 */
//   clickMenuItem(method) {
//     switch (method) {
//       case 'menuClose':
//         this.menuClose()
//         break;
//       case 'menuCloseLeft':
//         this.menuCloseLeft()
//         break;
//       case 'menuCloseRight':
//         this.menuCloseRight()
//         break;
//       case 'menuCloseOther':
//         this.menuCloseOther()
//         break;
//     }
//   },
//   /* 菜单项关闭按钮方法 */
//   menuClose() {
//     this.handleTabRemove(this.editableTabsValue)
//   },
//   menuCloseLeft() {
//     this.$store.state.editableTabs.find(e => {
//       if (e.title !== this.clickName) {
//         this.removeTab(e.name)
//       }
//       return e.title == this.clickName
//     })
//   },
//   menuCloseRight() {
//     this.$store.state.editableTabs.slice().reverse().find(e => {
//       if (e.title !== this.clickName) {
//         this.removeTab(e.name)
//       }
//       return e.title == this.clickName
//     })
//   },
//   menuCloseOther() {
//     this.$store.state.editableTabs.map(e => {
//       if (e.title !== this.clickName) {
//         this.removeTab(e.name)
//       }
//     })
//   },
//   /* 隐藏鼠标右键菜单 */
//   hideMenu() {
//     this.menuShow = false
//   },
//   /* 移除tab标签公用方法 */
//   removeTab(targetName) {
//     /* 隐藏鼠标右键菜单 */
//     this.hideMenu()
//     this.$store.commit("removeTab", targetName)
//   },
//   /* 处理tab标签x按钮的移除 */
//   handleTabRemove(targetName) {
//     /* 1、从editableTabs中移除当前tab标签 */
//     this.removeTab(targetName)
//     /* 2、更改路由地址 */
//     // 判断当前tabs列表中是否还有元素，有才进行以下操作，没有就不进行任何操作
//     if (this.$store.state.editableTabs.length > 0) {
//       // 获取tabs列表中的最后一个tab
//       let lastTag = this.$store.state.editableTabs.slice(-1)
//       // 更改路由地址
//       // 判断当前url地址和即将跳转的是否一致，不一致进行跳转，防止跳转多次
//       if ('/' + lastTag[0].name + '' !== this.$route.path) {
//         // 用path的跳转方法把当前项的name当作地址跳转。
//         this.$router.push({ path: lastTag[0].name })
//       }
//       // 更改tab标签绑定值，选中选项卡的 name
//       this.$store.state.editableTabsValue = lastTag[0].name
//       // 更改当前激活的菜单
//       this.$store.state.activeMenu = lastTag[0].name
//     } else {
//       this.$store.state.activeMenu = ''
//       this.$store.state.editableTabsValue = ''
//       this.$store.state.editableTabs = []
//     }
//   }
// },
// beforeUnmount() {
//   // 页面卸载时去除监听 防止占用资源
//   document.body.removeEventListener('click', this.hideMenu)
// },
// created() {},
// beforeMount() {
//   /* 从sessionStorage中获取存储的tab标签列表和tab标签绑定值以及当前激活的菜单 */
//   if (sessionStorage.getItem('activeMenu') != null &&
//     sessionStorage.getItem('editableTabsValue') != null &&
//     sessionStorage.getItem('editableTabs') != null) {
//     this.$store.state.activeMenu = sessionStorage.getItem('activeMenu');
//     this.$store.state.editableTabsValue = sessionStorage.getItem('editableTabsValue');
//     this.$store.state.editableTabs = JSON.parse(sessionStorage.getItem('editableTabs'));
//     this.editableTabsValue = sessionStorage.getItem('editableTabsValue')
//   } else {
//     // 初始化赋值
//     this.editableTabsValue = this.$store.state.editableTabsValue
//   }
// },
// mounted() {
//   // 监听全页面，如果有点击就隐藏右击菜单
//   document.body.addEventListener('click', this.hideMenu)
// }
}
</script>

<style lang="less" scoped>
::v-deep .el-tabs__nav-scroll {
  background-color: #cce0c5 !important; /* 替换为你选择的颜色值 */
}
/* 设置所有未选中的标签页的样式 */
::v-deep .el-tabs__item {
    color: #245e17 !important; /* 未选中标签页的文字颜色 */
    background-color: #cce0c5 !important;
    // border: 2px solid #000000; /* 未选中标签页的边框 */
}

/* 设置选中的标签页的样式 */
::v-deep .el-tabs__item.is-active {
    // color: #245e17 !important; /* 选中标签页的文字颜色 */
    color: #245e17 !important; /* 选中标签页的文字颜色 */
    background-color: #e3e6d0 !important; /* 选中标签页的背景颜色 */
    border: 2px 2px 0px 2px solid #6D8B74 !important; /* 选中标签页的边框 */
}

/* 可能还需要设置鼠标悬停的样式 */
::v-deep .el-tabs__item:hover {
    background-color: #6D8B74 !important; /* 鼠标悬停时标签页的背景颜色 */
    // color: #245e17 !important;
    color: #d0e7cb !important;
}

/* 右键菜单样式 */
// 大的列表的整体样式
.contextmenu {
position: fixed;
top: 0;
left: 0;
list-style-type: none;
padding: 5px;
border-radius: 4px;
font-size: 12px;
font-weight: 400;
color: #333;
transition: 0.3s;
background-color: #EFEAD8;
z-index: 100;
box-shadow: 2px 2px 3px 0 rgba(0, 0, 0, .3);
// 列表项的样式
.menu_item {
  margin: 0;
  padding: 7px 16px;
  /* 鼠标样式 */
  cursor: pointer;
  /* 悬停激活背景颜色 */
  &:hover {
    background: #beb79d;
  }
}
}
</style>
