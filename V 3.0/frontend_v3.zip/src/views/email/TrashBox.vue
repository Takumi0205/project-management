<!-- 垃圾箱视图 -->
<template>
  <div class="body">
    <div class="search-box">
        <el-input
        v-model="searchQuery"
        placeholder="Search emails..."
        class="input-with-select"
        >
            
        </el-input>
        <el-button class="search-button custom-button" slot="append" icon="el-icon-search" @click="searchEmails"></el-button>
        <el-button class="back-button custom-button" icon="el-icon-arrow-left" @click="resetSearch"></el-button>
    </div>
    <el-table
      :data="tableData"
      height="76vh"
      ref="multipleTable"
      tooltip-effect="dark"
      border
      :row-class-name="tableRowClassName"
      empty-text="No emails found in the transh box."
      style="width: 100%">
      <!-- 选择框 -->
      <el-table-column type="selection" width="55"></el-table-column>
      <!-- 序号 -->
      <el-table-column type="index" :index="indexMethod"></el-table-column>
      <!-- 时间 -->
      <el-table-column prop="updateTime" label="Date" width="115"></el-table-column>
      <!-- 发件人 -->
      <el-table-column prop="senderEmail" label="Sender" show-overflow-tooltip></el-table-column>
      <!-- 收件人 -->
      <el-table-column prop="recipientEmail" label="Recipient" show-overflow-tooltip></el-table-column>
      <!-- 主题 -->
      <el-table-column prop="subject" label="Subject" width="250" show-overflow-tooltip></el-table-column>
      <!-- 内容 -->
      <el-table-column prop="content" label="Content" width="250" show-overflow-tooltip></el-table-column>
      <!-- 附件信息 -->
      <el-table-column label="Attachment" width="160" show-overflow-tooltip>
        <template v-slot="{ row }">
          <span v-if="getAttachmentCount(row.attachmentInfo)">
            {{ getAttachmentCount(row.attachmentInfo) }} attachments
          </span>
          <span v-else>No attachment</span>
        </template>
      </el-table-column>
      <!-- 状态 -->
      <!-- <el-table-column prop="status" label="Status" width="120"></el-table-column> -->
      <!-- 操作 -->
      <el-table-column fixed="right" label="Operation" >
        <template v-slot="{ row }">
            <el-button @click="viewEmail(row.emailId)" type="text" size="small">View</el-button>
            <el-button @click="deleteForever(row.emailId)" type="text" size="small">Delete</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
    name: "TrashBox",
    data() {
        return {
            tableData: [],
            searchQuery: '',
        };
    },
    methods: {
        // loadTrashboxEmails(){
        //   const userEmail = localStorage.getItem('userEmail');
        //   if(userEmail){
        //     this.axios.get(`http://localhost:3759/email-web/trashbox?email=${userEmail}`)
        //     .then(response => {
        //         this.tableData = response.data.map(email => ({
        //             ...email,
        //             updateTime: this.formatDate(email.updateTime)
        //         }));
        //     }).catch(error => {
        //         console.error("Error fetching trashbox emails:", error);
        //     });
        //   } else {
        //       console.error("User email is not found in localStorage.");
        //   }
        // },
        loadTrashboxEmails() {
          const userEmail = localStorage.getItem('userEmail');
          if (!userEmail) {
              console.error("User email is not found in localStorage.");
              this.$message.error('User email not found. Please log in.');
              return;
          }

          // 构造获取垃圾箱邮件的基础URL
          let url = `http://localhost:3759/email-web/trashbox?email=${encodeURIComponent(userEmail)}`;
          // 如果存在搜索查询，则附加搜索查询
          if (this.searchQuery.trim()) {
              url += `&query=${encodeURIComponent(this.searchQuery.trim())}`;
          }

          this.axios.get(url)
              .then(response => {
                  this.tableData = response.data.map(email => {
                      email.updateTime = this.formatDate(email.updateTime);
                      return email;
                  });
                  // 如果未找到邮件，可以在此处理，例如，显示消息
                  if (this.tableData.length === 0) {
                      this.$message.info('No emails found in the trashbox.');
                  }
              })
              .catch(error => {
                  console.error("Error loading trashbox emails:", error);
                  this.$message.error('Failed to load trashbox emails');
              });
        },

        indexMethod(index) {
            return index + 1;
        },
        viewEmail(emailId) {
            // 实现跳转到邮件详细查看页面的逻辑
            this.$router.push({ name: 'ViewEmail', params: { emailId: emailId }});
        },
        deleteForever(emailId) {
          this.$confirm('Are you sure you want to permanently delete this email?', 'Warning', {
              confirmButtonText: 'Yes',
              cancelButtonText: 'No',
              type: 'warning'
          }).then(() => {
              // 用户确认删除后的逻辑
              this.axios.delete(`http://localhost:3759/email-web/trashbox/${emailId}`, {
                  params: { email: localStorage.getItem('userEmail') } // Assuming userEmail is stored in the component's data
              })
                .then(() => {
                    this.$message.success('Email has been permanently deleted.');
                    // 成功删除后，重新加载或更新列表，这里假设有一个方法loadTrashboxEmails来重新加载垃圾箱邮件
                    this.loadTrashboxEmails();
                })
                .catch(error => {
                    console.error("Error permanently deleting email:", error);
                    this.$message.error('Failed to permanently delete the email.');
                });
          }).catch(() => {
              this.$message.info('Deletion cancelled.');
          });
      },
        formatDate(date) {
            // return this.$moment(date).format('YYYY-MM-DD HH:mm:ss');
            return this.$moment(date).format('YYYY-MM-DD');
        },
        getAttachmentCount(attachmentInfo) {
            if (attachmentInfo) {
                try {
                    const attachments = JSON.parse(attachmentInfo);
                    return attachments.length;
                } catch (error) {
                    console.error('Error parsing attachmentInfo:', error);
                }
            }
            return 0;
        },
        tableRowClassName({row}) {
            // 这里可以根据需要设置行的样式
        },
        searchEmails() {
            const userEmail = localStorage.getItem('userEmail');
            if (userEmail && this.searchQuery.trim()) {
            this.axios.get(`http://localhost:3759/email-web/trashbox/search`, { params: { email: userEmail, query: this.searchQuery }})
                .then(response => {
                this.tableData = response.data.map(email => {
                    email.updateTime = this.formatDate(email.updateTime);
                    return email;
                });
                })
                .catch(error => {
                console.error("Error searching emails:", error);
                });
            } else {
            console.error("Recipient email is not found in localStorage or search query is empty.");
            }
        },
        resetSearch() {
            this.searchQuery = ''; // 重置搜索查询
            this.loadTrashboxEmails(); // 重新加载或显示全部邮件
        },
    },
    mounted() {
      const userEmail = localStorage.getItem('userEmail');
      if(userEmail){
        this.axios.get(`http://localhost:3759/email-web/trashbox?email=${userEmail}`)
        .then(response => {
            this.tableData = response.data.map(email => ({
                ...email,
                updateTime: this.formatDate(email.updateTime)
            }));
        }).catch(error => {
            console.error("Error fetching trashbox emails:", error);
        });
      } else {
          console.error("User email is not found in localStorage.");
      }
    }
}
</script>


<style lang="less" scoped>
.body {

    // max-width: 100vw; // 最大宽度不超过视口宽度
    // max-height: 84vh; // 最大高度不超过视口高度

    .search-box {
        display: flex;
        align-items: center; // 垂直居中对齐
        gap: 10px; // 在元素之间添加一些间隙
        padding-bottom: 10px; // 为搜索框和返回按钮底部添加一些间距

        .custom-button {
            display: flex; /* 启用Flexbox */
            justify-content: center; /* 水平居中内容 */
            align-items: center; /* 垂直居中内容 */
            width: 60px; /* 按钮宽度 */
        }
        .search-button{
            background-color: #eef1d7;
            color: #2f4d37;
            margin-left: 5px;
            &:hover {
                background: #cedac9;
                color: #2f4d37;
            }
        }
        .back-button {
            background-color: #eef1d7;
            color: #2f4d37;
            margin-left: 5px; 

            &:hover {
                background: #cedac9;
                color: #2f4d37;
            }
        }
    }
    // 每一行的背景颜色
    ::v-deep .el-table__row{
        background-color: #e3e6d0;
        color: #2f4d37;
    }
    // 表格表头背景颜色
    ::v-deep .el-table--border th.el-table__cell {
        background-color: #cedac9;
        color: #2f4d37;
    }
    //剩下表格的背景的颜色
    ::v-deep .el-table, .el-table__expanded-cell {
        background-color: transparent;
    }
    //设置当鼠标移动的时候的行背景颜色
    ::v-deep .el-table__body tr:hover > td{
        background-color:#cfd2bd !important;
    }
    //设置当鼠标移动的时候的行背景颜色
    ::v-deep .el-table__body .el-table__row.hover-row td {
        background-color: #cfd2bd !important;
        font-weight: bolder;
    }
    .el-table {
        .warning-row {
            background: oldlace;
        }
        .success-row {
            background: #f0f9eb;
        }
    }
    
    .no-emails-message {
        padding: 20px;
        text-align: center;
        color: #666;
    }
}
</style>