<!-- 发件箱视图 -->
<template>
  <div class="body">
    <div class="search-box">
        <el-input
        v-model="searchQuery"
        placeholder="Search emails..."
        class="input-with-select"
        >  
        </el-input>
        <el-button class="search-button custom-button" slot="append" icon="el-icon-search" @click="searchEmails"></el-button>
        <el-button class="back-button custom-button" icon="el-icon-arrow-left" @click="resetSearch"></el-button>
    </div>
    <el-table
      ref="multipleTable"
      :data="tableData"
      :row-class-name="tableRowClassName"
      tooltip-effect="dark"
      border
      height="76vh"
      empty-text="No emails found in the outbox."
      style="width: 100%">
      <!-- 选择框 -->
      <el-table-column
        type="selection"
        width="55">
      </el-table-column>
      <!-- 序号 -->
      <el-table-column
        type="index"
        :index="indexMethod">
      </el-table-column>
      <!-- 日期 -->
      <el-table-column
        prop="updateTime"
        label="Date"
        width="95"
        show-overflow-tooltip>
      </el-table-column>
      <!-- 发件人 -->
      <el-table-column
        prop="senderEmail"
        label="Sender"
        width="140"
        show-overflow-tooltip>
      </el-table-column>
      <!-- 收件人 -->
      <el-table-column
        prop="recipientEmail"
        label="Recipient"
        width="140"
        show-overflow-tooltip>
      </el-table-column>
      <!-- 主题 -->
      <el-table-column
        prop="subject"
        label="Subject"
        show-overflow-tooltip>
      </el-table-column>
      <!-- 内容 -->
      <el-table-column
        prop="content"
        label="Content"
        show-overflow-tooltip>
      </el-table-column>
      <!-- 附件数量 -->
      <el-table-column
        label="Attachment"
        width="120"
        show-overflow-tooltip>
        <template v-slot="{ row }">
          <span v-if="getAttachmentCount(row.attachmentInfo)">
            {{ getAttachmentCount(row.attachmentInfo) }} attachments
          </span>
          <span v-else>No attachment</span>
        </template>
      </el-table-column>
      <!-- 状态 -->
      <el-table-column
        prop="status"
        label="Status"
        width="100">
      </el-table-column>
      <!-- 操作 -->
      <el-table-column
      fixed="right"
      label="Operation"
      width="100">
        <template v-slot="{ row }">
            <el-button @click="viewEmail(row.emailId)" type="text" size="small">View</el-button>
            <el-button @click="deleteEmail(row.emailId)" type="text" size="small">Delete</el-button>
        </template>
      </el-table-column>

    </el-table>
  </div>
</template>


<script>
export default {
    name: "Outbox", 
    data() {
        return {
        tableData: [],
        searchQuery: '',
        };
    },
    methods: {
      // loadEmials(){
      //   const senderEmail = localStorage.getItem('userEmail');
      //   if(senderEmail){
      //       this.axios.get(`http://localhost:3759/email-web/outbox?email=${senderEmail}`)
      //       .then(response => {
      //           this.tableData = response.data.map(item => ({
      //           ...item,
      //           updateTime: this.formatDate(item.updateTime),
      //           }));
      //       })
      //       .catch(error => console.error("Error fetching sent items:", error));
      //   } else {
      //       console.error("Sender email is not found in localStorage.");
      //   }
      // },
        loadEmails() {
            const senderEmail = localStorage.getItem('userEmail');
            if (!senderEmail) {
                console.error("User email is not found in localStorage.");
                this.$message.error('User email not found. Please log in.');
                return;
            }

            // 构造获取发件箱邮件的基础URL
            let url = `http://localhost:3759/email-web/outbox?email=${encodeURIComponent(senderEmail)}`;
            // 如果存在搜索查询，则附加搜索查询
            if (this.searchQuery.trim()) {
                url += `&query=${encodeURIComponent(this.searchQuery.trim())}`;
            }

            this.axios.get(url)
                .then(response => {
                    this.tableData = response.data.map(item => {
                        item.updateTime = this.formatDate(item.updateTime);
                        return item;
                    });
                    if (this.tableData.length === 0) {
                        this.$message.info('No outbox found.');
                    }
                })
                .catch(error => {
                    console.error("Error loading outbox:", error);
                    this.$message.error('Failed to load outbox');
                });
        },
        indexMethod(index) {
            return index + 1;
        },
        viewEmail(emailId) {
            this.$router.push({ name: 'ViewEmail', params: { emailId: emailId } });
        },
        deleteEmail(emailId) {
            this.$confirm('Are you sure you want to delete this email?', 'Warning', {
                confirmButtonText: 'OK',
                cancelButtonText: 'Cancel',
                type: 'warning'
            }).then(() => {
                this.axios.delete(`http://localhost:3759/email-web/outbox/${emailId}`)
                    .then(response => {
                        // 检查状态码，以确保操作成功
                        if (response.status === 200) {
                            this.$message.success('Outbox deleted email successfully');
                            // 确保在这里重新加载收件箱列表，而不是跳转，如果是要刷新当前页面的数据
                            this.loadEmails(); // 重新加载收件箱的方法
                        } else {
                            // 如果状态码不是200，但请求被.then()捕获，说明有一个问题需要检查
                            console.error("Unexpected response status:", response);
                            this.$message.error('Failed to delete emial');
                        }
                    })
                    .catch(error => {
                        console.error("Error deleting draft:", error);
                        this.$message.error('Failed to delete draft');
                    });
            }).catch(() => {
                this.$message.info('Delete canceled');
            });
        },
        formatDate(date) {
            return this.$moment(date).format('YYYY-MM-DD'); // 格式化日期
        },
        getAttachmentCount(attachmentInfo) {
            try {
                const attachments = JSON.parse(attachmentInfo);
                return attachments ? attachments.length : 0;
            } catch (e) {
                return 0;
            }
        },
        tableRowClassName({row}) {
            // console.log("row:", row.status);
            if(row.status === 'sent') {
                return 'success-row';
            }  
            else if (row.status === 'failed') {
                return 'warning-row';
            }
            else {
                return '';
            }
        },
        searchEmails() {
            const userEmail = localStorage.getItem('userEmail');
            if (userEmail && this.searchQuery.trim()) {
            this.axios.get(`http://localhost:3759/email-web/outbox/search`, { params: { email: userEmail, query: this.searchQuery }})
                .then(response => {
                this.tableData = response.data.map(email => {
                    email.updateTime = this.formatDate(email.updateTime);
                    return email;
                });
                })
                .catch(error => {
                console.error("Error searching emails:", error);
                });
            } else {
            console.error("Recipient email is not found in localStorage or search query is empty.");
            }
        },
        resetSearch() {
            this.searchQuery = ''; // 重置搜索查询
            this.loadEmails(); // 重新加载或显示全部邮件
        },
    },
    mounted() {
      const senderEmail = localStorage.getItem('userEmail');
      if(senderEmail){
          this.axios.get(`http://localhost:3759/email-web/outbox?email=${senderEmail}`)
          .then(response => {
              this.tableData = response.data.map(item => ({
              ...item,
              updateTime: this.formatDate(item.updateTime),
              }));
          })
          .catch(error => console.error("Error fetching sent items:", error));
      } else {
          console.error("Sender email is not found in localStorage.");
      }
    },
}
</script>

<style lang="less" scoped>
.body {
    max-width: 100vw; // 最大宽度不超过视口宽度
    max-height: 84vh; // 最大高度不超过视口高度

    .search-box {
        display: flex;
        align-items: center; // 垂直居中对齐
        gap: 10px; // 在元素之间添加一些间隙
        padding-bottom: 10px; // 为搜索框和返回按钮底部添加一些间距

        .custom-button {
            display: flex; /* 启用Flexbox */
            justify-content: center; /* 水平居中内容 */
            align-items: center; /* 垂直居中内容 */
            width: 60px; /* 按钮宽度 */
        }
        .search-button{
            background-color: #eef1d7;
            color: #2f4d37;
            margin-left: 5px;
            &:hover {
                background: #cedac9;
                color: #2f4d37;
            }
        }
        .back-button {
            background-color: #eef1d7;
            color: #2f4d37;
            margin-left: 5px; 

            &:hover {
                background: #cedac9;
                color: #2f4d37;
            }
        }
    }
    // 每一行的背景颜色
    ::v-deep .el-table__row{
        background-color: #e3e6d0;
        color: #2f4d37;
    }
    // 表格表头背景颜色
    ::v-deep .el-table--border th.el-table__cell {
        background-color: #cedac9;
        color: #2f4d37;
    }
    //剩下表格的北京的颜色
    ::v-deep .el-table, .el-table__expanded-cell {
        background-color: transparent;
    }
    //设置当鼠标移动的时候的行背景颜色
    ::v-deep .el-table__body tr:hover > td{
        background-color:#cfd2bd !important;
    }
    //设置当鼠标移动的时候的行背景颜色
    ::v-deep .el-table__body .el-table__row.hover-row td {
        background-color: #cfd2bd !important;
        font-weight: bolder;
    }
    .el-table {
        .warning-row {
            background: oldlace;
        }
        .success-row {
            background: #f0f9eb;
        }
    }
    
    .no-emails-message {
        padding: 20px;
        text-align: center;
        color: #666;
    }
}
</style>





