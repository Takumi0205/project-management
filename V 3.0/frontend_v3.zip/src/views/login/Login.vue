<template>
    <div>
        <body id="poster">
            <el-form :model="loginForm" :rules="rules" ref="loginForm" class="login-container" label-position="left" label-width="0px">
                <h3 class="login_title">
                    Account Login
                </h3>
                <!-- 原本的 -->
                <!-- <el-form-item label="" prop="email">
                    <el-input type="email" v-model="loginForm.email" autocomplete="off" placeholder="Email"></el-input>
                </el-form-item>
                <el-form-item label="" prop="password">
                    <el-input type="password" v-model="loginForm.password" autocomplete="off" placeholder="Password"></el-input>
                </el-form-item> -->
                <!-- 新的样式 -->
                <el-form-item label="" prop="email">
                    <label :class="{'label-float': formFocus.emailFocused}" for="emailInput" class="custom-placeholder">Email</label>
                    <el-input id="emailInput" type="email" v-model="loginForm.email" autocomplete="off" 
                        @focus="formFocus.emailFocused = true" 
                        @blur="formFocus.emailFocused = !!loginForm.email"></el-input>
                </el-form-item>
                <el-form-item label="" prop="password" style="margin-top: 40px;">
                    <label :class="{'label-float': formFocus.passwordFocused}" for="passwordInput" class="custom-placeholder">Password</label>
                    <el-input id="passwordInput" type="password" v-model="loginForm.password" autocomplete="off"
                        @focus="formFocus.passwordFocused = true" 
                        @blur="formFocus.passwordFocused = !!loginForm.password"></el-input>
                </el-form-item>


                <el-form-item style="width: 100%;">
                    <el-button type="primary" v-on:click="Login()" style="width: 100%; margin-top: 40px;">Login</el-button>        
                </el-form-item>
                <el-form-item style="width: 100%;"> 
                    <el-button type="primary" @click="toRegister()" style="width: 100%;">Register</el-button>
                </el-form-item>
            </el-form>
        </body>
    </div>
  </template>
  
  <script>
    export default {
        name: 'Login',
        data() {
            var checkEmail = (rule, value, callback) => {
                if (!value) {
                    return callback(new Error('Email cannot be empty'));
                }
                const emailPattern = /^[a-zA-Z0-9._-]+@taku.com$/;
                if (!emailPattern.test(value)) {
                    return callback(new Error('Please enter a valid @taku.com email address'));
                }
                callback();
            };
            var validatePass = (rule, value, callback) => {
                if (value === '') {
                    callback(new Error('Please enter password'));
                } else {
                    callback();
                }
            };
            return {
                loginForm: {
                    email: '',
                    password: ''
                },
                formFocus: {
                    emailFocused: false,
                    passwordFocused: false,
                },
                rules: {
                    password: [
                        { validator: validatePass, trigger: 'blur' },
                        { min: 8, max: 15, message:"The password length is 8-15 characters", trigger: 'blur'}
                    ],
                    email: [
                        { validator: checkEmail, trigger: 'blur' },
                        { min: 14, max: 28, message:"The length of the email is 5-19 characters.", trigger: 'blur'}
                    ],
                }
            }
        },
        methods: {
            Login() {
                // 先进行表单验证
                this.$refs.loginForm.validate((valid) => {
                    if (valid) {
                        // 如果表单验证通过，则发送登录请求
                        this.axios.post('http://localhost:3759/email-web/login', this.loginForm).then((response) => {
                            const data = response.data;
                            // 检查后端返回的success字段
                            if (data.success) {
                                // 登录成功逻辑
                                const expirationDuration = 3600000; // 1小时 = 3600000毫秒
                                const expirationTime = new Date().getTime() + expirationDuration;
                                localStorage.setItem('userEmail', this.loginForm.email);// 或者从响应数据中获取，如果服务器返回了email
                                localStorage.setItem("expirationTime", expirationTime.toString());
                                this.$message.success('Log in successfully');
                                this.$router.push({ path: '/Home' });
                            } else {
                                // 登录失败逻辑
                                this.$message.error(data.message || 'Login failed');
                            }
                        }).catch((error) => {
                            // 注意：此处可能捕获到的是网络错误等，而非后端业务逻辑错误
                            console.error('Login request failed', error);
                            // 检查error.response是否存在，以及是否有后端返回的错误信息
                            if (error.response && error.response.data && error.response.data.message) {
                                this.$message.error('Login failed: ' + error.response.data.message);
                            } else {
                                this.$message.error('Login request failed');
                            }
                        });
                    } else {
                        console.log('Validation failed!');
                    }
                });
            },
            toRegister(){
                this.$router.push({path:'/Register'})
            },
        }
    }
  </script>
  <style>

    @font-face {
        font-family: 'HeadingFont';
        src: url('../../fonts/LibreCaslonDisplay-Regular.woff2') format('woff2');
        font-weight: normal;
        font-style: normal;
    }

    @font-face {
        font-family: 'TextFont';
        src: url('../../fonts/Domine-Regular.woff2') format('woff2');
        font-weight: normal;
        font-style: normal;
    }
    
    @font-face {
        font-family: 'TextFont2';
        src: url('../../fonts/LibreCaslonText-Bold.woff2') format('woff2');
        font-weight: normal;
        font-style: normal;
    }

    #poster{
        background-position:center;
        height:100%;
        width:100%;
        background-size: cover;
        position: fixed;
        background-image: url('../../assets/bk04.jpg');
    }

    body{
        margin: 0px;
        padding: 0px;
    }

    .login-container{
        border-radius: 10px;
        background-clip: padding-box;
        margin: 90px auto;
        width: 380px;
        padding: 35px 35px 35px 35px;

        /* 半透明背景 */
        background: rgba(224, 224, 224, 0.5); 
        /* 磨砂效果 */
        backdrop-filter: blur(10px); 
         /* 轻微的边框，增强磨砂效果 */
        border: 1px solid rgba(255, 255, 255, 0.2);
        /* 设置的阴影 */
        box-shadow: 0 0 25px #6e8b74; 
    }

    .login_title{
        font-family: 'HeadingFont';
        margin: 0px auto 45px auto;
        text-align: center;
        color: #505458;
        letter-spacing: 3px;
        font-size: 30px;
    }

    .login-container .el-button{
        /* background: #505458 ; */
        background: #2E3724 ;
        border: none;
        font-family: 'TextFont2';
        font-size: 16px;
        letter-spacing: 8px;
    }
    /* 当聚集到按钮时的样式 */
    .login-container .el-button:hover{
        color:#000000;
        background-color: #73672D;
    }
    /* 为了解决在点击submit按钮后变为蓝色 */
    .login-container .el-button:focus {
        background: #2E3724; /* 按钮原本的背景颜色 */
        color: #FFFFFF; /* 按钮原本的文字颜色 */
        /* border-color: #2E3724; 如果有边框，指定边框颜色 */
    }

    /* 为输入框添加透明背景并去除边框，仅保留底部的下划线 */
    .el-input__inner {
        background-color: transparent !important;
        border: none !important; /* 移除边框 */
        box-shadow: none !important; /* 移除阴影效果 */
        border-bottom: 1.75px solid #4c6a53 !important; /* 仅底部显示边框作为下划线，您可以调整粗细 */
        border-radius: 0 !important; /* 移除圆角效果 */
    }
    /* 调整输入框内部文本的 padding，确保下划线直且位置合适 */

    .el-input__inner:focus {
        border: none !important;
        box-shadow: none !important;
        border-bottom: 1.75px solid #A5732E !important; 
        border-radius: 0 !important; /* 移除圆角效果 */
    }

    /* 实现点击时,placeholder向上移动形成标题 */
    .custom-placeholder {
        position: absolute;
        pointer-events: none;
        left: 15px;
        transition: .5s ease all;
        color: #403A1F;
        transform-origin: left top;
        font-family: 'TextFont';
        font-size: 14px;
        letter-spacing: 1px;
    }

    .label-float {
        transform: translateY(-25px) translateX(2px); /* 向上移动 */
    }
    /* 更改提示字的颜色 */
    .el-form-item__error {
        font-family: 'TextFont';
        font-size: 3px;
        letter-spacing: 1px;
        color: #9e5548 !important; /* 将颜色改为红色，你可以自定义为任何颜色 */
    }
  </style>