<!-- 邮件系统的主页面框架 -->
<template>
  <!-- 顶部导航栏 + 侧边 + 右边主页面（主要活动在此显示） -->
  <div class="home">
    <el-container>
      <!-- 顶部菜单栏部分 -->
      <el-header height="5vh">
        <!-- 1.系统logo -->
        <img src="../../assets/logo.png">
        <!-- 用户登录区域 -->
        <div class="login_user">
          <!-- 登录用户按钮 -->
          <div class="user_btn">
            <!-- <el-avatar class="user-avatar" :src="avatarUrl" :size="35" ></el-avatar> -->
            <el-dropdown @command="handleCommand">
              <span class="el-dropdown-link">
                Me<i class="el-icon-arrow-down el-icon--right"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="viewUser">User Center</el-dropdown-item>
                <el-dropdown-item></el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
            <el-link type="danger" :underline="false" class="logout-link" style="font-size: 16px" @click="logout">exit</el-link>
          </div>
        </div>
      </el-header>
      <el-container>
        <!-- 侧边栏区域 -->
        <!-- 为了加一个点击关闭时有一个过渡动画 -->
        <el-aside style="width: content-box">
          <!-- 1. 主菜单按钮（点击按钮展开收起） -->
          <div class="toggle_box" @click="toggleClick">
            | | |
          </div>
          <!-- 2. 菜单区域 -->
          <!-- active-text-color 当前激活菜单的颜色 -->
          <el-menu :default-active="this.$store.state.activeMenu"
                  class="el-menu-vertical-demo"
                  @open="handleOpen"
                  @close="handleClose"
                  @select="handleSelect"
                  text-color="#000000"
                  :router="true"
                  active-text-color="#699a69"
                  background-color="#cce0c5"
                  :unique-opened="true"
                  :collapse="isCollapse"
                  :style="{ width: isCollapse ? '70px' : menuWidth }">
          <!-- 绑定:menuList这个组件 和菜单vue中的props: ["menuList"]互相绑定 -->
          <MenuTree :menuList="menuList"></MenuTree>        
          </el-menu>
        </el-aside>
        <!-- 右面主显示区域！ -->
        <el-main>
          <!-- 主页面母版页头（标签导航栏） -->
          <TabNavBar></TabNavBar>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
/* 引入菜单子组件 */
import MenuTree from '@/components/menu/MenuTree.vue'
// 引入标签导航栏
import TabNavBar from '@/components/tab/TabNavBar.vue'

export default {
  name: 'HomeView',
  components: {
    // 注册组件
    MenuTree: MenuTree,
    TabNavBar: TabNavBar,
  },
  data () {
    return {
      /* 汉堡按钮是否折叠 */
      // isCollapse: false, //汉堡按钮下面的列表默认是展开的
      isCollapse: true,
      userInfo:[],
      menuWidth: '220px',
      /* 菜单列表 */
      menuList: [
        {
          id: 1,
          name: 'index',
          path: 'index',
          meta: {
            title: 'Home',
            icon: 'ri-function-fill'
            // el-icon-menu  ri-function-fill
            
          },
          children: []
        },
        {
          id: 2,
          name: 'email',
          path: 'email',
          meta: {
            title: 'Email Management',
            icon: 'ri-mail-settings-fill'
          },
          alwaysShow: true,
          children: [
            {
              id: 3,
              name: 'inbox',
              path: 'inbox',
              meta: {
                title: 'Inbox',
                icon: 'ri-import-fill'
              },
              children: []
            },
            {
              id: 4,
              name: 'drafts',
              path: 'drafts',
              meta: {
                title: 'Drafts',
                icon: 'ri-draft-fill'
              },
              children: []
            },
            {
              id: 5,
              name: 'trashBox',
              path: 'trashBox',
              meta: {
                title: 'Trash Box',
                icon: 'ri-delete-bin-5-fill'
              },
              children: []
            },
            {
              id: 6,
              name: 'outbox',
              path: 'outbox',
              meta: {
                title: 'Outbox',
                icon: 'ri-export-fill'
              },
              children: []
            },
            // {
            //   id: 7,
            //   name: 'sysPost',
            //   path: 'sysPost',
            //   meta: {
            //     title: '岗位管理',
            //     icon: 'el-icon-menu'
            //   },
            //   children: []
            // },
            // {
            //   id: 8,
            //   name: 'sysLog',
            //   path: 'sysLog',
            //   meta: {
            //     title: '日志管理',
            //     icon: 'el-icon-folder'
            //   },
            //   children: [
            //     {
            //       id: 9,
            //       name: 'sysLoginLog',
            //       path: 'sysLoginLog',
            //       meta: {
            //         title: '登录日志',
            //         icon: 'el-icon-document'
            //       },
            //       children: []
            //     },
            //     {
            //       id: 10,
            //       name: 'sysOperationLog',
            //       path: 'sysOperationLog',
            //       meta: {
            //         title: '操作日志',
            //         icon: 'el-icon-tickets'
            //       },
            //       children: []
            //     }
            //   ]
            // }
          ]
        },
        {
          id: 11,
          path: 'index',
          name: 'sysUser',
              path: 'sysUser',
              meta: {
                title: 'User Management',
                icon: 'ri-user-settings-fill'
              },
              children: []
        },
        {
          id: 12,
          name: 'sendEmail',
          path: 'sendEmail',
          meta: {
            title: 'Send Email',
            icon: 'ri-mail-send-fill'
          },
          children: []
        }
      ],
    }
  },
  methods: {
    /* 汉堡按钮点击展开以及关闭 */
     toggleClick () {
      // 点击之后这个isCollapse会变成相反的状态
      this.isCollapse = !this.isCollapse
    },
    /* sub-menu 展开的回调 */
    handleOpen (key, keyPath) {
      console.log(key, keyPath)
    },
    /* sub-menu 收起的回调 */
    handleClose (key, keyPath) {
      console.log(key, keyPath)
    },
    /* 菜单激活回调 */
    handleSelect (key, keyPath) {
      this.$store.state.editableTabsValue = key;
      this.$store.state.activeMenu = key;
    },
    // 退出登录方法
    logout() {
      localStorage.removeItem("userEmail");
      localStorage.removeItem("expirationTime");
      // 调用RESET_STATE mutation来重置Vuex状态
      this.$store.commit('RESET_STATE');
      this.$router.push("/");
    },
    loadUserInfo(userEmail) {
      if(userEmail){
        this.axios.get(`http://localhost:3759/email-web/sysUser/${userEmail}`)
        .then(response => {
          // console.log(response.data);
          this.userInfo = response.data;
          
        })
        .catch(error => {
          console.error("Error fetching user info:", error);
        });
      }else{
        console.error("User email not found.");
      }
    },
    handleCommand(command) {
      if(command === 'viewUser') {
        this.$router.push('/sysUser');
      } else if (command === 'todo') {
        // 处理To-dos的逻辑
      }
    }
  },
  mounted() {
    const userEmail = localStorage.getItem('userEmail');
    this.loadUserInfo(userEmail);
  },
  // computed: {
  //   avatarUrl() {
  //     try {
  //       // 尝试解析userInfo.avatar JSON字符串
  //       const avatarInfo = JSON.parse(this.userInfo.avatar);
  //       return avatarInfo.url; // 返回解析后的头像URL
  //     } catch (error) {
  //       console.error("Error parsing avatar info:", error);
  //       return ''; // 解析失败时返回一个默认的占位URL或空字符串
  //     }
  //   },
  // },
}
</script>

<style lang="less" scoped>
// 图标样式
::v-deep .ri-mail-send-fill, ::v-deep .ri-export-fill,
::v-deep .ri-user-settings-fill, ::v-deep .ri-delete-bin-5-fill,
::v-deep .ri-draft-fill, ::v-deep .ri-import-fill, ::v-deep .ri-mail-settings-fill,
::v-deep .ri-function-fill, ::v-deep .el-icon-menu{
  color: #3c4e40;
  font-size: 14px; /* 调整图标的大小 */
  margin-right: 7px; /* 设置图标和文字之间的空隙 */
}
::v-deep .el-submenu__title i {
  color: #3c4e40;
}
::v-deep .el-submenu__icon-arrow{
  font-size: 14px;
  right: 15px;
}
::v-deep .el-menu--vertical .li .i{
  margin-right: 10px;
}
.home{
  background-image: url('../../assets/bk04.jpg');
}
// 最上面的导航栏样式
  .el-header{
    // background-color: #889776;
    background-color: #5F7161;
    color: #FFFFFF;
    text-align: left;
    line-height: 5vh;
    margin: 0 0;
    padding: 0 0;

  // 设置图片的样式
  img {
    width: 10vh;
    height: 5vh;
    // border-radius: 20%;
  }

  // 登录用户区域的样式
  .login_user {
    width: 320px;
    float: right;
    display: flex;
    justify-content: space-evenly;
  }

    // 登录用户按钮
    .user_btn {
      font-family: 'TextFont'; /* 使用适合阅读的字体 */
      letter-spacing: 1px;
      width: 50%;
      display: flex;
      justify-content: space-between;
      align-items: center; /* 添加此行来实现上下居中 */
      .user-avatar{
        // align-items: center; /* 添加此行来实现上下居中 */
      }
      .el-dropdown-link {
        cursor: pointer;
        color: #FFFFFF;
        font-size: 16px;

      }
    
      .el-icon-arrow-down {
        font-size: 12px;
      }
      
    }
  }

  //侧边栏区域
  .el-aside {
    // background-color: #b5ba9d;
    background-color: #cce0c5;
    font-family: 'TextFont';
    letter-spacing: 0.5px;
    // color: #FFFFFF;
    text-align: left;
    height: 95vh;
    transition: width 0.5s ease; /* 过渡动画持续时间及效果 */
    // width: 200px;

    // 汉堡按钮（展开关闭）
    .toggle_box {
      // background-color: #a7ab91;
      background-color: #6D8B74;
      font-size: 15px;
      font-weight: bold;
      line-height: 30px;
      color: #000000;
      letter-spacing: 0.25em; //设置文本字符的间距表现
      text-align: center;
      // 鼠标变为手
      cursor: pointer;
    }

    // 侧边栏导航样式
    .el-menu-vertical-demo:not(.el-menu--collapse) {
      overflow: hidden;
    }
  }

  // 主页面区域样式
  .el-main {
    font-family: 'TextFont';
    letter-spacing: 1px;
    // background-color: #E3E1D9;
    background-color: #EFEAD8;
    
    color: #000000;
    height: 95vh;
    overflow: hidden;
  }
  
  body > .el-container {
    margin-bottom: 40px;
    background-color: #000000 !important;
  }
  
  .el-container:nth-child(5) .el-aside,
  .el-container:nth-child(6) .el-aside {
    line-height: 260px;
  }
  
  .el-container:nth-child(7) .el-aside {
    line-height: 320px;
  }

  /deep/ .el-tabs__content {
  background-color: #e3e6d0; /* 你想要的颜色 */
}
</style>