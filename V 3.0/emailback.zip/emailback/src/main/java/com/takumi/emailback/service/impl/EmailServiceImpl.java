package com.takumi.emailback.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.takumi.emailback.mapper.EmailMapper;
import com.takumi.emailback.entity.EmailEntity;
import com.takumi.emailback.mapper.EmailUserMapper;
import com.takumi.emailback.entity.EmailUserEntity;
import com.takumi.emailback.req.EmailLoginReq;
import com.takumi.emailback.req.EmailSaveReq;
import com.takumi.emailback.resp.EmailLoginResp;
import com.takumi.emailback.service.EmailService;
import com.takumi.emailback.utils.CopyUtil;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;


import java.util.List;

@Service
public class EmailServiceImpl extends ServiceImpl<EmailMapper, EmailEntity> implements EmailService {
    @Resource
    private EmailMapper emailMapper;
//引入用户信息总表格，让它可以在成功注册时一起添加到总用户信息表中。
    @Resource
    private EmailUserMapper emailUserMapper; // 注入EmailUserMapper
//    @Override
//    public void register(EmailSaveReq req) {
//        EmailEntity user = CopyUtil.copy(req, EmailEntity.class);
//        // 看一下输出
////        System.out.println("the user is:" + user);
//        if(!ObjectUtils.isEmpty(req.getEmail())){
//            EmailEntity emailDb = selectByEmail(req.getEmail());
//            if(ObjectUtils.isEmpty(emailDb)){
////                emailMapper.insert(user);
//                try {
//                    emailMapper.insert(user);
//                    // 设置默认头像
//                    String defaultAvatarJson = "{\"status\":\"success\",\"name\":\"avatar01.jpeg\",\"uid\":\"avatar01\",\"url\":\"http://localhost:3759/avatars/avatar01.jpeg\"}";
//
//                    // 同时将部分信息插入到 user_message 表
//                    EmailUserEntity emailUserEntity = CopyUtil.copy(req, EmailUserEntity.class);
//                    emailUserEntity.setAvatar(defaultAvatarJson); // 设置默认头像
//                    // 插入到 user_message 表
//                    emailUserMapper.insert(emailUserEntity);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                    // 打印异常信息
//                    System.out.println("Insert operation failed: " + e.getMessage());
//                }
//            }
//            else{
//                System.out.println("Already have a duplicate email");
//                throw new RuntimeException("Already have a duplicate email");
//            }
//        }
//    }
public boolean register(EmailSaveReq req) {
    EmailEntity user = CopyUtil.copy(req, EmailEntity.class);
    if (!ObjectUtils.isEmpty(req.getEmail())) {
        EmailEntity emailDb = selectByEmail(req.getEmail());
        if (!ObjectUtils.isEmpty(emailDb)) {
            // 邮箱已存在，返回 false 或其他错误标识
            System.out.println("email already had.");
            return false;
        }
        try {
            //邮件符合要求,没有重复的
            emailMapper.insert(user);
            String defaultAvatarJson = "{\"status\":\"success\",\"name\":\"avatar01.jpeg\",\"uid\":\"avatar01\",\"url\":\"http://localhost:3759/avatars/avatar01.jpeg\"}";
            EmailUserEntity emailUserEntity = CopyUtil.copy(req, EmailUserEntity.class);
            emailUserEntity.setAvatar(defaultAvatarJson);
            emailUserMapper.insert(emailUserEntity);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Insert operation failed: " + e.getMessage());
            return false;
        }
    }
    return false;
}



    @Override
    public EmailLoginResp login(EmailLoginReq req) {
        EmailEntity emailDb = selectByEmail(req.getEmail());
        if (emailDb == null) {
            // 用户不存在
            System.out.println("Login failed: User does not exist");
            throw new RuntimeException("User does not exist");
        } else {
            // 检查密码是否匹配
            if (emailDb.getPassword().equals(req.getPassword())) {
                // 登录成功
                EmailLoginResp emailLoginResp = CopyUtil.copy(emailDb, EmailLoginResp.class);
                System.out.println("Login successful");
                return emailLoginResp;
            } else {
                // 密码不匹配
                System.out.println("Login failed: Password does not match");
                throw new RuntimeException("Password does not match");
            }
        }
    }


    //    查询email是否已经存在
    public EmailEntity selectByEmail(String email){
        QueryWrapper<EmailEntity> wrapper = new QueryWrapper<>();
        //从前端获取到的email来和数据库中储存的getEmail对比
        wrapper.lambda().eq(EmailEntity::getEmail,email);
        List<EmailEntity> emailList = emailMapper.selectList(wrapper);
//        如果数据库为空则返回null
        if(CollectionUtils.isEmpty(emailList)){
            return null;
        }
//        不为空的话就取到数据库中的该值
        else {
            return emailList.get(0);
        }
    }

}
