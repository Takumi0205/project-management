package com.takumi.emailback.service;

import com.takumi.emailback.entity.EmailUserEntity;
import com.takumi.emailback.req.EmailUserReq;

public interface EmailUserService {
    EmailUserReq getUserByEmail(String emailId);

    boolean updateUser(EmailUserReq userReq);
}
