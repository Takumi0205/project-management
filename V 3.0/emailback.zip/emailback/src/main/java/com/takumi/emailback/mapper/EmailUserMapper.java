package com.takumi.emailback.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.takumi.emailback.entity.EmailUserEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface EmailUserMapper extends BaseMapper<EmailUserEntity> {
    // 这里可以定义一些特定的数据库操作方法，如果仅使用MyBatis Plus提供的CRUD操作，这里可以不需要额外定义方法
    @Select("SELECT * FROM user_message WHERE email = #{email}")
    EmailUserEntity selectByEmail(String email);


    @Update("UPDATE user_message SET name = #{name}, phone = #{phone}, " +
            "address = #{address}, department = #{department}," +
            " personal_intro = #{personalIntro}, " +
            "avatar = #{avatar} WHERE email = #{email}")
    void updateUser(EmailUserEntity userEntity);
}

