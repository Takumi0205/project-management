package com.takumi.emailback.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;

@TableName("email_message")
public class EmailMessageEntity {
    @TableId("email_id")
    private Long emailId;

    private String senderEmail;
    private String recipientEmail;
//    邮件的主题
    private String subject;
    private String content;
//    附件信息
    private String attachmentInfo;
    private LocalDateTime creationTime;
    private LocalDateTime updateTime;
    private String status;

    private String recipients;
    private Boolean isRead = false; // 默认为false，表示未读

    private Boolean senderDeleted = false;
    private Boolean recipientDeleted = false;

    private Boolean confirmSenderDeleted = false;
    private Boolean confirmRecipientDeleted = false;

    // Getters and Setters
    public Long getEmailId() {
        return emailId;
    }

    public void setEmailId(Long emailId) {
        this.emailId = emailId;
    }

    public String getSenderEmail() {
        return senderEmail;
    }

    public void setSenderEmail(String senderEmail) {
        this.senderEmail = senderEmail;
    }

    public String getRecipientEmail() {
        return recipientEmail;
    }

    public void setRecipientEmail(String recipientEmail) {
        this.recipientEmail = recipientEmail;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAttachmentInfo() {
        return attachmentInfo;
    }

    public void setAttachmentInfo(String attachmentInfo) {
        this.attachmentInfo = attachmentInfo;
    }

    public LocalDateTime getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(LocalDateTime creationTime) {
        this.creationTime = creationTime;
    }

    public LocalDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(LocalDateTime updateTime) {
        this.updateTime = updateTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    public Boolean getSenderDeleted() {
        return senderDeleted;
    }

    public void setSenderDeleted(Boolean senderDeleted) {
        this.senderDeleted = senderDeleted;
    }

    public Boolean getRecipientDeleted() {
        return recipientDeleted;
    }

    public void setRecipientDeleted(Boolean recipientDeleted) {
        this.recipientDeleted = recipientDeleted;
    }

    public Boolean getConfirmSenderDeleted() {
        return confirmSenderDeleted;
    }

    public void setConfirmSenderDeleted(Boolean confirmSenderDeleted) {
        this.confirmSenderDeleted = confirmSenderDeleted;
    }

    public Boolean getConfirmRecipientDeleted() {
        return confirmRecipientDeleted;
    }

    public void setConfirmRecipientDeleted(Boolean confirmRecipientDeleted) {
        this.confirmRecipientDeleted = confirmRecipientDeleted;
    }
    public String getRecipients() {
        return recipients;
    }

    public void setRecipients(String recipients) {
        this.recipients = recipients;
    }

    @Override
    public String toString() {
        return "EmailMessageEntity{" +
                "emailId=" + emailId +
                ", senderEmail='" + senderEmail + '\'' +
                ", recipientEmail='" + recipientEmail + '\'' +
                ", subject='" + subject + '\'' +
                ", content='" + content + '\'' +
                ", attachmentInfo='" + attachmentInfo + '\'' +
                ", creationTime=" + creationTime +
                ", updateTime=" + updateTime +
                ", status='" + status + '\'' +
                ", isRead='" + isRead + '\'' +
                ", senderDeleted='" + senderDeleted + '\'' +
                ", recipientDeleted='" + recipientDeleted + '\'' +
                ", confirmSenderDeleted='" + confirmSenderDeleted + '\'' +
                ", confirmRecipientDeleted='" + confirmRecipientDeleted + '\'' +
                ", recipients='" + recipients + '\'' +
                '}';
    }


}
