package com.takumi.emailback.controller;

import com.takumi.emailback.req.EmailMessageSaveReq;
import com.takumi.emailback.req.ScheduledEmailSaveReq;
import com.takumi.emailback.resp.CommonResp;
import com.takumi.emailback.service.ScheduledEmailService;
import jakarta.annotation.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/email-web")
public class ScheduledEmailController {

    @Resource
    private ScheduledEmailService scheduledEmailService;

    @PostMapping("/scheduleEmail")
    public ResponseEntity<CommonResp<Object>> scheduleEmail(@RequestBody ScheduledEmailSaveReq emailRequest) {
        System.out.println("Received scheduledTime: " + emailRequest.getScheduledTime());
        CommonResp<Object> resp = new CommonResp<>();
        try {
            System.out.println("进行到这里了");
            boolean isSchedule = scheduledEmailService.scheduleEmail(emailRequest);

            if (isSchedule) {
                resp.setMessage("Email scheduled successfully");
                return ResponseEntity.ok(resp);
            } else {
                resp.setSuccess(false);
                resp.setMessage("Email send failed due to some problems"); // 请替换[具体原因]为实际失败的原因
                return ResponseEntity.badRequest().body(resp);
            }
        } catch (Exception e) {
            resp.setSuccess(false);
            resp.setMessage("Failed to schedule email: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(resp);
        }
    }


}
