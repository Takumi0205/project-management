package com.takumi.emailback.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.takumi.emailback.entity.EmailUserEntity;
import com.takumi.emailback.mapper.EmailUserMapper;
import com.takumi.emailback.req.EmailMessageSaveReq;
import com.takumi.emailback.req.EmailUserReq;
import com.takumi.emailback.service.EmailUserService;
import com.takumi.emailback.utils.CopyUtil;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@Service
public class EmailUserServiceImpl extends ServiceImpl<EmailUserMapper, EmailUserEntity> implements EmailUserService {
    @Resource
    private EmailUserMapper emailUserMapper;
    @Override
    public EmailUserReq getUserByEmail(String email) {
//        System.out.println("The get email:" + email);
        EmailUserEntity entity = emailUserMapper.selectByEmail(email);
//        System.out.println("The user information:" + entity);
        if (entity != null ){
            EmailUserReq userDetails = CopyUtil.copy(entity, EmailUserReq.class);
            return userDetails;
        }
        return null;
    }

    @Override
    @Transactional
    public boolean updateUser(EmailUserReq userReq) {
        // Assuming EmailUserEntity corresponds to the user table and you have a userMapper for it
        EmailUserEntity userEntity = CopyUtil.copy(userReq, EmailUserEntity.class);
        System.out.println("the user entity is:" + userEntity);
        try {
            System.out.println("avatar information:" + userEntity.getAvatar());
            emailUserMapper.updateUser(userEntity);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false; // 操作失败
        }

    }


}
