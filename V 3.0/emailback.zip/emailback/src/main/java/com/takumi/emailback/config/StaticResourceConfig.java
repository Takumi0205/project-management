package com.takumi.emailback.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class StaticResourceConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 配置静态资源的处理规则
        // 这里假设你希望将"/files/**"映射到本地文件系统的"/path/to/your/upload/directory/"目录
        // 注意替换"/path/to/your/upload/directory/"为你实际的文件保存目录

        registry.addResourceHandler("/files/**")
                .addResourceLocations("file:/D:/project/MySpringBootProject/uploads/");

        // 映射头像图片
        registry.addResourceHandler("/avatars/**")
                .addResourceLocations("file:/D:/project/MySpringBootProject/avatars/");
    }
}
