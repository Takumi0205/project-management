package com.takumi.emailback.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.takumi.emailback.entity.ScheduledEmailEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Delete;

import java.util.List;

@Mapper
public interface ScheduledEmailMapper extends BaseMapper<ScheduledEmailEntity> {

    @Select("SELECT * FROM scheduled_email WHERE email_id = #{emailId}")
    ScheduledEmailEntity selectByEmailId(Long emailId);

    @Insert("INSERT INTO scheduled_email (sender_email, recipient_email, subject, content, attachment_info, scheduled_time, status, creation_time, update_time) " +
            "VALUES (#{senderEmail}, #{recipientEmail}, #{subject}, #{content}, #{attachmentInfo}, #{scheduledTime}, #{status}, #{creationTime}, #{updateTime})")
    int insertScheduledEmail(ScheduledEmailEntity scheduledEmail);

    @Update("UPDATE scheduled_email SET sender_email = #{senderEmail}, recipient_email = #{recipientEmail}, " +
            "subject = #{subject}, content = #{content}, attachment_info = #{attachmentInfo}, " +
            "scheduled_time = #{scheduledTime}, status = #{status}, update_time = #{updateTime} " +
            "WHERE email_id = #{emailId}")
    int updateScheduledEmail(ScheduledEmailEntity scheduledEmail);

    @Delete("DELETE FROM scheduled_email WHERE email_id = #{emailId}")
    int deleteScheduledEmail(Long emailId);

    // 根据状态查询所有预定邮件
    @Select("SELECT * FROM scheduled_email WHERE status = #{status}")
    List<ScheduledEmailEntity> selectByStatus(String status);

}
