package com.takumi.emailback.service;

import com.takumi.emailback.req.ScheduledEmailSaveReq;

public interface ScheduledEmailService {
    boolean scheduleEmail(ScheduledEmailSaveReq emailRequest) throws Exception;
}
