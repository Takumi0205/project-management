package com.takumi.emailback;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.takumi.emailback.entity.EmailEntity;
import com.takumi.emailback.entity.EmailMessageEntity;
import com.takumi.emailback.mapper.EmailMapper;
import com.takumi.emailback.mapper.EmailMessageMapper;
import com.takumi.emailback.req.EmailMessageSaveReq;
import com.takumi.emailback.service.impl.EmailMessageServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class EmailMessageServiceImplTest {

    @Autowired
    private EmailMessageServiceImpl emailMessageService;

    @MockBean
    private EmailMessageMapper emailMessageMapper;

    @MockBean
    private EmailMapper emailMapper;

    @Test
    void testSendMessage() {
        EmailMessageSaveReq req = new EmailMessageSaveReq();
        req.setSenderEmail("example@example.com");
        req.setRecipientEmail("recipient@example.com");
        req.setSubject("Test Email");
        req.setContent("This is a test email.");

        EmailMessageEntity message = new EmailMessageEntity();
        message.setSenderEmail(req.getSenderEmail());
        message.setRecipientEmail(req.getRecipientEmail());
        message.setSubject(req.getSubject());
        message.setContent(req.getContent());
        message.setStatus("sent");

        // 设置预期的行为
        when(emailMessageMapper.insert(any(EmailMessageEntity.class))).thenReturn(1);

        // 调用实际方法
        boolean result = emailMessageService.sendMessage(req);

        // 验证方法返回正确的结果
        assertTrue(result);

        // 验证是否调用了 mapper 的 insert 方法
        verify(emailMessageMapper, times(1)).insert(any(EmailMessageEntity.class));
    }

    @Test
    void testSaveDraft() {
        EmailMessageSaveReq draftReq = new EmailMessageSaveReq();
        // 填充请求数据...

        EmailMessageEntity draft = new EmailMessageEntity();
        // 填充草稿实体数据...

        // 模拟数据库操作成功
        when(emailMessageMapper.insert(any(EmailMessageEntity.class))).thenReturn(1);

        // 执行测试
        boolean result = emailMessageService.saveDraft(draftReq);

        // 验证结果
        assertTrue(result);

        // 验证是否调用了数据库操作
        verify(emailMessageMapper, times(1)).insert(any(EmailMessageEntity.class));
    }

    @Test
    void testGetAllEmailAddresses() {
        List<EmailEntity> emailEntities = new ArrayList<>();
        // 添加测试数据到emailEntities...

        // 设置当调用emailMapper.selectList时返回测试数据
        when(emailMapper.selectList(any())).thenReturn(emailEntities);

        // 执行测试
        List<String> emailAddresses = emailMessageService.getAllEmailAddresses();

        // 验证返回的列表与预期匹配
        assertEquals(emailEntities.size(), emailAddresses.size());

        // 验证是否调用了数据库操作
        verify(emailMapper, times(1)).selectList(any());
    }
    @Test
    void testGetEmailsForRecipient() {
        String recipientEmail = "recipient@example.com";
        List<EmailMessageEntity> emailMessageEntities = new ArrayList<>();
        // 添加测试数据到emailMessageEntities...

        // 设置模拟行为
        when(emailMessageMapper.selectList(any(QueryWrapper.class))).thenReturn(emailMessageEntities);

        // 执行方法
        List<EmailMessageSaveReq> emails = emailMessageService.getEmailsForRecipient(recipientEmail);

        // 验证返回的邮件列表
        assertEquals(emailMessageEntities.size(), emails.size());

        // 确认调用了selectList方法
        verify(emailMessageMapper).selectList(any(QueryWrapper.class));
    }

}
