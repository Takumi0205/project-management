select * from t_admin;

create table register(
user_ID varchar(60),
password varchar(30),
address varchar(100),
email varchar(50),
phone_number varchar(30)
);
select * from user_register;
ALTER table users_register rename to user_register;

create table merchant_register(
merchant_ID varchar(60),
password varchar(30),
address varchar(100),
email varchar(50),
phone_number varchar(30)
);
insert into user_register value('user','123456','sichuan','123@qq.com',123456789);
select * from merchant_register;

create table login(
user_ID varchar(60),
password varchar(30)
);
insert into login value('user','123456');
select * from login;


create table user_register(
user_ID varchar(60),
password varchar(30),
address varchar(100),
email varchar(50),
phone_number varchar(30)
);

create table merchant_register(
merchant_ID varchar(60),
password varchar(30),
address varchar(100),
email varchar(50),
phone_number varchar(30)
);

insert into user_register value('user','123456','sichuan','123@qq.com',123456789,'user');

create table login(
user_ID varchar(60),
password varchar(30)
);
insert into login value('user','123456');


 -- 创建相关的分类表
 create table classify(
classify_ID varchar(60),
classify_Name varchar(50)
 );
 select * from classify;
 insert into classify value('1','Mobile');
 insert into classify value('2','Digital'),('3','Household appliances'), ('4','Computer'), ('5','Office'),('6','Home'),('7','Kitchenware'),('8','Furniture'),('9','Lamps');
 insert into classify value('10','Clothing'),('11','Underwear'),('12','Bags'),('13','Clocks'),('14','jewelry'),('15','Sports');
 insert into classify value('16','Outdoors'),('17','Automotive Supplies'),('18','Car'),('19','Mother Baby'),('20','Nursery feeding'),('21','Toy musical instruments');
 insert into classify value('22','Pets'),('23','Home cleaning'),('24','Personal care'),('25','Books'),('26','Literature');
 -- 创建商品表
 drop table goods;
 create table goods(
 goods_ID varchar(60),
 merchant_ID varchar(30),
 name varchar(90),
 image varchar(90),
 des varchar(200),
 money float(50),
 on_sale float(50),
 type_size varchar(50),
 type_color varchar(50),
 inventory float(50),
 classify_ID varchar(30),
 like_number varchar(30),
 dislike_number varchar(30)
 );
 insert into goods value('1','1','iphone','tupian','a good phone',3000,2999,'M','Blue',60,1,30,200);
 insert into goods value('2','2','iphone','tupian','a good phone','M','Blue',60,2,30,200);
 select * from goods;
 
  drop table classifyGoods;
  create table classifyGoods(
  goods_ID varchar(60),
  classify_ID varchar(30),
  name varchar(90),
  image varchar(90),
  money float(50),
  on_sale float(50)
  );
  insert into classifyGoods value('1','1','iphone','tupian',3000,2999);
  insert into classifyGoods value('35','1','huawei','tupian',6590,5688);
  select * from classifyGoods;
  select * from classifyGoods where classify_ID=1;

ALTER TABLE goods ADD create_time timestamp not null default CURRENT_TIMESTAMP COMMENT '创建时间';
ALTER TABLE goods ADD update_time timestamp not null default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP COMMENT '更新时间';
SELECT image,name, on_sale, update_time FROM classifyGoods ORDER BY update_time ASC, name DESC;

  drop table merchant;
  create table merchant_store(
  merchant_ID varchar(50),
  store_name varchar(60),
  head_p varchar(70),
  phone_number varchar(50),
  email varchar(60),
  address varchar(60)
  );
  -- 先去得到成功登陆的商家id、然后将merchant注册表中的信息传入merchant_store 
  select * from merchant_store;
  insert into merchant value('mer','','tupian','');
  
  -- 创建一个商品列表，把merchant——ID以及goods——ID设置为主键。
  drop table merchant_goods;
create table merchant_goods(
merchant_ID varchar(50),
goods_ID varchar(60),
goods_name varchar(90),
goods_description varchar(200),
goods_picture varchar(90),
goods_classify varchar(60),
goods_classify_ID varchar(60),
goods_size varchar(90),
goods_color varchar(90),
inventory varchar(60),
price float(50),
on_sale float(50)
) ; 
insert into merchant_goods value('test2','test1','iphone','a phone','tupian','mobile','1','M','blue','900',6758.9,6632.8);
insert into merchant_goods value('test2','test2','huawei','a phone','tupian','mobile','1','S','red','600',6598.9,4555.8);
select * from merchant_goods;

-- 商家可以查看orders
 
 
 -- 用户购物车
 drop table user_shoppingcar;
 create table user_shoppingcar(
 user_ID varchar(60),
 goods_ID varchar(60),
 goods_name varchar(90),
 goods_picture varchar(90),
 goods_size varchar(90),
 goods_color varchar(90),
 price float(50),
 on_sale float(50),
 count varchar(60),
 total float(50)
 );
 
 select * from user_shoppingcar;
 insert into user_shoppingcar value('user','test5','Cat','','L','White',1111.11,2222.22,'1',2222.22);
 -- 创建一个点赞过的用户的id的表格
 drop table user_like_go;
 create table user_like_go(
  user_ID varchar(60),
  goods_ID varchar(60)
 );
 ALTER TABLE user_like_go ADD create_time timestamp not null default CURRENT_TIMESTAMP COMMENT '创建时间';
 select * from user_like_go;
 -- 创建一个不喜欢商品的用户id的表格
  create table user_dislike_go(
	  user_ID varchar(60),
	  goods_ID varchar(60)
 );
 
 
 -- 创建一个用户的地址表
 create table user_address(
	user_ID varchar(60),
	address varchar(120),
    sendee varchar(90),
    phone_number varchar(30)
 );
   ALTER TABLE user_address ADD create_time timestamp not null default CURRENT_TIMESTAMP COMMENT '创建时间';
   select * from user_address;
   
 -- 创建一个用户购买商品表
 drop table user_buy_goods;
 create table user_buy_goods(
 user_ID varchar(60),
 merchant_ID varchar(60),
 merchant_name varchar(90),
 goods_ID varchar(60),
 goods_name varchar(90),
 address varchar(90),
 goods_size varchar(30),
 goods_color varchar(30),
 price float(50),
 count varchar(60),
 total varchar(60)
 );
  ALTER TABLE user_buy_goods ADD create_time timestamp not null default CURRENT_TIMESTAMP COMMENT '创建时间';
 select * from user_buy_goods;
 
 
 
 -- 用户支付后，商品详情表
 drop table user_orders;
 CREATE TABLE user_orders (
    user_ID VARCHAR(60),
    merchant_ID VARCHAR(60),
    merchant_name VARCHAR(90),
    goods_ID VARCHAR(60),
    goods_name VARCHAR(90),
    goods_des VARCHAR(200),
    address VARCHAR(90),
    goods_size VARCHAR(30),
    goods_color VARCHAR(30),
    price FLOAT(50),
    count VARCHAR(60),
    total FLOAT(50),
    pay_method VARCHAR(60),
    status VARCHAR(30),
    express_ID VARCHAR(60)
);
 ALTER TABLE user_orders ADD order_time timestamp not null default CURRENT_TIMESTAMP COMMENT '创建时间';
  ALTER TABLE user_orders ADD arrival_time timestamp default CURRENT_TIMESTAMP COMMENT '到达时间';
  select * from user_orders;
  
  
  drop table goods_comment;
  create table goods_comment(
  goods_ID varchar(60),
  user_ID varchar(60),
  picture varchar(120),
  comments varchar(130),
  comments_like varchar(30)
  );
 ALTER TABLE goods_comment ADD create_time timestamp not null default CURRENT_TIMESTAMP COMMENT '创建时间';
      
 select * from goods_comment;