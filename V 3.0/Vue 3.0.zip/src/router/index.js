import Vue from 'vue'
import VueRouter from 'vue-router'
import HomeView from '@/views/home/HomeView.vue'
import Login from '../views/login/Login.vue'
import Register from '../views/register/Register.vue'
import store from '@/store'

Vue.use(VueRouter)
// 因为发现可以在url跳过登录这个页面，所以使用 Vue Router 的全局守卫：实现一个全局的 beforeEach 守卫，在每个路由转换之前检查认证状态。




const routes = [
  {
    // 默认路径登录页面
    path: '/',
    name: 'Login',
    component: () => import('../views/login/Login'),
    meta: { 
      requiresAuth: false, // 明确标记不需要认证的页面
    }
  },
  {
    // 注册路由
    path: '/register',
    name: 'Register',
    component: () => import('../views/register/Register'),
    meta: { requiresAuth: false } // 明确标记不需要认证的页面
  },
  {
    // 邮件系统主页面
    path: '/home',
    name: 'Home',
    component: () => import('../views/home/HomeView'),
    // redirect当进入home路径时，自动重定向到/index页面。
    redirect: '/index',
    meta: { 
      requiresAuth: true 
    }, // 添加一个 meta 字段表示这个路由需要认证
    children: [
      {
        // 首页路由
        path: '/index',
        name: 'Index',
        component: () => import('../views/home/Index'),
        meta: { 
          requiresAuth: true
        },
      },
      {
        // 用户管理路由
        path: '/sysUser',
        name: 'SysUser',
        component: () => import('../views/user/SysUser'),
        meta: { 
          requiresAuth: true 
         },
      },
      {
        // 收件箱路由
        path: '/inbox',
        name: 'Inbox',
        component: () => import('../views/email/Inbox'),
        meta: { 
          requiresAuth: true
        },
      },
      {
        // 收件箱路由
        path: '/trashBox',
        name: 'TrashBox',
        component: () => import('../views/email/TrashBox'),
        meta: { 
          requiresAuth: true
         },
      },
      {
        // 写邮件路由
        path: '/sendEmail',
        name: 'SendEmail',
        component: () => import('../views/email/SendEmail'),
        meta: { 
          requiresAuth: true
        },
      },
      {
        // 草稿箱路由
        path: '/drafts',
        name: 'Drafts',
        component: () => import('../views/email/Drafts'),
        meta: { 
          requiresAuth: true
         },
      },
      {
        // 发件箱路由
        path: '/outbox',
        name: 'Outbox',
        component: () => import('../views/email/Outbox'),
        meta: { 
          requiresAuth: true
         },
      },
      {
        // 查看邮件路由
        path: '/viewEmail',
        name: 'ViewEmail',
        component: () => import('../views/email/ViewEmail'),
        meta: { 
          requiresAuth: true
         },
      },
      {
        // 修改邮件路由
        path: '/editEmail',
        name: 'EditEmail',
        component: () => import('../views/email/EditEmail'),
        meta: { 
          requiresAuth: true
         },
      },
      {
        // 回复邮件路由
        path: '/reply',
        name: 'Reply',
        component: () => import('../views/email/Reply'),
        meta: { 
          requiresAuth: true
         },
      },
    ]
  },
  {
    path: '/about',
    name: 'about',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/AboutView.vue')
  }
]

const router = new VueRouter({
  routes
})

// 全局前置守卫，检查访问权限
router.beforeEach((to, from, next) => {
  const userEmail = localStorage.getItem('userEmail');
  const expirationTime = localStorage.getItem('expirationTime');
  const currentTime = new Date().getTime();

  const isAuthenticated = userEmail && expirationTime && currentTime < parseInt(expirationTime);
  console.log("userEmail: ",userEmail);
  
  if (to.path !== '/' && !isAuthenticated && to.meta.requiresAuth) {
    store.commit('RESET_STATE');
    // 对于需要认证的页面，如果用户未登录或会话已过期，重定向到登录页面
    console.log("to path is not successful, you must first login ");
    next({ path: '/' });
  } else if (to.path === '/' && isAuthenticated) {
    // 如果用户试图访问登录页面但已经登录且会话未过期，重定向到首页
    console.log("expirationTime:",expirationTime);
    next('/index');
  } else {
    // 在其他情况下，正常导航到目标路由
    next();
  }
});


export default router
