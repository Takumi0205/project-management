<template>
    <div class="email-container">
        <el-form :model="emailForm" ref="emailForm" label-width="100px" class="email-form">
            <el-button class="close-btn" @click="closeView">X</el-button>
            <h3 class="email-subject">Reply</h3>

            <!-- 邮件标题输入框 -->
            <el-form-item prop="subject" :rules="rules.subject" label="Subject:" label-width="100px">
                <el-input v-model="emailForm.subject" placeholder="Email subject" prefix-icon="el-icon-edit"></el-input>
            </el-form-item>
            <!-- 收件人选择框 -->
            <!-- <el-form-item prop="recipientEmail" :rules="rules.recipientEmail">
                <el-select v-model="emailForm.recipientEmail" filterable placeholder="Please select recipient">
                    <el-option v-for="item in recipients" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item> -->
            <el-form-item prop="recipientEmail" :rules="rules.recipientEmails" label="Recipient Email:" label-width="170px" v-if="isHrDepartment">
                <!-- HR部门：多选 -->
                <el-select v-model="recipientEmails" multiple filterable placeholder="Please select recipients" style="width: 100%;">
                    <el-option v-for="item in recipients" :key="item.value" :label="item.label" :value="item.value"></el-option>
                </el-select>
            </el-form-item>

            <el-form-item prop="recipientEmail" :rules="rules.recipientEmail" label="Recipient Email:" label-width="170px" v-else>
                <!-- 非HR部门：单选 -->
                <el-select v-model="emailForm.recipientEmail" filterable placeholder="Please select recipient">
                    <el-option v-for="item in recipients" :key="item.value" :label="item.label" :value="item.value"></el-option>
                </el-select>
            </el-form-item>

            <!-- 定时发送 -->
            <el-form-item label="Scheduled Send Time:" prop="scheduledTime" v-if="isMarketingDepartment" label-width="215px">
                <el-date-picker
                    v-model="scheduledTime"
                    type="datetime"
                    :picker-options="pickerOptions"
                    placeholder="Choose the time"
                    value-format="yyyy-MM-dd HH:mm:ss">
                </el-date-picker>
            </el-form-item>

            <!-- 内容选择框 -->
            <el-form-item prop="content">
                <!-- <el-input type="textarea" v-model="emailForm.content" placeholder="Email Content" rows="5"> -->
                <vue-editor v-model="emailForm.content" placeholder="Email Content"></vue-editor>
                <!-- </el-input> -->
            </el-form-item>
            <el-form-item label="Attachments:">
                <el-upload class="upload-demo" action="http://localhost:3759/email-web/upload" multiple :on-success="handleUploadSuccess" :on-remove="handleRemoveAttachment" :file-list="attachments" :before-upload="beforeFileUpload" list-type="text">
                    <el-button size="small" type="primary">Click to upload</el-button>
                    <div slot="tip" class="el-upload__tip">Only files with a size less than {{ isRnd ? '10MB' : '2MB' }} are allowed</div>
                </el-upload>
            </el-form-item>
            <el-form-item class="form-actions">
                <el-button type="primary" @click="saveDraft" style="width: 200px; margin-right: 2%;">Save as draft</el-button>
                <el-button type="success" @click="sendEmail" style="width: 200px; margin-left: 2%; margin-right: 2%;">Send</el-button>
                <el-button type="default" @click="resetEmailForm" style="width: 200px;">Reset</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>

<script>
import moment from 'moment-timezone';
export default {
    name: "EditEmail",
    data() {
        return {
            emailForm: {
                recipientEmail: '',
                senderEmail: localStorage.getItem('userEmail') || '',
                subject: '',
                content: '',
                attachmentInfo: [],
                status: '',
            },
            recipients: [],
            attachments: [],
            recipientEmails:[],
            isHrDepartment: false,
            isRnd: false,
            isMarketingDepartment:false,
            userInfo:[],//用户的个人信息
            scheduledTime: null,// 存储定时发送的时间
            rules: {
                subject: [
				    { required: true, message: 'Please input the subject of the email', trigger: 'blur' }
                ],
                recipientEmail: [
                    { required: true, message: 'Please select a recipient', trigger: 'blur' }
                ],
                recipientEmails: [
                    
                ],
            },
            //选择日期时间前检查,不许选择之前的时间,只能选择此刻/以后的时间
            pickerOptions: {
                format: 'yyyy-MM-dd HH:mm',
                valueFormat: 'yyyy-MM-dd HH:mm:00', // 提交到后端的格式，秒固定为00
                selectableRange: '00:00:00 - 23:59:59', // 可选时间范围，从00:00到23:59
                disabledDate(time) {
                    let now = new Date();
                    now.setMinutes(now.getMinutes(), 0, 0); // 设置当前小时的起始分钟（0分钟0秒0毫秒）
                    return time.getTime() < now.getTime();
                }
            },
        };
    },
    mounted() {
        const emailId = this.$route.params.emailId;
        const userEmail = localStorage.getItem('userEmail');
        this.loadUserInfo(userEmail);
        this.loadReply(emailId);
        this.axios.get('http://localhost:3759/email-web/get-email-list')
			.then(response => {
				// 假设后端直接返回了邮箱地址的数组
				// 将每个邮箱地址转换为el-select组件所需的对象格式
				this.recipients = response.data.map(email => {
					return { label: email, value: email };
				});
			})
			.catch(error => {
				console.error("Failed to fetch email addresses:", error);
				this.$message.error('Failed to load recipient emails');
			});
    },
    methods: {
        loadReply(emailId) {
            this.emailForm.emailId = emailId;
            this.axios.get(`http://localhost:3759/email-web/emails/${emailId}`)
            .then((response) => {
                const { senderEmail,emailId, recipientEmail, subject, content, attachmentInfo, recipients } = response.data;
                this.emailForm.subject = subject;
                this.emailForm.content = content;
                console.log("hr has recipients:",recipients);
                // 设置邮件的收件人为原邮件的发件人
                this.emailForm.recipientEmail = senderEmail;
                //即使是hr,现在他收到的也是一个人的,要是回复的时候,直接选取发件人的email就行,要是想发送给其他人就直接加就行.
                this.recipientEmails = [senderEmail]; // 将发件人设为回复的默认收件人
                // 设置邮件的发件人
                this.emailForm.senderEmail = localStorage.getItem('userEmail');

                // 为回复设置邮件主题，通常是在原邮件主题前加上"Re: "
                this.emailForm.subject = `Re: ${subject}`;
                // 为回复设置邮件内容，通常是引用原邮件的内容
                this.emailForm.content = `\n\n--- Original message ---\n${content}`;

                // 假设附件信息以JSON字符串形式保存
                this.attachments = attachmentInfo ? JSON.parse(attachmentInfo) : [];
            })
            .catch(error => {
                console.error("Error loading draft:", error);
            });
        },
        loadUserInfo(userEmail) {
			if (userEmail) {
				this.axios.get(`http://localhost:3759/email-web/sysUser/${userEmail}`)
				.then(response => {
					this.userInfo = response.data;
					// 假设用户信息中包含部门信息，并且部门标识符为'department'
					this.isHrDepartment = response.data.department === 'hr';
                    //如果是Research and Development部门,那么可以发送更大的附件
					this.isRnd = response.data.department === 'rnd';
      				this.maxAttachmentSize = this.isRnd ? 10 * 1024 * 1024 : 2 * 1024 * 1024;  // 设置为10MB或2MB
                    //如果是marketing部门可以定时发送
					this.isMarketingDepartment = response.data.department === 'marketing';
				})
				.catch(error => {
					console.error("Error fetching user info:", error);
				});
			} else {
				console.error("User email not found.");
			}
		},
        handleUploadSuccess(response, file, fileList) {
            this.attachments.push({
                name: file.name,
                url: response.url, // Assuming your backend returns the URL for the uploaded file
            });
            this.emailForm.attachmentInfo = JSON.stringify(this.attachments);
        },
        handleRemoveAttachment(file, fileList) {
            this.attachments = fileList;
            this.emailForm.attachmentInfo = JSON.stringify(this.attachments);
        },
        //附件上传之前检查
		beforeFileUpload(file) {
			const isAllowedSize = file.size <= this.maxAttachmentSize;
			if (!isAllowedSize) {
				this.$message.error(`The file size cannot exceed ${this.isRnd ? '10MB' : '2MB'}.`);
			}
			return isAllowedSize;
		},
        saveDraft() {
			this.$refs.emailForm.validate((valid) => {
				if (valid) {
					// 将attachments数组转换为JSON字符串并存入emailForm.attachmentInfo
					this.emailForm.attachmentInfo = JSON.stringify(this.attachments);
					// 设置状态为草稿
					this.emailForm.status = 'draft';
					// 调用API保存草稿
                    // 根据是否是HR部门，使用不同的字段和API端点
					if (this.isHrDepartment && this.recipientEmails.length > 1) {
						// HR部门且recipientEmails字段被使用
						this.emailForm = { ...this.emailForm, recipientEmail: this.recipientEmails.join(';') }; // 假设后端期待一个字符串
						this.saveEmailFormDataToMultipleRecipients(); // 调用发送给多个收件人的方法
					} else {
						// 非HR部门或没有使用recipientEmails字段
                        // 表示的是如果HR只选择了一个收件人
                        if(this.isHrDepartment){
                            this.emailForm.recipientEmail=this.recipientEmails;
                        }
						this.saveEmailFormData();
					}
				} else{
					console.log('error draft!!');
				}
			});
		},
        saveEmailFormData() {
			// 调用API发送邮件
			this.axios.post('http://localhost:3759/email-web/saveDraft', this.emailForm)
			.then(response => {
				this.resetForm(); // 调用resetEmailForm来重置表单

				// this.$router.push({ name: 'Outbox' });
                this.$router.push({ name: 'Inbox' }); 
				this.$message.success('Email saved successfully');
				// 处理响应...
			})
			.catch(error => {
				// 如果发送失败，设置状态为 'failed'
				this.emailForm.status = 'failed';
				console.error(error); // 输出完整的错误信息
				if (error.response && error.response.data) {
					// 如果后端返回了具体的错误消息
					this.$message.error('Failed to save email: ' + error.response.data.message);
				} else {
					this.$message.error('Failed to save email');
				}
			});
	    },

        sendEmail() {
			this.$refs.emailForm.validate((valid) => {
				if (valid) {
					// 如果验证通过
					// 将attachments数组转换为JSON字符串并存入emailForm.attachmentInfo
					this.emailForm.attachmentInfo = JSON.stringify(this.attachments);
                    if (this.scheduledTime) {
                        this.emailForm.status='scheduled';
                        // 如果设置了定时发送时间
                        this.scheduleEmail(); // 调用定时发送方法
                    } 
                    else {
                        // 设置状态为已发送
                        this.emailForm.status = 'sent';
                        // 根据是否是HR部门，使用不同的字段和API端点
                        
                        if (this.isHrDepartment && this.recipientEmails.length > 1) {
                            console.log("HR选择了多个收件人的具体个数:",this.recipientEmails.length);
                            // HR部门且recipientEmails字段被使用
                            this.emailForm = { ...this.emailForm, recipientEmail: this.recipientEmails.join(';') }; // 假设后端期待一个字符串
                            this.sendEmailToMultipleRecipients(); // 调用发送给多个收件人的方法
                        } else {
                            // 非HR部门或没有使用recipientEmails字段
                            // 表示的是如果HR只选择了一个收件人
                            if(this.isHrDepartment){
                                this.emailForm.recipientEmail=this.recipientEmails[0];
                                this.recipientEmails=null;
                                console.log("HR只选择了一个收件人",this.emailForm.recipientEmail);
                            }
                            this.sendEmailFormData(); // 调用原有的发送邮件方法
                        }
                    }
				} 
                else {
					console.log('error submit!!');
				}
			});
		},
        // 定时发送邮件的方法
		scheduleEmail() {
			// 假设 this.scheduledTime 是你从日期选择器得到的日期时间对象
			let formattedTime = moment(this.scheduledTime)
			.tz("Asia/Shanghai") // 或者使用用户的本地时区
			.format('YYYY-MM-DDTHH:mm:ss') + 'Z'; // ISO 格式，确保添加了 'Z' 来指定 UTC
			// 创建一个包含所有邮件信息以及定时发送时间的对象
			let emailData = {
				...this.emailForm,
				scheduledTime: formattedTime // 添加定时发送时间
			};
			console.log("scheduled email data:", emailData);
			// 调用后端API来处理定时发送的请求
			this.axios.post('http://localhost:3759/email-web/scheduleEmail', emailData)
			.then(response => {
				this.resetForm(); // 成功后重置表单
                this.$router.push({ name: 'Inbox' });
				this.$message.success('Email scheduled for delivery at: ' + formattedTime);
			})
			.catch(error => {
				// 如果发送失败，设置状态为 'failed'
				this.emailForm.status = 'failed';
				console.error(error); // 输出完整的错误信息
				if (error.response && error.response.data) {
					// 如果后端返回了具体的错误消息
					this.$message.error('Failed to send email: ' + error.response.data.message);
				} else {
					this.$message.error('Failed to send email');
				}
			});
		},
        sendEmailFormData() {
			// 调用API发送邮件
			this.axios.post('http://localhost:3759/email-web/send', this.emailForm)
			.then(response => {
				this.resetForm(); // 调用resetEmailForm来重置表单
				// this.$router.push({ name: 'Outbox' });
                this.$router.push({ name: 'Inbox' }); 
				this.$message.success('Email sent successfully');
				// 处理响应...
			})
			.catch(error => {
				// 如果发送失败，设置状态为 'failed'
				this.emailForm.status = 'failed';
				console.error(error); // 输出完整的错误信息
				if (error.response && error.response.data) {
					// 如果后端返回了具体的错误消息
					this.$message.error('Failed to send email: ' + error.response.data.message);
				} else {
					this.$message.error('Failed to send email');
				}
			});
	    },
        resetEmailForm() {
            this.emailForm = {
                recipientEmail: '',
                senderEmail: localStorage.getItem('userEmail') || '',
                subject: '',
                content: '',
                attachmentInfo: [],
                status: '',
            };
            this.attachments = [];
            this.recipientEmails = [];
        },
        formatDate(date) {
            return this.$moment(date).format('YYYY-MM-DD'); // 格式化为您需要的格式
        },
        closeView() {
            this.$router.push({path:'Inbox'});
        },
        resetForm() {
			// 只重置特定的字段，保留senderEmail字段
			this.emailForm = {
				...this.emailForm, // 使用展开操作符保留其他值，主要是senderEmail
				recipientEmail: '',
				subject: '',
				content: '',
				attachmentInfo: '',
				status: '',
			};
			this.attachments = []; // 清空附件列表
            this.recipientEmails = [];
            this.scheduledTime = null;
		},
        // 多个收件人(发送邮件)
		// 多个收件人
		sendEmailToMultipleRecipients() {
			this.axios.post('http://localhost:3759/email-web/sendEmailToMulRecipients', this.emailForm)
				.then(response => {
					if(response.data.success) {
						this.resetForm(); // 调用resetEmailForm来重置表单
                        this.$router.push({ name: 'Inbox' }); 
						this.$message.success(response.data.message);
						// 进一步的处理，例如清空表单，跳转页面等
					} else {
						this.$message.error(response.data.message);
					}
				})
				.catch(error => {
					console.error("Error sending email to multiple recipients:", error);
					this.$message.error('Failed to send email due to server error');
				});
		},
		saveEmailFormDataToMultipleRecipients(){
			this.axios.post('http://localhost:3759/email-web/saveDraftMultipleRecipients', this.emailForm)
			.then(response => {
				this.resetForm(); // 调用resetEmailForm来重置表单
                this.$router.push({ name: 'Inbox' }); 
				// this.$router.push({ name: 'Outbox' });

				this.$message.success('Email saved successfully');
				// 处理响应...
			})
			.catch(error => {
				// 如果发送失败，设置状态为 'failed'
				this.emailForm.status = 'failed';
				console.error(error); // 输出完整的错误信息
				if (error.response && error.response.data) {
					// 如果后端返回了具体的错误消息
					this.$message.error('Failed to save email: ' + error.response.data.message);
				} else {
					this.$message.error('Failed to save email');
				}
			});
		},

    },

};
</script>

<style lang="less" scoped>
.email-container {
    height: 650px;/* 根据你的内容多少调整，确保内容能够良好展示 */
  	overflow: auto; /* 如果内容超出指定高度，允许滚动 */
    .email-form{
        padding: 20px;
        .close-btn {
            position: absolute;
            right: 60px;
            top: 20px;
            background-color: #dde1be;
            color: #2f4d37;
            border: 1px solid #d1ccbc;
            &:hover {
                background-color: #c8ccac;
                color: #2f4d37;
                border: 1px solid #d2d4c2;
            }
        }
        .email-subject{
			color: #2f4d37;
		}
        ::v-deep  .el-form-item__label {
			color: #2f4d37 !important; /* 设置 label 的字体颜色 */
			font-size: 15px;
		}
		::v-deep .el-icon-edit {
			color: #136d45; /* 将颜色设置为你喜欢的颜色 */
		}
		/* 隐藏表单项前面的星号 */
		::v-deep .el-form-item__label::before {
			display: none !important;
		}
		::v-deep .el-select .el-input__inner {
			text-align: left; /* 使文本靠左显示 */
		}
		.upload-demo{
			margin-top: 10px;
			::v-deep .el-button{
				font-size: 15px;
				background-color: #9ab390;
				border: 1px solid #fbf6e4;
				color: #f3ffde;
				&:hover {
					background-color: #2f4d37;
				}
			}
		}
        .form-actions{

			::v-deep .el-button{
				margin-top: 30px;
				font-size: 15px;
				background-color: #9ab390;
				border: 1px solid #fbf6e4;
				color: #f3ffde;
				&:hover {
					background-color: #2f4d37;
				}
			}
		}
        ::v-deep .ql-picker-label {
			line-height: normal; /* 修正行高 */
		}
		::v-deep .ql-snow .ql-picker-label{
			float: right;
			width: auto;
			padding-right: 15px;
		}
    }
}

</style>